"""
Queues real REsimpli sync actions for Alex, using the exact action
names from Alex's real locked instructions (not invented names):
POST_DISPO_LISTING, SEND_E_SIGN_ASSIGNMENT, SEND_E_SIGN_JV, RECORD_CALL,
TAG_FP. SMS_FP_PHASE_2 is deliberately never queued here - it's
explicitly forbidden in Phase 1 per the same document.

Still just queuing - nothing calls REsimpli's real API yet (no key).
This is what was previously missing: the table existed, real actions
were named in the spec, but nothing in the code ever wrote a row.
"""

from alex.db.db import get_connection


def queue_resimpli_action(deal_id: int, action: str, detail: str | None = None) -> None:
    conn = get_connection()
    conn.execute(
        "INSERT INTO resimpli_sync_queue (deal_id, action, detail, status) "
        "VALUES (?, ?, ?, 'QUEUED')",
        (deal_id, action, detail),
    )
    conn.commit()
    conn.close()
