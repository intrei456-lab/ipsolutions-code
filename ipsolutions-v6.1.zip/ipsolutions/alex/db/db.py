"""
Alex's database connection helper. Same pattern as Chris's - separate
SQLite file, WAL mode, cross-agent reads happen via a direct connection
to the sibling agent's .db file (see shared/db.py for the helper).
"""

import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "alex.db"
SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    conn = get_connection()
    with open(SCHEMA_PATH) as f:
        conn.executescript(f.read())
    conn.commit()

    try:
        conn.execute("ALTER TABLE resimpli_sync_queue ADD COLUMN detail TEXT")
        conn.commit()
    except sqlite3.OperationalError:
        pass  # column already exists — normal after the first run

    conn.close()


if __name__ == "__main__":
    init_db()
    print(f"Alex DB initialized at {DB_PATH}")
