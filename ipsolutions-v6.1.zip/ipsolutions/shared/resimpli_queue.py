"""
Queues a real REsimpli pipeline-stage sync every time a lead's status
actually changes in our system - "pipeline movement" that's queued
automatically instead of only happening at lead creation.

Uses the real stage mapping already confirmed against REsimpli's actual
UI (shared/resimpli_mapping.py). Still just QUEUES - nothing actually
calls REsimpli's API yet, since RESIMPLI_API_KEY is still blank. Once
that's live, a real flush job reads resimpli_sync_queue WHERE status =
'QUEUED' and pushes each row's `detail` (the target stage) to REsimpli,
then marks it flushed - that flush job doesn't exist yet either, this
just makes sure the queue has the right data waiting for it.
"""

from chris.db.db import get_connection
from shared.resimpli_mapping import LEAD_STATUS_TO_RESIMPLI_STAGE


def queue_status_update(lead_id: int, new_status: str) -> None:
    stage = LEAD_STATUS_TO_RESIMPLI_STAGE.get(new_status)
    if stage is None:
        # No confirmed REsimpli stage for this status yet (e.g. DEAD -
        # see the honest note in resimpli_mapping.py) - don't queue a
        # guess, just skip it until the real column name is confirmed.
        return

    conn = get_connection()
    conn.execute(
        "INSERT INTO resimpli_sync_queue (lead_id, action, detail) VALUES (?, 'UPDATE_STATUS', ?)",
        (lead_id, stage),
    )
    conn.commit()
    conn.close()
