"""
Maps IPSolutions' internal lead status/fields to REsimpli's real data
model - confirmed directly against REsimpli Academy screenshots
(actual product UI, not documentation guesses).

STRATEGIC DECISION #2 (confirmed by Thomas, corrects the earlier
Twilio direction): NOT a separate SMS system. Thomas does not want a
standalone Twilio account/A2P registration running independently of
REsimpli - he wants the command center to work AS A LAYER ON TOP of
REsimpli, texting and calling through REsimpli's own native number and
infrastructure, not a second parallel system.

Real implication: REsimpli's own API doesn't expose a "send one SMS"
action (confirmed - only Create Lead / Create Buyer/Agent / record
updates). The realistic integration path once the API key is live:
our sync writes the lead into REsimpli and assigns it to an existing
REsimpli Drip Campaign (REsimpli's real "Converting to Lead" modal has
a "Put contact on a Drip Campaign?" toggle, and REsimpli's Custom Drip
builder supports SMS as a real step type alongside Direct Mail/Task/
RVM/Email). Thomas builds/owns the actual campaign content inside
REsimpli's own dashboard; our command center's job is deciding WHICH
lead should be on WHICH campaign and WHEN, not sending the text itself.
No Twilio account, no A2P registration on IPSolutions' side - REsimpli
already handles that compliance burden themselves.

STILL OPEN: which specific REsimpli campaign(s) new/researched/hot
leads should route into - same open question as RESIMPLI_DEFAULT_CAMPAIGN_ID
below, needs Thomas to check his real REsimpli account and confirm.

STRATEGIC DECISION (confirmed by Thomas): Chris stays fully custom.
REsimpli also ships its own built-in seller-conversation AI (talks to
the seller, handles objections, triggers drip campaigns, books the
appointment, auto-advances the pipeline board - "lives inside REsimpli,
zero setup"). That feature is NOT used - Chris replaces everything it
would have done. REsimpli's role here is purely the CRM/data layer:
leads, pipeline stages, contact records. Our command center (Chris/
Alex/Taylor) does all the actual AI work and syncs its real results
into REsimpli's fields, not the other way around.

ACTION NEEDED ON THOMAS'S SIDE (not something this code can do): go
into REsimpli's own account settings and turn off/disable their native
AI conversation feature for leads that IPSolutions is working, so it
doesn't run in parallel with Chris and create duplicate/conflicting
seller conversations. Where exactly that toggle lives wasn't visible
in the screenshots provided - check REsimpli's AI/Automation settings,
or ask their support directly if it's not obvious.

NOT wired to any live sync yet - RESIMPLI_API_KEY is still blank in
.env. This exists so that when the key arrives, the sync logic gets
built against REsimpli's real pipeline stages and field names on the
first pass, instead of guessing and having to redo it.
"""

# REsimpli's real pipeline board columns, left to right, confirmed from
# the actual Leads (89) kanban view:
#   New Leads -> Discovery -> Interested Add To Follow-up ->
#   Due Diligence -> Offer Follow Up -> Offers Made -> Under Contract
#
# Mapped against our real `leads.status` values (chris/db/schema.sql).
# Anything without a clean match is left None - don't guess a stage,
# leave it manual until confirmed.
LEAD_STATUS_TO_RESIMPLI_STAGE = {
    "NEW": "New Leads",
    "RESEARCHED": "Discovery",
    "WORKING": "Interested Add To Follow-up",
    "ACTIVE": "Under Contract",       # set once lock_deal fires - contract is real at that point
    "DEAD": None,                     # REsimpli's board didn't show a "Dead/Lost" column in the
                                       # screenshots - confirm the real column name before mapping
    "DO_NOT_CONTACT": None,
}

# REsimpli's real lead detail fields (right-hand panel), confirmed from
# the actual List Stacking / lead detail screenshots, mapped against
# our real `leads` table columns.
LEAD_FIELD_TO_RESIMPLI = {
    "arv": "Est. Value",
    "mortgage_balance": "Est. Total Liens",
    "equity": "Est. Equity",
    "address": "Property Address",     # REsimpli splits city/state/zip out of the same record
    "owner_name": "Owner 1 Name",
}

# Additional real fields confirmed from REsimpli's List Stacking
# analytics dashboard - useful for future lead enrichment, not
# currently stored in our leads table:
#   - Vacant status (Total Vacant %, Vacant in Last 30 Days)
#   - Phone type breakdown (Mobile / Landline / VoIP / Other)
#   - Opted Out status
#   - Owner Type (Absentee / Homeowner / Unknown)
#   - Ownership Type (Individual / Company / Trust)
# None of these map to an existing column - flagging here so a future
# schema addition (if these ever get pulled in) matches REsimpli's
# real field names instead of inventing new ones.

# REsimpli's full real feature inventory (from their own nav menu) -
# relevant to what IPSolutions could eventually pull in vs. build custom:
#   DATA:      List Stacking, Free Skip Tracing, Driving for Dollar
#   MARKETING: Drip Campaign, Direct Mail, Seller Website, Gen 2 AI
#   SALES:     All-in-One CRM, Speed to Lead, Buyer Management, E-Sign
#   OPERATION: KPI Dashboard, Full Accounting, Leaderboard
#
# E-SIGN IS REAL AND RELEVANT: REsimpli has a built-in e-signature
# feature. This directly relates to /chris/leads/{id}/lock_deal, which
# currently just takes a manually-pasted "Purchase Agreement Document
# URL" - once the API key is live, that field could potentially be
# replaced with a real REsimpli E-Sign document link instead of a
# manual paste. Worth revisiting once the API key is in hand and we
# can see what the E-Sign API actually exposes.
#
# Drip campaign structure (from the real "Add Drip Campaign" builder):
# each step = a delay (duration + time span) before one of five real
# actions - Direct Mail, SMS, Task, RVM (ringless voicemail), Email.
# Relevant to fp-outreach.md's relationship warm-up cadence (Section 6)
# if that ever gets built as an actual REsimpli drip instead of a
# manual touch.

# REAL REQUIREMENT confirmed from the "Converting to Lead" modal: REsimpli
# requires a Campaign to be selected when a lead is created/converted -
# it's a required field (marked with *), not optional. Our current
# insert_lead() / resimpli_sync_queue has no campaign concept at all.
#
# Before the real CREATE_LEAD sync can fire, Thomas needs to tell us
# which REsimpli campaign new IPSolutions leads should route into (the
# screenshots show existing campaign groups: "ACQ Campaigns (4)",
# "FUS Campaigns (6)", "Leadership (7)" - likely one of the ACQ ones,
# but needs to be confirmed, not assumed).
RESIMPLI_DEFAULT_CAMPAIGN_ID = None  # TODO: set once Thomas confirms which campaign

# REsimpli also supports (per the same modal): putting a new lead on a
# Drip Campaign, and adding Tags, both as explicit yes/no choices at
# creation time - worth deciding IPSolutions' defaults for both before
# the real sync goes live, rather than defaulting silently to "No" for
# both the way the modal itself defaults.
