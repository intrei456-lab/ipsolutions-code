---
name: agent-outreach
description: Use when running the real estate agent outreach channel (Mat Beard's off-market model) - list sourcing, tiering logic, poke/follow-up scripts, and the tier-one phone call flow for turning agent relationships into off-market deal flow.
---

# Skill: Real Estate Agent Outreach

Source: Mat Beard off-market model (Deal Generator training, March
2026). Adapted for IPSolutions LLC markets and terminology rules. This
is Chris's second lead-generation channel, separate from direct-to-
seller outreach (tax delinquent, code violations, FSBO).

## Why agents, and why active agents first

Over 70% of licensed agents nationally didn't close a single sale last
year. An agent with an active listing right now is, by definition, not
in that 70% — that's the low-hanging fruit before broadening to the
full license list in a market. Agents see off-market and about-to-
expire inventory before it ever hits public search, which is the whole
point of this channel.

## List sourcing (per market: Baltimore MD primary, FL and NC counties)

Pull from BatchLeads/PropStream (either works — same core filters):

1. Boundary/radius search around the target ZIPs for that market
2. Filter: residential, single-family (add multifamily for NC given
   that market's multifamily strength)
3. Filter: MLS status = active or pending listings only (this is the
   "currently doing deals" filter)
4. Optional price cap — exclude agents listing properties well above
   what this business buys in that market, since they're unlikely to
   have anything in the ugly/discount range
5. Prefer agents representing individual homeowners over flippers/
   institutional sellers — filter out iBuyer brokerages (Opendoor,
   Offerpad) by brokerage name or email domain, since their inventory
   is company-owned and rarely distressed

## The tier system

Every agent contact lands in one bucket. This is the entire point of
the outreach bot/VA — sifting, not selling.

| Tier | Definition | Action |
|---|---|---|
| **Tier 1** | Gave us an address; actively working a deal with them | Call within hours, run analysis, negotiate or pass |
| **Tier 2** | Tier 1 fallout — analyzed and passed | Owner (Thomas/Chris) works these personally |
| **Tier 3** | No inventory right now, but open to hearing about future ones | Automated monthly check-in, different message each time |
| Follow-up | No answer | Re-poke on a cadence |
| Dead | Rude / explicitly not interested | Stop contact |

**Golden bucket**: every agent who has ever gone to Tier 1, regardless
of whether that specific deal closed. This is the referral base —
revisit any time the buy criteria changes (e.g. "actually, send me
multifamily this month" instead of the standard ugly-house ask).

Reference math: getting one deal from roughly 1 in 3 agents you
transact with in a given year is a reasonable expectation once the
relationship is real, not just a first touch.

## Poke messages (first touch, agent-facing)

Keep these short, non-CRM-sounding, peer-to-peer — an agent should feel
like they're texting a person, not a system. Rotate variants so repeat
contacts don't get an identical message. Never use "cash buyer" or
"investor" language; frame as a financial partner / off-market buyer
relationship.

> "Hey [Name], this is [Chris/Thomas] with Intense Property Solutions —
> we buy properties in [market] as-is, off-market. Any chance you've got
> anything ugly on your radar that's been sitting, needs work, or the
> seller just wants gone fast?"

> "Hi [Name], reaching out because you've got listings in [market].
> We're always looking for the fixer-upper nobody wants to show — got
> anything like that right now, on or off market?"

If they say no inventory: **don't drop them** — ask the qualifying
follow-up that keeps them warm for Tier 3:

> "Totally get it. How often do you run across something like that in
> this area — every now and then, or pretty rare?"

## Real worked example (from the source video, verbatim)

Matt walks through an actual live conversation on screen. This is the
real shape a Tier 1 conversation takes, start to finish — worth
matching this rhythm exactly, not just the general pattern above.

The agent (Stephanie) sent a listing link without an address. The bot
still worked from just the link:

> Bot: *"Thanks for sending that over. Do you know the condition?"*
> Stephanie: *"30 day close, no repairs, no updates needed. 250k, not
> on market."*
> Bot: *"Got it — 250 and truly off-market helps a lot. I'm sending
> this to my partner Matt and acquisition team."*

The bot parsed the address directly out of the listing link (Chimney
Ridge Road) without Stephanie ever typing it, tagged the lead Tier 1
the moment a real asking price came back, and immediately queued the
call: *"I'll give you a call shortly."*

Property analysis ran automatically in the background: estimated value
$230K against a $250K ask — not a deal (need to be ~50-60% of retail
for a workable as-is offer, so this was $180K+ off). Matt's real pass
message, verbatim:

> *"Stephanie, thank you so much for this opportunity. Probably not
> gonna be a good fit on this one because we're typically looking for
> the ugly ones we can buy at a discount. But you know, awesome house —
> good luck with selling it, and keep this in mind if you run across
> anything else down the road."*

This is the real pattern for a pass: **thank them, name the specific
reason (not vague), compliment the property honestly, leave the door
open for next time.** No stringing along, no soft maybe.

A second real example, agent not open to creative terms: agent said
*"not open to creative finance,"* and the response was simply to tag
Tier 2 and move on — no extended persuasion attempt. Confirms the hard
rule already in this skill: don't waste time trying to talk someone
into something they've already said no to.

## When an agent responds with a property

Get to yes/no fast — speed matters more than a perfect script here.
Ask only what's needed to run a same-call estimate:

- Condition (repairs needed, updates needed)
- Asking price, and whether it's on or off market
- Timeline / how soon they need it closed

Run the quick property analysis (retail value estimate → apply the
50–60% rule of thumb for an as-is offer range) before responding. If
it's clearly not a fit, say so immediately rather than stringing the
agent along — this preserves the relationship for the next one. Real
verbatim example from the source video (see worked example above):

> "Appreciate this opportunity — probably not gonna be a good fit on
> this one, we're typically looking for the ones we can buy at a real
> discount. But nice property — good luck with it, and keep us in mind
> if you run across anything else."

If the numbers are close but not there, and creative terms might work:

> "Hey [Name], checked out [address] — the only way we could get close
> to asking is on some kind of creative terms, seller finance or
> subject-to, maybe a hybrid. Not sure if your client's open to that,
> but wanted to ask before passing."

If it tags Tier 1 (address given, numbers plausible), move to the phone
call — don't keep negotiating over text.

## Speed-to-call is the highest-leverage step in this channel

The moment an agent hands over an address and it tags Tier 1, the clock
starts. Target: call within **minutes**, not hours — same principle as
Alex's Time-to-Blast metric on the dispo side, just applied to the
front end of this channel. Six hours is the outer ceiling if a human
has to pick this up manually; automated (bot books the call slot the
second the tag fires) should be closing in on five minutes.

Why it matters more than almost anything else here:

- **Agents are talking to other buyers too.** A fast response is often
  the entire difference between getting the deal looked at and getting
  ignored on the next one — agents remember who moves and who doesn't.
- **Speed reads as competence.** An agent who gets a same-day (or
  same-minute) response trusts that this business is real and worth
  sending the next off-market lead to. A slow response undoes the
  relationship-building this whole channel depends on.
- **It compounds the golden bucket.** Every fast, clean response —
  even a pass — is what turns a one-time agent contact into a repeat
  source. The 1-in-3 repeat-deal rate depends on the agent having a
  good experience working with us, and response time is most of that
  experience.

**Hard rule**: never let a Tier 1 sit uncalled. If Chris (or Thomas)
can't make the call immediately, that's an escalation, not something
to queue and get to later.

## Tier 1 phone call flow

Goal: confirm where they are in the process, get any competing offers
on the table, and set an appointment if it's worth pursuing further.

1. Open with context so it doesn't feel like a cold call — reference
   the property they sent and what's already known:
   > "Hey [Name], this is [Chris] with Intense Property Solutions — you
   > sent over the place on [street]. Where's your client at in the
   > process on this one?"
2. Ask about condition and repair scope in their own words
3. Ask directly if there are other offers on the table — this tells you
   whether there's room to negotiate or whether it's a bidding war to
   stay out of
4. If it's a real fit: set a phone appointment (or hand off) to make an
   offer, framed as "so we can see if this makes sense for both sides"
5. If it's not a fit: close it out quickly and warmly (see pass message
   above) rather than leaving it hanging — a clean no keeps the
   relationship healthy for the next property

## Tier 3 / dormant re-engagement

Monthly automated touch, rotate the ask based on current buy priority
instead of always asking for the generic ugly house:

> "Hey [Name], still buying in [market] — this month we're specifically
> looking for multifamily / creative-finance situations if anything
> like that crosses your desk."

## KPI benchmarks

- 12–20 off-market properties sourced per closed deal is the
  well-run range; 20–30 is still workable while volume is ramping.
  If the ratio is meaningfully worse than that, the fix is usually in
  qualifying speed or offer presentation, not lead volume.
- Roughly 1 in 3 agents a deal gets done with in a calendar year
  produces a second deal that same year — the golden bucket compounds.
- **Time-to-call on Tier 1**: target minutes, hard ceiling of hours.
  This is the front-end equivalent of Taylor's Time-to-Blast metric and
  should be tracked the same way — it's not a soft goal.

## Hard rules (carried from AGENTS.md)

- Never say "cash buyers" or "investor list" in agent-facing copy —
  use "financial partners" / "funding network" framing
- Never present a single number to an agent before there's a real
  reason to believe the deal works — frame as a range once repair/ARV
  numbers are in hand
- Tone with agents is peer-to-peer, never CRM-sounding or scripted —
  if a message reads like a bot, rewrite it
