---
name: 5-day-dispo-process
description: Use when running dispositions on a newly locked deal - the day-by-day process from photos through decision day, including the TTB (Time to Blast) metric.
---

# Skill: 5-Day Dispo Process

Source: originally Jerry Norton's 5-day dispo model, taught to
IPSolutions via Matt Beard's "checkbooks" training. Implemented in
`alex/dispo/five_day_engine.py`.

## TTB — the single most important metric

Time to Blast (TTB) = hours from Chris's handoff to Alex actually
blasting the deal to financial partners. This is THE headline metric.

- **Target: under 12 hours**
- **Critical: over 24 hours** (fires an alert)

Per Matt Beard's source material, deals with TTB under 12 hours close
at a dramatically higher rate — the real reference point is contracted
deals selling to roughly 70% purely by making TTB a tracked, enforced
metric instead of an afterthought. Speed to market matters more than
almost anything else in dispositions.

## Day-by-day (exact checklist, from the real Dispo Command tool)

26 tasks total across 6 days (Day 0–5). Role tags below (CRITICAL /
ASST / MGR) are from the source tool — they indicate who/what actually
executes the task, which maps directly onto whether Alex handles it
autonomously (ASST) or it needs a human/manager action (MGR, CRITICAL).

**Day 0 — Pre-Blast Prep** (5 tasks)
*"Get everything set before anything goes public. No blast until media
is uploaded and title is open."*
1. Open title with preferred title company — **CRITICAL**
2. Align property name/ID across CRM, deal portal, and shared drive
3. Upload all photos, videos, and specs to deal portal
4. Verify walkthrough date/time is set in portal & calendar
5. Confirm CRM deal portal is fully populated — no blast until this is
   done

**Day 1 — Blast & Build** (4 tasks)
*"Generate conversations and identify serious buyers. Keep copy vague
to prompt replies."* — this is a real, specific tone rule: the Day 1
blast copy should NOT over-explain the property, it should be vague
enough that interested buyers have to reply/ask to learn more, which is
what actually surfaces genuine interest vs. passive scrollers.
1. Send email + SMS blast to full buyer list
2. Post to Facebook groups and dispo services
3. Log all interested replies as buyer leads in Prospects (tag A/B/C)
4. Dispo Manager calls A-Tier buyers personally — same day, no
   exceptions — **MGR**

**Day 2 — Outreach** (4 tasks)
*"Grow the buyer pool and surface demand. Keep details light on text —
move to the phone."* — another real tone rule: don't negotiate or
over-explain over text, the goal of texting is just to get a real
phone conversation started.
1. Call skip-traced active buyers in the area (not yet on list) —
   **MGR**
2. Send basic-info text and portal link to interested parties
3. Update all Prospects statuses in CRM
4. Move all interested buyers from text to a phone call

**Day 3 — Reminders**: Follow up on Day 1 non-responders — A-tier gets
a mandatory Thomas phone call, B-tier gets a follow-up email, C-tier
gets no follow-up yet. If no offers by end of Day 3, prepare a
price-adjustment recommendation.

**Day 4 — Walkthrough Day**: ONE 2-hour showing window, all interested
financial partners in the same slot — never individual showings.
Escort every financial partner; never let one talk to the seller
unsupervised. All offers are due by end of business day.

**Day 5 — Decision Day**: Ask "is that really the best you can do?" on
every offer. Send FOMO texts to other interested parties once one offer
is accepted.
