"""
Connects chris/followup/cadence.py's timing logic (which computes WHEN
to follow up) to shared/vapi_client.py's trigger_seller_followup_call
(which actually places the call). Before this file, cadence.py was
real, correct logic that nothing ever called - a genuine "AI Follow-Up"
gap versus what REsimpli's native AI would have covered.

Voice follow-up works today (Vapi is already wired). Text/SMS
follow-up does NOT - and per Thomas's real direction, it won't be a
separate Twilio/A2P build. Once the REsimpli API key is live, text
follow-up should route through REsimpli's own Drip Campaign feature
(assign the lead to a real REsimpli campaign) rather than this
codebase sending SMS directly - see shared/resimpli_mapping.py for
the full reasoning. enqueue_followup() below always schedules a voice
call for now; the REsimpli drip-assignment path isn't built yet either,
since it still needs a real API key and a confirmed campaign ID.
"""

from datetime import datetime, timedelta

from chris.db.db import get_connection
from chris.followup.cadence import cadence_from_price_gap, adjust_for_motivation


def enqueue_followup(lead_id: int, gap_from_mao: float, motivation: str | None) -> dict:
    """
    Called after a brief/offer goes out with no immediate yes/no - queues
    the next real follow-up touch using the actual cadence logic instead
    of a guessed interval.
    """
    cadence = cadence_from_price_gap(gap_from_mao)
    cadence = adjust_for_motivation(cadence, motivation or "MEDIUM")
    next_touch = datetime.utcnow() + timedelta(days=cadence.frequency_days_min)

    conn = get_connection()
    conn.execute(
        "INSERT INTO followup_queue (lead_id, track, next_touch_at, status, drip_step) "
        "VALUES (?, ?, ?, 'PENDING', ?)",
        (lead_id, 1, next_touch.isoformat(), cadence.frequency_description),
    )
    conn.commit()
    conn.close()
    return {"queued": True, "next_touch_at": next_touch.isoformat(), "reason": cadence.frequency_description}


def run_seller_followup_dispatch() -> dict:
    """
    The actual send side - meant to run on a schedule (see main.py's
    scheduler). Finds every due, pending follow-up with a real phone
    number on file and places a real Vapi voice call. Leads with no
    phone number are skipped, not silently dropped - they stay PENDING
    so they're not lost, just not actionable yet.
    """
    from shared.vapi_client import trigger_seller_followup_call

    conn = get_connection()
    due = conn.execute(
        "SELECT fq.queue_id, fq.lead_id, fq.drip_step, l.owner_name, l.owner_phone, l.address "
        "FROM followup_queue fq JOIN leads l ON l.lead_id = fq.lead_id "
        "WHERE fq.status = 'PENDING' AND fq.next_touch_at <= datetime('now')"
    ).fetchall()

    called, skipped_no_phone, blocked_phase1, failed = 0, 0, 0, 0
    for row in due:
        if not row["owner_phone"]:
            skipped_no_phone += 1
            continue
        try:
            trigger_seller_followup_call(
                lead_name=row["owner_name"] or "there",
                lead_phone=row["owner_phone"],
                lead_id=row["lead_id"],
                followup_reason=f"Scheduled follow-up on {row['address']} ({row['drip_step'] or 'no reason logged'})",
            )
            conn.execute("UPDATE followup_queue SET status = 'SENT' WHERE queue_id = ?", (row["queue_id"],))
            called += 1
        except RuntimeError as exc:
            if "PHASE 1 VOICE RULE" in str(exc):
                blocked_phase1 += 1
            else:
                failed += 1
        except Exception:  # noqa: BLE001 — one bad call should never block the rest of the batch
            failed += 1
    conn.commit()
    conn.close()
    return {
        "called": called, "skipped_no_phone": skipped_no_phone,
        "blocked_phase1": blocked_phase1, "failed": failed, "checked": len(due),
    }
