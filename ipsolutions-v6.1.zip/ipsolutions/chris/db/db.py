"""
Chris's database connection helper. One SQLite file, WAL mode for
concurrent reads while the scheduler writes.
"""

import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "chris.db"
SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    """Create tables if they don't exist. Safe to call on every startup."""
    conn = get_connection()
    with open(SCHEMA_PATH) as f:
        conn.executescript(f.read())
    conn.commit()
    _migrate_add_lat_lng(conn)
    conn.close()


def _migrate_add_lat_lng(conn: sqlite3.Connection) -> None:
    """
    schema.sql's CREATE TABLE IF NOT EXISTS only applies to brand-new
    databases — an existing chris.db from before the map feature won't
    get the new lat/lng columns automatically. This adds them once,
    safely, on every startup (SQLite raises if the column already
    exists, which we just ignore).
    """
    for column in ("lat", "lng"):
        try:
            conn.execute(f"ALTER TABLE leads ADD COLUMN {column} REAL")
            conn.commit()
        except sqlite3.OperationalError:
            pass  # column already exists — normal after the first run

    try:
        conn.execute("ALTER TABLE resimpli_sync_queue ADD COLUMN detail TEXT")
        conn.commit()
    except sqlite3.OperationalError:
        pass  # column already exists — normal after the first run


def seed_market_zips() -> None:
    """Populate market_zips from shared config. Safe to re-run (INSERT OR REPLACE)."""
    from shared.config import MARKET_ZIPS

    conn = get_connection()
    for state, info in MARKET_ZIPS.items():
        for zip_code in info["zips"]:
            conn.execute(
                """
                INSERT OR REPLACE INTO market_zips (zip, state, region_tier, multifamily_strong)
                VALUES (?, ?, ?, ?)
                """,
                (zip_code, state, info["tier"], int(info["multifamily_strong"])),
            )
    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db()
    seed_market_zips()
    print(f"Chris DB initialized at {DB_PATH}")
