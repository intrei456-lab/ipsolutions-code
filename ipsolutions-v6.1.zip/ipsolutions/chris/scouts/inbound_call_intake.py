"""
chris/scouts/inbound_call_intake.py

Single job: given a real inbound seller call transcript (a seller
calling IN, not us calling out), extract the property/owner info
needed to create or update a lead record - the "AI Call Answering" +
"AI Lead Qualification" capability that previously had no equivalent
for unprompted inbound calls (Brielle only handled calls WE triggered).

Triggered from /vapi/webhook when Vapi reports an inbound call. Narrow,
single-purpose per AGENTS.md's design principle: this only extracts
structured info from a transcript, it doesn't touch the database
(main.py's webhook handler does that) or decide call routing.
"""

from shared.llm_client import draft_content


def extract_inbound_seller_call(transcript: str, caller_phone: str) -> dict:
    """
    Returns a dict with whatever could be confidently extracted:
    {name, address, city, state, zip, motivation, summary}.
    Any field the caller didn't actually provide comes back as None -
    this never invents an address or name that wasn't really said.
    """
    if not transcript or not transcript.strip():
        return {
            "name": None, "address": None, "city": None, "state": None, "zip": None,
            "motivation": "UNKNOWN", "summary": "No transcript available - call may not have connected.",
        }

    system_prompt = """You are extracting structured information from a
real phone call transcript between a seller who called IN to Intense
Property Solutions and Brielle, the voice assistant who answered.

Extract ONLY what the caller actually said - never invent or infer an
address, name, or detail that wasn't genuinely stated. If something
wasn't mentioned, say NONE for that field exactly.

Respond in EXACTLY this format, nothing else:
NAME: caller's name, or NONE
ADDRESS: street address of the property, or NONE
CITY: city, or NONE
STATE: two-letter state code, or NONE
ZIP: 5-digit zip, or NONE
MOTIVATION: HIGH, MEDIUM, LOW, or UNKNOWN - based on urgency/tone actually expressed
SUMMARY: one or two sentences on what the caller actually wants"""

    user_prompt = f"""Real call transcript:

{transcript}

Extract the fields above from what was actually said."""

    result = draft_content(system_prompt, user_prompt, max_tokens=300, check_safety=False)
    text = result["text"].strip()

    fields = {"name": None, "address": None, "city": None, "state": None, "zip": None,
              "motivation": "UNKNOWN", "summary": ""}
    label_map = {"NAME": "name", "ADDRESS": "address", "CITY": "city", "STATE": "state",
                 "ZIP": "zip", "MOTIVATION": "motivation", "SUMMARY": "summary"}

    for line in text.splitlines():
        if ":" not in line:
            continue
        label, _, value = line.partition(":")
        key = label_map.get(label.strip().upper())
        if not key:
            continue
        value = value.strip()
        fields[key] = None if value.upper() == "NONE" else value

    if fields["motivation"] not in ("HIGH", "MEDIUM", "LOW"):
        fields["motivation"] = "UNKNOWN"

    return fields
