"""
Taylor's node engine — New Handoff Ingest (Step 1) and the node-by-node
advancement rules for the nodes with real conditional logic (most nodes
are simple "confirm X" checks; a few have hard gates worth encoding
explicitly).
"""

from dataclasses import dataclass, field

from shared.config import TITLE_COMPANY_DIRECTORY, emd_tier_for_close_window
from taylor.db.db import get_connection
from taylor.nodes.node_template import NODE_TEMPLATE

REQUIRED_HANDOFF_FIELDS = [
    "assignment_signed_doc_url", "fp_name", "fp_email", "fp_phone",
    "fp_entity", "emd_amount", "emd_received_at", "close_date_target",
    "photos_package_url", "zip", "state", "address",
]


@dataclass
class HandoffValidationResult:
    valid: bool
    missing_fields: list[str] = field(default_factory=list)


def validate_handoff(handoff_payload: dict) -> HandoffValidationResult:
    missing = [f for f in REQUIRED_HANDOFF_FIELDS if not handoff_payload.get(f)]
    return HandoffValidationResult(valid=len(missing) == 0, missing_fields=missing)


def ingest_new_handoff(handoff_payload: dict) -> dict:
    """
    Step 1: New Handoff Ingest. Validates required fields, opens a
    closings row at node 1 (done) / node 2 (in_progress), seeds all 36
    node rows, resolves title company by state, and handles the NC
    TBD-title-company hold.
    """
    validation = validate_handoff(handoff_payload)
    if not validation.valid:
        return {
            "accepted": False,
            "alert_type": "handoff_missing_fields",
            "severity": "HIGH",
            "message": f"Missing required fields: {', '.join(validation.missing_fields)}",
        }

    conn = get_connection()
    try:
        cur = conn.execute(
            """
            INSERT INTO closings (
                deal_id, address, city, state, zip, fp_name, fp_email, fp_phone,
                fp_entity, emd_amount, emd_received_at, close_date_target,
                seller_contract_doc_url, assignment_doc_url, photos_package_url,
                current_node, status, risk_tier
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 2, 'in_progress', ?)
            """,
            (
                handoff_payload.get("deal_id"), handoff_payload["address"],
                handoff_payload.get("city"), handoff_payload["state"], handoff_payload["zip"],
                handoff_payload["fp_name"], handoff_payload["fp_email"], handoff_payload["fp_phone"],
                handoff_payload["fp_entity"], handoff_payload["emd_amount"],
                handoff_payload["emd_received_at"], handoff_payload["close_date_target"],
                handoff_payload.get("seller_contract_doc_url"),
                handoff_payload["assignment_signed_doc_url"],
                handoff_payload["photos_package_url"],
                handoff_payload.get("risk_tier", "STANDARD"),
            ),
        )
        closing_id = cur.lastrowid

        # Seed all 36 node rows; node 1 done (handoff received), node 2 in_progress
        for node in NODE_TEMPLATE:
            status = "done" if node.number == 1 else ("in_progress" if node.number == 2 else "pending")
            conn.execute(
                "INSERT INTO closing_nodes (closing_id, node_number, status, started_at) "
                "VALUES (?, ?, ?, datetime('now'))",
                (closing_id, node.number, status),
            )

        # Resolve title company
        state = handoff_payload["state"]
        title_info = TITLE_COMPANY_DIRECTORY.get(state, {})
        title_company = title_info.get("primary")

        alerts_fired = []
        if state == "NC" and title_company is None:
            conn.execute(
                "UPDATE closings SET title_company_assigned = 'TBD-NC' WHERE closing_id = ?",
                (closing_id,),
            )
            conn.execute(
                """
                INSERT INTO ceo_alerts (closing_id, alert_type, severity, title, message)
                VALUES (?, 'nc_title_company_missing', 'HIGH', 'NC title company needed',
                        'NC deal arrived - Thomas must designate a title company before node 7 can proceed.')
                """,
                (closing_id,),
            )
            alerts_fired.append("nc_title_company_missing")
        else:
            conn.execute(
                "UPDATE closings SET title_company_assigned = ? WHERE closing_id = ?",
                (title_company, closing_id),
            )

        # EMD tier + expected amount
        days_to_close = handoff_payload.get("days_to_close", 14)
        tier = emd_tier_for_close_window(days_to_close)
        conn.execute(
            """
            INSERT INTO emd_status (closing_id, expected_amount, received_amount, received_at,
                                     emd_tier, non_refundable_portion, applies_to_purchase_price)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                closing_id, tier.get("total", tier.get("total_min")), handoff_payload["emd_amount"],
                handoff_payload["emd_received_at"], str(days_to_close),
                tier.get("non_refundable", 2000), tier.get("applies_to_price"),
            ),
        )

        conn.commit()
        return {"accepted": True, "closing_id": closing_id, "alerts_fired": alerts_fired}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Node 4: EMD verification (hard gate)
# ---------------------------------------------------------------------------

def check_node_4_emd(
    received_amount: float | None,
    expected_amount: float,
    received_at: str | None,
    carveout_documented: bool,
    hours_since_assignment_signature: float,
) -> dict:
    """
    Mark done if received >= expected AND received_at is set AND the $2k
    non-refundable carve-out is documented in the contract. If 24h have
    passed since assignment signature with no wire in escrow -> HIGH alert,
    mark blocked.
    """
    if received_amount is not None and received_amount >= expected_amount and received_at and carveout_documented:
        return {"status": "done"}

    if hours_since_assignment_signature > 24:
        return {
            "status": "blocked",
            "blocking_reason": "emd_not_received_24h",
            "alert_type": "emd_not_received_24h",
            "severity": "HIGH",
        }

    return {"status": "pending"}


# ---------------------------------------------------------------------------
# Node 6: Affidavit & MOA filing (risk-tier-gated)
# ---------------------------------------------------------------------------

def check_node_6_affidavit(risk_tier: str, affidavit_filed_confirmed: bool) -> dict:
    """
    STANDARD (default, ~80%+ of deals) -> auto-complete, no filing needed.
    PROTECT_SPREAD -> blocked until Thomas confirms county filing complete.
    """
    if risk_tier == "STANDARD":
        return {
            "status": "done",
            "notes": "Not required - clean transaction, no protect-spread flag. Affidavit & MOA filing skipped.",
        }

    if affidavit_filed_confirmed:
        return {"status": "done"}

    return {
        "status": "blocked",
        "blocking_reason": "affidavit_filing_required",
        "alert_type": "affidavit_filing_required",
        "severity": "HIGH",
    }


# ---------------------------------------------------------------------------
# Node 7: Title file open (blocked on TBD-NC)
# ---------------------------------------------------------------------------

def check_node_7_title_open(title_company_assigned: str | None) -> dict:
    if title_company_assigned is None or title_company_assigned == "TBD-NC":
        return {"status": "blocked", "blocking_reason": "nc_title_company_missing"}
    return {"status": "done", "file_opened": True}


# ---------------------------------------------------------------------------
# Node 25: Photos (verification only - upstream is Alex's responsibility)
# ---------------------------------------------------------------------------

def check_node_25_photos(photos_status: str, photos_package_url: str | None) -> dict:
    """
    Photos are delivered PRE-signing by Alex's photo-gate workflow. Taylor
    only verifies - never coordinates TaskRabbit/lockbox/Thomas capture
    from this stage, that responsibility stays with Alex.
    """
    if photos_status == "DELIVERED" and photos_package_url:
        return {
            "status": "done",
            "notes": f"Photos already in deal file (URL: {photos_package_url}) - delivered pre-signing per Alex photo-gate workflow.",
        }
    return {
        "status": "blocked",
        "blocking_reason": "photos_missing_post_signature",
        "alert_type": "photos_missing_post_signature",
        "severity": "HIGH",
        "message": "Photos missing post-signature - escalate to Alex photos workflow.",
    }


# ---------------------------------------------------------------------------
# Node 28: Assignment fee disbursement verification
# ---------------------------------------------------------------------------

def check_node_28_assignment_fee(hud_disbursed_amount: float, signed_assignment_fee: float,
                                   carveout_already_received: float = 0) -> dict:
    """
    In a normal close, full assignment fee disburses at closing (EMD
    applies to purchase price). Carve-out only offsets if FP defaulted
    pre-close.
    """
    expected = signed_assignment_fee - carveout_already_received
    if abs(hud_disbursed_amount - expected) > 1.0:  # allow for rounding
        return {
            "status": "blocked",
            "alert_type": "assignment_fee_mismatch",
            "severity": "HIGH",
            "message": f"HUD disbursement ${hud_disbursed_amount:,.2f} does not match expected ${expected:,.2f}",
        }
    return {"status": "done"}


# ---------------------------------------------------------------------------
# Advance Active Pipeline (Daily 10am ET) - THE missing piece. Real,
# correct check functions for nodes 2/3/4/5/6/7/25 existed but nothing
# ever called them - every closing sat frozen at node 2 forever after
# ingest. This walks every in_progress closing and actually advances it.
#
# Nodes 8-23 are deliberately NOT included here - they depend on real
# back-and-forth with a title company (search results, insurance
# commitment, funding source confirmation, wire orchestration) that
# isn't modeled as clean structured data anywhere in this system yet.
# Advancing them automatically would mean silently marking real,
# unverified title-company work as "done" - worse than leaving them
# pending. They need either a real title-company webhook/integration
# or manual confirmation, neither of which exists today.
#
# Nodes 26-28 are correctly excluded too - per the real spec these are
# Closing Day Sweep territory only, not the daily pipeline walk.
# ---------------------------------------------------------------------------

def _touch_node(conn, closing_id: int, node_number: int, result: dict) -> None:
    """Applies a check-function result to the real closing_nodes row, and
    fires a ceo_alerts row if the check flagged one."""
    status = result.get("status")
    if status is None:
        return
    conn.execute(
        "UPDATE closing_nodes SET status = ?, blocking_reason = ?, notes = ?, last_checked_at = datetime('now') "
        "WHERE closing_id = ? AND node_number = ?",
        (status, result.get("blocking_reason"), result.get("notes"), closing_id, node_number),
    )
    if status == "blocked" and result.get("alert_type"):
        already_fired = conn.execute(
            "SELECT 1 FROM ceo_alerts WHERE closing_id = ? AND alert_type = ? "
            "AND created_at > datetime('now', '-24 hours')",
            (closing_id, result["alert_type"]),
        ).fetchone()
        if not already_fired:
            conn.execute(
                "INSERT INTO ceo_alerts (closing_id, alert_type, severity, title, message) "
                "VALUES (?, ?, ?, ?, ?)",
                (closing_id, result["alert_type"], result.get("severity", "MEDIUM"),
                 f"Node {node_number} blocked", result.get("message", result.get("blocking_reason", ""))),
            )


def advance_active_pipeline() -> list[dict]:
    conn = get_connection()
    try:
        closings = conn.execute("SELECT * FROM closings WHERE status = 'in_progress'").fetchall()
        results = []

        for c in closings:
            closing_id = c["closing_id"]
            nodes = {
                row["node_number"]: dict(row)
                for row in conn.execute(
                    "SELECT * FROM closing_nodes WHERE closing_id = ?", (closing_id,)
                ).fetchall()
            }
            touched = []

            # Node 2: assignment doc URL present (non-empty check - real
            # reachability check would need an actual HTTP fetch, not
            # available inside this scheduled job)
            if nodes.get(2, {}).get("status") != "done":
                status = "done" if c["assignment_doc_url"] else "blocked"
                _touch_node(conn, closing_id, 2, {
                    "status": status,
                    "blocking_reason": "assignment_url_unreachable" if status == "blocked" else None,
                    "alert_type": "assignment_url_unreachable" if status == "blocked" else None,
                    "severity": "HIGH",
                })
                touched.append(2)

            # Node 3: FP contact info complete
            if nodes.get(3, {}).get("status") != "done":
                complete = all([c["fp_name"], c["fp_email"], c["fp_phone"], c["fp_entity"]])
                _touch_node(conn, closing_id, 3, {
                    "status": "done" if complete else "blocked",
                    "blocking_reason": "fp_contact_incomplete" if not complete else None,
                    "alert_type": "fp_contact_incomplete" if not complete else None,
                    "severity": "MEDIUM",
                })
                touched.append(3)

            # Node 4: EMD verified (hard gate)
            if nodes.get(4, {}).get("status") != "done":
                emd = conn.execute("SELECT * FROM emd_status WHERE closing_id = ?", (closing_id,)).fetchone()
                if emd:
                    hours_since = (
                        __import__("datetime").datetime.utcnow()
                        - __import__("datetime").datetime.fromisoformat(c["started_at"])
                    ).total_seconds() / 3600
                    result = check_node_4_emd(
                        received_amount=emd["received_amount"], expected_amount=emd["expected_amount"],
                        received_at=emd["received_at"],
                        carveout_documented=bool(c["assignment_doc_url"]),  # proxy - doc on file implies carve-out language present
                        hours_since_assignment_signature=hours_since,
                    )
                    _touch_node(conn, closing_id, 4, result)
                    touched.append(4)

            # Node 5: seller signed purchase contract on file
            if nodes.get(5, {}).get("status") != "done":
                has_contract = bool(c["seller_contract_doc_url"])
                _touch_node(conn, closing_id, 5, {
                    "status": "done" if has_contract else "blocked",
                    "blocking_reason": "seller_contract_missing" if not has_contract else None,
                    "alert_type": "seller_contract_missing" if not has_contract else None,
                    "severity": "MEDIUM",
                })
                touched.append(5)

            # Node 6: Affidavit & MOA (risk-tier gated)
            if nodes.get(6, {}).get("status") != "done":
                result = check_node_6_affidavit(
                    risk_tier=c["risk_tier"],
                    affidavit_filed_confirmed=(nodes.get(6, {}).get("status") == "AFFIDAVIT_CONFIRMED"),
                )
                _touch_node(conn, closing_id, 6, result)
                touched.append(6)

            # Node 7: title file open
            if nodes.get(7, {}).get("status") != "done":
                result = check_node_7_title_open(c["title_company_assigned"])
                _touch_node(conn, closing_id, 7, result)
                touched.append(7)

            # Node 25: photos (verification only - Alex owns delivery)
            if nodes.get(25, {}).get("status") != "done":
                result = check_node_25_photos(
                    photos_status="DELIVERED" if c["photos_package_url"] else "PENDING",
                    photos_package_url=c["photos_package_url"],
                )
                _touch_node(conn, closing_id, 25, result)
                touched.append(25)

            conn.commit()
            results.append({"closing_id": closing_id, "address": c["address"], "nodes_checked": touched})

        return results
    finally:
        conn.close()
