"""
Taylor's sweeps — Pending Follow-Ups (3pm ET daily) and Closing Day
(5pm ET daily).
"""

from taylor.db.db import get_connection


def pending_followups_sweep() -> list[dict]:
    """
    For each active closing, identify the oldest still-in_progress node
    and log what kind of nudge is needed. Actual message sending is left
    to the caller (this just identifies what needs a touch).
    """
    conn = get_connection()
    try:
        active_closings = conn.execute(
            "SELECT closing_id, address FROM closings WHERE status = 'in_progress'"
        ).fetchall()

        results = []
        for closing in active_closings:
            oldest_pending = conn.execute(
                """
                SELECT node_number, status, started_at FROM closing_nodes
                WHERE closing_id = ? AND status = 'in_progress'
                ORDER BY started_at ASC LIMIT 1
                """,
                (closing["closing_id"],),
            ).fetchone()

            if oldest_pending is None:
                continue

            node_num = oldest_pending["node_number"]
            # Map node ranges to responsible-party nudge type
            if node_num in (7, 8, 9):
                nudge_type = "title_company_nudge"
            elif node_num in (14, 15, 16, 17):
                nudge_type = "fp_funding_reminder"
            elif node_num in (18, 19):
                nudge_type = "seller_doc_chase"
            else:
                nudge_type = "general_status_check"

            results.append({
                "closing_id": closing["closing_id"],
                "address": closing["address"],
                "stalled_node": node_num,
                "nudge_type": nudge_type,
            })

            conn.execute(
                """
                INSERT INTO communications_log (closing_id, direction, channel, subject)
                VALUES (?, 'outbound', 'email', ?)
                """,
                (closing["closing_id"], f"Follow-up nudge: {nudge_type} (node {node_num})"),
            )

        conn.commit()
        return results
    finally:
        conn.close()


def closing_day_sweep(today: str) -> list[dict]:
    """
    For each deal where close_date_target is today: check wire receipt,
    doc execution, recording status. Flag anything blocking.
    """
    conn = get_connection()
    try:
        todays_closings = conn.execute(
            "SELECT closing_id, address FROM closings WHERE close_date_target = ? AND status = 'in_progress'",
            (today,),
        ).fetchall()

        results = []
        for closing in todays_closings:
            blocked_nodes = conn.execute(
                "SELECT node_number, blocking_reason FROM closing_nodes WHERE closing_id = ? AND status = 'blocked'",
                (closing["closing_id"],),
            ).fetchall()

            status = "ON_TRACK" if not blocked_nodes else "BLOCKED"
            results.append({
                "closing_id": closing["closing_id"],
                "address": closing["address"],
                "status": status,
                "blockers": [dict(b) for b in blocked_nodes],
            })

            if blocked_nodes:
                for b in blocked_nodes:
                    conn.execute(
                        """
                        INSERT INTO ceo_alerts (closing_id, alert_type, severity, title, message)
                        VALUES (?, ?, 'HIGH', 'Closing day blocker', ?)
                        """,
                        (closing["closing_id"], b["blocking_reason"] or "unknown_blocker",
                         f"Closing scheduled today but node {b['node_number']} is blocked: {b['blocking_reason']}"),
                    )
                continue

            # Real nodes 34/36 - previously check_node_34_resimpli_update
            # existed but nothing ever called it or wrote a real queue
            # row. This is the actual completion check: every one of the
            # 36 nodes for this closing is done, so the deal is genuinely
            # closed - queue the real REsimpli closed-won update and
            # archive it, instead of leaving status='in_progress' forever.
            node_counts = conn.execute(
                "SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) AS done "
                "FROM closing_nodes WHERE closing_id = ?",
                (closing["closing_id"],),
            ).fetchone()

            if node_counts["total"] and node_counts["total"] == node_counts["done"]:
                conn.execute(
                    "INSERT INTO resimpli_sync_queue (closing_id, action_type, payload, status) "
                    "VALUES (?, 'mark_closed_won', ?, 'queued')",
                    (closing["closing_id"], f'{{"address": "{closing["address"]}", "closed_date": "{today}"}}'),
                )
                conn.execute(
                    "UPDATE closings SET status = 'closed', archived_at = datetime('now') WHERE closing_id = ?",
                    (closing["closing_id"],),
                )
                results[-1]["status"] = "CLOSED_AND_ARCHIVED"

        conn.commit()
        return results
    finally:
        conn.close()


def stall_detection_sweep() -> list[dict]:
    """
    Any node with started_at more than 72 hours old and status != done ->
    node_stalled_72h alert.
    """
    conn = get_connection()
    try:
        stalled = conn.execute(
            """
            SELECT closing_id, node_number FROM closing_nodes
            WHERE status != 'done'
              AND started_at IS NOT NULL
              AND started_at < datetime('now', '-72 hours')
            """
        ).fetchall()

        results = []
        for row in stalled:
            conn.execute(
                """
                INSERT INTO ceo_alerts (closing_id, alert_type, severity, title, message)
                VALUES (?, 'node_stalled_72h', 'MEDIUM', 'Node stalled', ?)
                """,
                (row["closing_id"], f"Node {row['node_number']} has been open for over 72 hours."),
            )
            results.append({"closing_id": row["closing_id"], "node_number": row["node_number"]})

        conn.commit()
        return results
    finally:
        conn.close()
