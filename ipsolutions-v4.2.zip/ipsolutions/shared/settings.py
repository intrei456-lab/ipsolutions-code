"""
Small persisted settings for site-wide cosmetic state (tagline, banner
note, accent color) - written by the Builder chat, read by the real
site header on every load.

Deliberately a JSON file, not a new DB table or migration: three
cosmetic fields don't need schema machinery, and this needs to be dead
simple to reason about since it's edited by an LLM in a loop.
"""

import json
from pathlib import Path

SETTINGS_PATH = Path(__file__).parent.parent / "brain" / "site_settings.json"

DEFAULTS = {
    "tagline": "Real Service. Real Solutions.",
    "banner_note": None,
    "accent_color": "#C9A961",
}


def get_settings() -> dict:
    if not SETTINGS_PATH.exists():
        return dict(DEFAULTS)
    try:
        with open(SETTINGS_PATH) as f:
            data = json.load(f)
        return {**DEFAULTS, **data}
    except Exception:  # noqa: BLE001 — a corrupt settings file should never break the site
        return dict(DEFAULTS)


def update_settings(updates: dict) -> dict:
    current = get_settings()
    for key in ("tagline", "banner_note", "accent_color"):
        if key in updates:
            current[key] = updates[key]
    SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(SETTINGS_PATH, "w") as f:
        json.dump(current, f, indent=2)
    return current
