"""
Fills in the LLM-authored sections of a pre-call brief (opener,
objections, box technique, voicemail, risk flags) using Claude, grounded
in the actual conversation modules we've built rather than a generic
prompt. This is the piece that turns the deterministic template skeleton
into a genuinely complete, lead-specific brief.

NOTE: requires a real ANTHROPIC_API_KEY and network access to run - not
testable in this sandbox (no network egress here). The prompt
construction and module wiring below is structurally complete and ready
to run once deployed with real credentials.
"""

from chris.conversation.call_script import OPENERS, get_opener
from chris.conversation.negotiation import PRICE_RANGE_STRATEGY
from chris.conversation.objections import OBJECTIONS
from chris.conversation.personality import PERSONALITY_PROFILES
from chris.templates.pre_call_brief import BriefInputs
from shared.llm_client import draft_content

SYSTEM_PROMPT = """You are Chris, the acquisitions agent for Intense Property Solutions LLC.
You draft pre-call briefs for Thomas using Keith Everett's acquisition
framework. You have access to a library of real scripts, objection
rebuttals, and negotiation tactics - use them as your source material,
adapted to the specific lead's numbers and situation, not generic advice.

Hard rules:
- Never use "buyers/cash buyers/investor list/wholesale/reselling" -
  use "financial partners/Equity Protection Program participants/funding
  network" instead.
- Spell "novation" correctly, never "innovation".
- Comps are always presented as ranges to sellers, never exact numbers.
- The DM gate (confirming all decision-makers) must be respected -
  never suggest naming a hard price before all parties are confirmed.
- Keep the voicemail script under 30 seconds and curiosity-based - never
  mention price or make it sound like a sales pitch.
"""


def build_context_block(inputs: BriefInputs) -> str:
    """Assembles the relevant reference material for this specific lead -
    matching personality/source rather than dumping every objection."""
    opener = get_opener(inputs.snapshot.source) or OPENERS[0]

    personality_key = None
    if inputs.personality_hypothesis:
        hypothesis_upper = inputs.personality_hypothesis.upper()
        # Check longest-matching key first so blended hypotheses like
        # "YELLOW/BLUE Blend" don't ambiguously match whichever enum
        # member happens to iterate first.
        matches = [k for k in PERSONALITY_PROFILES if k.value in hypothesis_upper]
        if matches:
            personality_key = matches[0]

    personality_block = ""
    if personality_key:
        profile = PERSONALITY_PROFILES[personality_key]
        personality_block = (
            f"\nPersonality hypothesis: {personality_key.value}\n"
            f"Coaching note: {profile.coaching_note}\n"
            f"Sample script tone: {profile.sample_script}\n"
        )

    objections_block = "\n".join(
        f"- Trigger: {', '.join(o.trigger_phrases[:2])} -> {o.rebuttal_script[:150]}..."
        for o in OBJECTIONS[:8]  # representative sample, not the whole library
    )

    return f"""LEAD DATA:
Lead #{inputs.lead_id}
Address: {inputs.snapshot.address}, {inputs.snapshot.city} {inputs.snapshot.state} {inputs.snapshot.zip_code}
Source: {inputs.snapshot.source}
Exit strategy: {inputs.exit_strategy}
Owner: {inputs.owner.name}
Offer ladder: T1 ${inputs.offer.t1_lowball:,.0f} / MAO ${inputs.offer.mao_ceiling:,.0f} / Novation ${inputs.offer.novation_target:,.0f}
{personality_block}
SUGGESTED OPENER (source-matched): {opener.text if hasattr(opener, 'text') else opener.script}

AVAILABLE OBJECTION REBUTTALS (sample - use whichever are actually likely for this lead):
{objections_block}

PRICE-RANGE STRATEGY (use if seller's number is within our MAO):
{chr(10).join(f'{s.step_number}. {s.name}: {s.script}' for s in PRICE_RANGE_STRATEGY)}
"""


def generate_llm_sections(inputs: BriefInputs) -> dict:
    """
    Returns a dict with keys: call_opener, objection_handlers,
    box_technique, voicemail_script, risk_flags - each drafted by Claude
    using this lead's specific data + the reference material above.
    """
    context = build_context_block(inputs)

    user_prompt = f"""{context}

Using the lead data and reference material above, draft the following
5 sections of this lead's pre-call brief. Be specific to THIS lead's
numbers and situation - don't write generic advice.

1. CALL OPENER - personalized with owner name and address
2. OBJECTION HANDLERS - the 3 most likely objections for this specific
   lead, with rebuttals customized to their actual numbers
3. BOX TECHNIQUE SEQUENCE - using this brief's actual T1/MAO numbers
4. VOICEMAIL SCRIPT - under 30 seconds, curiosity-based only
5. RISK FLAGS - specific to what's known about this lead

Format your response with clear section headers matching the 5 items above.
"""

    result = draft_content(SYSTEM_PROMPT, user_prompt, max_tokens=3000)
    return result
