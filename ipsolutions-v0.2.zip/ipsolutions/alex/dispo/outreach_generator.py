"""
Alex's outreach message drafting — uses Claude to draft FP-facing emails
(Mode 1 buy-box collection, deal-specific blast, verification follow-up),
grounded in the real templates/mechanics we've built rather than a
generic prompt. Every draft passes through shared/llm_client's automatic
terminology + spread-invisibility checks before being returned.
"""

from dataclasses import dataclass

from alex.fp_hunt.proactive import BUY_BOX_QUESTIONS
from alex.fp_network.tiering import FinancialPartner, compute_dispo_tier
from shared.llm_client import draft_content
from shared.rendering import strip_internal_fields

SYSTEM_PROMPT = """You are Alex, the dispositions agent for Intense Property
Solutions LLC. You draft outreach emails to financial partners (FPs) -
real estate investors and cash buyers. You have real templates and
mechanics to draw from - use them as your foundation, personalized to
the specific FP and deal, not generic copy.

Hard rules:
- NEVER reveal contract_price, assignment_fee, or the spread. Only
  fp_facing_price (contract_price + assignment_fee) may be shown.
- NEVER use internal matching language in FP-facing copy: no "your
  preferred ZIPs", "your capacity aligns", "your response time", "your
  reputation tier", "cold cash partner", "private money partner", or
  similar phrases that reveal how the FP was selected internally.
- Tone is always peer-to-peer and opportunity-first: "bringing this to
  you first" - never CRM-first or transactional-sounding.
- Mode 1 (proactive/buy-box) outreach leads with the 5 buy-box
  questions, not a pitch about the company.
- Use "financial partner" / "funding network" terminology, never "cash
  buyer" or "investor list" in the FP's own copy (this is the internal
  term we use to talk ABOUT them, not language we use TO them - to them
  they're just "you" / the recipient).
"""


@dataclass
class OutreachContext:
    fp_name: str
    fp_company: str | None = None
    outreach_type: str = "PROACTIVE"  # PROACTIVE / DEAL_SPECIFIC / VERIFICATION / POST_CLOSE_DEEPEN
    deal_address: str | None = None
    deal_zip: str | None = None
    fp_facing_price: float | None = None
    arv: float | None = None
    close_date_target: str | None = None
    known_buy_box_zips: list[str] | None = None
    is_vip: bool = False


def build_context_block(ctx: OutreachContext) -> str:
    lines = [f"FP name: {ctx.fp_name}"]
    if ctx.fp_company:
        lines.append(f"Company: {ctx.fp_company}")
    lines.append(f"Outreach type: {ctx.outreach_type}")

    if ctx.outreach_type == "PROACTIVE":
        lines.append("\nBUY-BOX QUESTIONS TO ASK (lead with these, not a company pitch):")
        for i, q in enumerate(BUY_BOX_QUESTIONS, 1):
            lines.append(f"{i}. {q}")
        if ctx.is_vip:
            lines.append('\nFraming to include: "You\'ll be in our VIP group - you see deals first before they go wider."')

    elif ctx.outreach_type == "DEAL_SPECIFIC":
        # Build the safe payload - strip_internal_fields ensures contract_price/
        # assignment_fee never even make it into the prompt context, not just
        # the final output.
        deal_payload = strip_internal_fields({
            "address": ctx.deal_address,
            "zip": ctx.deal_zip,
            "fp_facing_price": ctx.fp_facing_price,
            "arv": ctx.arv,
            "close_date_target": ctx.close_date_target,
        })
        lines.append(f"\nDEAL DETAILS (fp_facing_price is the ONLY price to mention):")
        for k, v in deal_payload.items():
            if v is not None:
                lines.append(f"  {k}: {v}")

    elif ctx.outreach_type == "VERIFICATION":
        lines.append(
            "\nAsk for: (1) proof of funds - bank statement, LOC letter, or "
            "HM pre-approval, (2) last closed deal address + date, "
            "(3) direct ask: are you the end buyer or wholesaling this?"
        )

    elif ctx.outreach_type == "POST_CLOSE_DEEPEN":
        lines.append(
            f"\nThank them for closing on {ctx.deal_address}. Ask for updated "
            f"buy-box info and a referral ('who else in your network does "
            f"deals in [area]?')."
        )

    return "\n".join(lines)


def draft_outreach_email(ctx: OutreachContext) -> dict:
    context = build_context_block(ctx)
    user_prompt = f"""{context}

Draft a short, personalized outreach email for this financial partner.
Keep it brief - 3-5 sentences. Match the outreach type's purpose exactly
as described above. Include a subject line.
"""
    return draft_content(SYSTEM_PROMPT, user_prompt, max_tokens=500)
