-- Taylor (Transaction Coordinator) database schema.
-- Cross-agent reads: Alex's handoffs/assignments_signed/emd_tracking (read-only).
-- Real 14-table list confirmed against the live Twin build.

CREATE TABLE IF NOT EXISTS closings (
    closing_id INTEGER PRIMARY KEY AUTOINCREMENT,
    deal_id INTEGER,                            -- FK to Alex's deals.deal_id (cross-db, not enforced)
    address TEXT,
    city TEXT,
    state TEXT,
    zip TEXT,
    fp_name TEXT,
    fp_email TEXT,
    fp_phone TEXT,
    fp_entity TEXT,
    fp_ein TEXT,
    emd_amount REAL,
    emd_received_at TEXT,
    title_company_assigned TEXT,
    current_node INTEGER DEFAULT 1,             -- 1-36
    status TEXT DEFAULT 'in_progress',           -- in_progress/closed/dead
    risk_tier TEXT DEFAULT 'STANDARD',
    close_date_target TEXT,
    hud_url TEXT,
    recorded_at TEXT,
    archived_at TEXT,
    started_at TEXT DEFAULT (datetime('now')),
    funded_at TEXT,
    days_to_close INTEGER,
    exit_strategy TEXT DEFAULT 'WHOLESALE_ASSIGNMENT',
    closing_method TEXT DEFAULT 'STANDARD_ASSIGNMENT',
    assignment_fee_collected REAL,
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS node_template (
    node_number INTEGER PRIMARY KEY,            -- 1-36
    title TEXT NOT NULL,
    phase TEXT NOT NULL                         -- PRE_CLOSING / CONTRACT_DOCS / CLOSING / POST_CLOSING
);

CREATE TABLE IF NOT EXISTS closing_nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    closing_id INTEGER NOT NULL REFERENCES closings(closing_id),
    node_number INTEGER NOT NULL,
    status TEXT DEFAULT 'pending',               -- pending/in_progress/done/blocked
    blocking_reason TEXT,
    started_at TEXT,
    completed_at TEXT,
    last_checked_at TEXT,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS title_company_directory (
    state TEXT PRIMARY KEY,
    primary_company TEXT,
    secondary_company TEXT,
    contact_name TEXT,
    contact_email TEXT,
    contact_phone TEXT
);

CREATE TABLE IF NOT EXISTS title_assignments (
    assignment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    closing_id INTEGER NOT NULL REFERENCES closings(closing_id),
    title_company TEXT,
    file_opened_at TEXT,
    title_search_ordered_at TEXT,
    title_insurance_commitment_ordered_at TEXT
);

CREATE TABLE IF NOT EXISTS emd_status (
    emd_id INTEGER PRIMARY KEY AUTOINCREMENT,
    closing_id INTEGER NOT NULL REFERENCES closings(closing_id),
    expected_amount REAL,
    received_amount REAL,
    received_at TEXT,
    emd_tier TEXT,
    expected_by TEXT,                            -- 24h after assignment signature
    non_refundable_portion REAL DEFAULT 2000,
    applies_to_purchase_price REAL,
    refundable_status TEXT DEFAULT 'HELD'
);

CREATE TABLE IF NOT EXISTS closing_documents (
    doc_id INTEGER PRIMARY KEY AUTOINCREMENT,
    closing_id INTEGER NOT NULL REFERENCES closings(closing_id),
    doc_type TEXT,                               -- Assignment/A&MOA/Termination/Extension/Auth-Release-Escrow
    status TEXT DEFAULT 'draft',                 -- draft/sent/executed/recorded
    doc_url TEXT,
    recorded_at TEXT,
    wire_received_at TEXT
);

CREATE TABLE IF NOT EXISTS closing_kpi (
    kpi_date TEXT,
    rollup_type TEXT,                            -- daily/weekly
    active_deal_count INTEGER DEFAULT 0,
    total_assignment_fee_at_risk REAL,
    closed_deals_count INTEGER DEFAULT 0,
    total_assignment_fees_banked REAL,
    avg_days_assignment_to_funded REAL,
    closing_rate REAL,
    emd_receipt_rate REAL,
    photos_delivery_rate REAL,
    PRIMARY KEY (kpi_date, rollup_type)
);

CREATE TABLE IF NOT EXISTS ceo_alerts (
    alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
    closing_id INTEGER REFERENCES closings(closing_id),
    alert_type TEXT NOT NULL,
    severity TEXT DEFAULT 'MEDIUM',              -- HIGH/MEDIUM/LOW
    title TEXT,
    message TEXT,
    fired_at TEXT DEFAULT (datetime('now')),
    email_sent_at TEXT
);

CREATE TABLE IF NOT EXISTS contract_gap_alerts (
    alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
    closing_id INTEGER REFERENCES closings(closing_id),
    contract_type TEXT,                          -- MD_HOLD_BACK / SUBTO / NC_CASH / NC_VACANT_LAND
    resolved INTEGER DEFAULT 0,
    fired_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS communications_log (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    closing_id INTEGER REFERENCES closings(closing_id),
    direction TEXT DEFAULT 'outbound',
    channel TEXT,                                -- email/phone_text/webhook
    recipient TEXT,
    subject TEXT,
    template_used TEXT,
    sent_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS resimpli_sync_queue (
    queue_id INTEGER PRIMARY KEY AUTOINCREMENT,
    closing_id INTEGER REFERENCES closings(closing_id),
    action_type TEXT,
    payload TEXT,                                -- JSON
    status TEXT DEFAULT 'queued',
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS taylor_handoffs (
    handoff_id INTEGER PRIMARY KEY AUTOINCREMENT,
    closing_id INTEGER REFERENCES closings(closing_id),
    direction TEXT DEFAULT 'OUTBOUND_TO_ALEX_POST_CLOSE',
    status TEXT DEFAULT 'POST_CLOSE_SIGNAL',
    fp_id INTEGER,
    fp_name TEXT,
    fp_contact TEXT,
    deal_zip TEXT,
    deal_state TEXT,
    assignment_fee_collected REAL,
    close_date_actual TEXT,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_closings_status ON closings(status);
CREATE INDEX IF NOT EXISTS idx_closings_node ON closings(current_node);
CREATE INDEX IF NOT EXISTS idx_closing_nodes_closing ON closing_nodes(closing_id);
CREATE INDEX IF NOT EXISTS idx_closing_nodes_status ON closing_nodes(status);
