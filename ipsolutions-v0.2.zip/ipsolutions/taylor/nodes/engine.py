"""
Taylor's node engine — New Handoff Ingest (Step 1) and the node-by-node
advancement rules for the nodes with real conditional logic (most nodes
are simple "confirm X" checks; a few have hard gates worth encoding
explicitly).
"""

from dataclasses import dataclass, field

from shared.config import TITLE_COMPANY_DIRECTORY, emd_tier_for_close_window
from taylor.db.db import get_connection
from taylor.nodes.node_template import NODE_TEMPLATE

REQUIRED_HANDOFF_FIELDS = [
    "assignment_signed_doc_url", "fp_name", "fp_email", "fp_phone",
    "fp_entity", "emd_amount", "emd_received_at", "close_date_target",
    "photos_package_url", "zip", "state", "address",
]


@dataclass
class HandoffValidationResult:
    valid: bool
    missing_fields: list[str] = field(default_factory=list)


def validate_handoff(handoff_payload: dict) -> HandoffValidationResult:
    missing = [f for f in REQUIRED_HANDOFF_FIELDS if not handoff_payload.get(f)]
    return HandoffValidationResult(valid=len(missing) == 0, missing_fields=missing)


def ingest_new_handoff(handoff_payload: dict) -> dict:
    """
    Step 1: New Handoff Ingest. Validates required fields, opens a
    closings row at node 1 (done) / node 2 (in_progress), seeds all 36
    node rows, resolves title company by state, and handles the NC
    TBD-title-company hold.
    """
    validation = validate_handoff(handoff_payload)
    if not validation.valid:
        return {
            "accepted": False,
            "alert_type": "handoff_missing_fields",
            "severity": "HIGH",
            "message": f"Missing required fields: {', '.join(validation.missing_fields)}",
        }

    conn = get_connection()
    try:
        cur = conn.execute(
            """
            INSERT INTO closings (
                deal_id, address, city, state, zip, fp_name, fp_email, fp_phone,
                fp_entity, emd_amount, emd_received_at, close_date_target,
                current_node, status, risk_tier
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 2, 'in_progress', ?)
            """,
            (
                handoff_payload.get("deal_id"), handoff_payload["address"],
                handoff_payload.get("city"), handoff_payload["state"], handoff_payload["zip"],
                handoff_payload["fp_name"], handoff_payload["fp_email"], handoff_payload["fp_phone"],
                handoff_payload["fp_entity"], handoff_payload["emd_amount"],
                handoff_payload["emd_received_at"], handoff_payload["close_date_target"],
                handoff_payload.get("risk_tier", "STANDARD"),
            ),
        )
        closing_id = cur.lastrowid

        # Seed all 36 node rows; node 1 done (handoff received), node 2 in_progress
        for node in NODE_TEMPLATE:
            status = "done" if node.number == 1 else ("in_progress" if node.number == 2 else "pending")
            conn.execute(
                "INSERT INTO closing_nodes (closing_id, node_number, status, started_at) "
                "VALUES (?, ?, ?, datetime('now'))",
                (closing_id, node.number, status),
            )

        # Resolve title company
        state = handoff_payload["state"]
        title_info = TITLE_COMPANY_DIRECTORY.get(state, {})
        title_company = title_info.get("primary")

        alerts_fired = []
        if state == "NC" and title_company is None:
            conn.execute(
                "UPDATE closings SET title_company_assigned = 'TBD-NC' WHERE closing_id = ?",
                (closing_id,),
            )
            conn.execute(
                """
                INSERT INTO ceo_alerts (closing_id, alert_type, severity, title, message)
                VALUES (?, 'nc_title_company_missing', 'HIGH', 'NC title company needed',
                        'NC deal arrived - Thomas must designate a title company before node 7 can proceed.')
                """,
                (closing_id,),
            )
            alerts_fired.append("nc_title_company_missing")
        else:
            conn.execute(
                "UPDATE closings SET title_company_assigned = ? WHERE closing_id = ?",
                (title_company, closing_id),
            )

        # EMD tier + expected amount
        days_to_close = handoff_payload.get("days_to_close", 14)
        tier = emd_tier_for_close_window(days_to_close)
        conn.execute(
            """
            INSERT INTO emd_status (closing_id, expected_amount, received_amount, received_at,
                                     emd_tier, non_refundable_portion, applies_to_purchase_price)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                closing_id, tier.get("total", tier.get("total_min")), handoff_payload["emd_amount"],
                handoff_payload["emd_received_at"], str(days_to_close),
                tier.get("non_refundable", 2000), tier.get("applies_to_price"),
            ),
        )

        conn.commit()
        return {"accepted": True, "closing_id": closing_id, "alerts_fired": alerts_fired}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Node 4: EMD verification (hard gate)
# ---------------------------------------------------------------------------

def check_node_4_emd(
    received_amount: float | None,
    expected_amount: float,
    received_at: str | None,
    carveout_documented: bool,
    hours_since_assignment_signature: float,
) -> dict:
    """
    Mark done if received >= expected AND received_at is set AND the $2k
    non-refundable carve-out is documented in the contract. If 24h have
    passed since assignment signature with no wire in escrow -> HIGH alert,
    mark blocked.
    """
    if received_amount is not None and received_amount >= expected_amount and received_at and carveout_documented:
        return {"status": "done"}

    if hours_since_assignment_signature > 24:
        return {
            "status": "blocked",
            "blocking_reason": "emd_not_received_24h",
            "alert_type": "emd_not_received_24h",
            "severity": "HIGH",
        }

    return {"status": "pending"}


# ---------------------------------------------------------------------------
# Node 6: Affidavit & MOA filing (risk-tier-gated)
# ---------------------------------------------------------------------------

def check_node_6_affidavit(risk_tier: str, affidavit_filed_confirmed: bool) -> dict:
    """
    STANDARD (default, ~80%+ of deals) -> auto-complete, no filing needed.
    PROTECT_SPREAD -> blocked until Thomas confirms county filing complete.
    """
    if risk_tier == "STANDARD":
        return {
            "status": "done",
            "notes": "Not required - clean transaction, no protect-spread flag. Affidavit & MOA filing skipped.",
        }

    if affidavit_filed_confirmed:
        return {"status": "done"}

    return {
        "status": "blocked",
        "blocking_reason": "affidavit_filing_required",
        "alert_type": "affidavit_filing_required",
        "severity": "HIGH",
    }


# ---------------------------------------------------------------------------
# Node 7: Title file open (blocked on TBD-NC)
# ---------------------------------------------------------------------------

def check_node_7_title_open(title_company_assigned: str | None) -> dict:
    if title_company_assigned is None or title_company_assigned == "TBD-NC":
        return {"status": "blocked", "blocking_reason": "nc_title_company_missing"}
    return {"status": "done", "file_opened": True}


# ---------------------------------------------------------------------------
# Node 25: Photos (verification only - upstream is Alex's responsibility)
# ---------------------------------------------------------------------------

def check_node_25_photos(photos_status: str, photos_package_url: str | None) -> dict:
    """
    Photos are delivered PRE-signing by Alex's photo-gate workflow. Taylor
    only verifies - never coordinates TaskRabbit/lockbox/Thomas capture
    from this stage, that responsibility stays with Alex.
    """
    if photos_status == "DELIVERED" and photos_package_url:
        return {
            "status": "done",
            "notes": f"Photos already in deal file (URL: {photos_package_url}) - delivered pre-signing per Alex photo-gate workflow.",
        }
    return {
        "status": "blocked",
        "blocking_reason": "photos_missing_post_signature",
        "alert_type": "photos_missing_post_signature",
        "severity": "HIGH",
        "message": "Photos missing post-signature - escalate to Alex photos workflow.",
    }


# ---------------------------------------------------------------------------
# Node 28: Assignment fee disbursement verification
# ---------------------------------------------------------------------------

def check_node_28_assignment_fee(hud_disbursed_amount: float, signed_assignment_fee: float,
                                   carveout_already_received: float = 0) -> dict:
    """
    In a normal close, full assignment fee disburses at closing (EMD
    applies to purchase price). Carve-out only offsets if FP defaulted
    pre-close.
    """
    expected = signed_assignment_fee - carveout_already_received
    if abs(hud_disbursed_amount - expected) > 1.0:  # allow for rounding
        return {
            "status": "blocked",
            "alert_type": "assignment_fee_mismatch",
            "severity": "HIGH",
            "message": f"HUD disbursement ${hud_disbursed_amount:,.2f} does not match expected ${expected:,.2f}",
        }
    return {"status": "done"}
