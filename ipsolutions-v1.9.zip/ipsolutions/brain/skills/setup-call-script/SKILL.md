---
name: setup-call-script
description: Use for the vetting call that happens after an agent gives an address (Tier 1) - deciding whether a lead is worth pursuing before underwriting or bringing to a JV partner. Distinct from the initial outreach script (agent-outreach) - this is the call that comes after.
---

# Skill: The Setup Call

Source: Matt Beard, real estate agent outreach training. Formerly called
the "second call" - renamed "setup call" because its real job is
setting up the negotiation, not closing it.

## The single most important rule: this call is not for locking up the deal

**The goal of this call is to diagnose, not negotiate.** Before the
call, the operator does not go in hoping to get a signed contract -
removing that pressure is what makes the call work. The only question
this call answers is: **does this lead make sense to pursue further -
worth underwriting, worth bringing to a JV partner or funding
source?** Speed matters: this call should happen within roughly six
hours of a lead going Tier 1, ideally much faster.

## The opening

Reference three things in order: (1) who they already talked to /
where the lead came from, (2) your own role ("I do the underwriting"),
(3) a direct question about where they're at in the process.

> "Hey, this is [name], I work with [team member they already talked
> to]. I think you guys were going back and forth on a property off of
> [street] - I do the underwriting over here and got the notes on it,
> figured I'd give you a call to see where you guys are at in the
> process."

This holds a specific frame: positions the caller as the person who
actually makes buying decisions (not a screener), and moves
immediately into finding out where things stand rather than pitching.

## Red flags vs green flags (decide fast, don't linger on bad leads)

**Red flags - deprioritize or drop:**
- They mention multiple offers already on the table, or language
  implying a bidding war ("submit your best and final by this
  afternoon") - a real competitive situation is a bad fit, since this
  business does not compete in bidding wars and does not chase deals
  with strong existing offers
- The seller won't entertain any discount at all regardless of terms

**Green flags - worth continuing:**
- They want convenience, are tired of the process, seem generally open
  to an as-is offer

**On red-flag multiple-offer claims specifically**: treat with real
skepticism, not automatic belief. Most agents with genuinely strong
offers they intend to accept don't advertise the exact numbers - an
agent throwing out specific competing numbers unprompted is often
trying to create urgency rather than reporting a real situation. This
doesn't mean assume they're lying, but don't let the claim alone kill
a conversation or change strategy - stick to the normal process.

## The condition and ARV questions - and the rule that governs both

Ask two questions in sequence:
1. "What do you think needs to be done to bring it to maximum value?"
2. "If it were fully renovated, what do you think it'd be worth?"

These serve two purposes at once: gathering real condition/ARV
information, and validating the agent's professional opinion - which
matters more than it sounds. Do not act like a know-it-all here.

**Hard rule: never argue their number, never a "comp battle."** If
they say the ARV is $500k and your own number says $450k, the response
is "okay, cool" - not a counter-argument, not asking them to justify
it with their own comps. Correcting them or trying to win an ARV
debate does not get the deal; it just damages the relationship and the
frame the caller is trying to hold.

## Explaining how the business runs its numbers

After validating their opinion, explain the math plainly and honestly
- this is not a negotiating trick, it's genuinely how the offer gets
built:

> "That makes sense given it needs updating. Here's how we look at
> it - if it needs the kitchen and bathrooms redone, that's probably
> $40-50k in work. We budget assuming a 15% profit margin on the sale
> price, and we always assume it'll cost a bit more than expected,
> because flips always do. So if we think we can sell it for $400k,
> we're budgeting like it'll only be a $60k margin, not more."

This explanation is what makes the eventual offer feel like real math
instead of an arbitrary lowball, and gives the agent something
credible to relay to their seller.

## Never give an exact number on this call

After asking if there are other offers on the table, the caller does
**not** quote a firm price. The actual line:

> "I don't know if I can pay all the way up to what you mentioned. I
> have a good feeling I might be a little under it. Let me go do my
> homework - should I call you back once the dust settles, or wait
> till tomorrow? What do you recommend?"

This buys time to actually underwrite properly, avoids anchoring
against yourself, and gives the agent time to go find out the seller's
*real* bottom line - which is very often lower than what they first
claimed. People tend to state a number and believe it's firm ("truth
bias" - the default assumption that what someone says is accurate) -
but initial "bottom dollar" figures are frequently negotiable once a
real offer is on the table. Don't let a stated bottom line alone
determine whether to proceed; stick to the underwriting and offer
process regardless of what number was mentioned upfront.

## After the call: three outcomes, decide fast

1. **Worth pursuing** - green flags, real information gathered → move
   to underwriting / bring to a JV partner or funding source
2. **Not ready yet** - missing something needed (e.g. no photos yet) →
   follow up once that's resolved
3. **Not a fit** - red flags, no realistic path → thank them, move on
   immediately, don't feel bad about it

**The discipline that matters most**: spend time on the right leads,
disqualify the wrong ones fast and without guilt. The more time spent
on leads that were never going to work, the fewer real deals get
closed - "how good of a lead is it," never a binary good/bad
judgment, but a fast go/no-go call.
