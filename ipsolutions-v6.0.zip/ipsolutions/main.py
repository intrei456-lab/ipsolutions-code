"""
IPSolutions agent system - entry point.

Runs a FastAPI app (for webhooks + manual triggers) alongside an
in-process APScheduler instance covering all three agents' scheduled
jobs. Each agent has its own SQLite database file; cross-agent reads
happen via direct same-box file access (see each agent's handoff/ingest
modules).

Run locally for testing:
    uvicorn main:app --reload --port 8000

Trigger jobs manually while testing:
    curl -X POST http://localhost:8000/chris/scouts/tax_delinquent_md/run
    curl -X POST http://localhost:8000/alex/kpi/run
    curl -X POST http://localhost:8000/taylor/sweeps/pending_followups/run

Deploy: see README.md for the systemd service setup on a VPS.
"""

from contextlib import asynccontextmanager
from datetime import date

from dotenv import load_dotenv
load_dotenv()  # Must run before any module reads os.environ (e.g. shared/llm_client.py)

import base64
import os
import secrets

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel
from starlette.middleware.base import BaseHTTPMiddleware

from chris.db.db import init_db as chris_init_db, seed_market_zips
from chris.scouts import tax_delinquent_md
from alex.db.db import init_db as alex_init_db
from alex.dispo.kpi_rollup import compute_daily_kpi as alex_compute_kpi
from taylor.db.db import init_db as taylor_init_db, seed_node_template, seed_title_company_directory
from taylor.sweeps.daily_sweeps import pending_followups_sweep, closing_day_sweep, stall_detection_sweep
from taylor.nodes.kpi_and_archive import compute_kpi as taylor_compute_kpi

scheduler = AsyncIOScheduler(timezone="America/New_York")


# ---------------------------------------------------------------------------
# Chris's scheduled jobs
# ---------------------------------------------------------------------------

def run_chris_scout_pass_a():
    """7am ET daily. Currently runs the one live scout module; more get
    added here as they're built (see architecture doc build order)."""
    print("[scheduler] Chris: 7am scout pass A")
    tax_delinquent_md.run()
    # TODO as more scouts come online:
    # water_shutoff_md.run()
    # code_violations_md.run()
    # fl_county_rotation.run()
    # d4d_zip_rotation.run()


def run_daily_briefing():
    """
    7:30am ET daily - Thomas's morning digest across all three agents,
    matching what Matt Beard demonstrates as the crown jewel of his own
    build: real live data, AI-narrated, sent so it's waiting when he
    wakes up rather than something he has to go check for.
    """
    print("[scheduler] Sending daily briefing")
    from shared.daily_briefing import send_daily_briefing

    result = send_daily_briefing(use_ai_narration=True)
    print(f"[scheduler] Daily briefing sent: {result['sent']}")


# ---------------------------------------------------------------------------
# Alex's scheduled jobs
# ---------------------------------------------------------------------------

def run_alex_daily_kpi():
    """End-of-day KPI rollup for Alex."""
    print("[scheduler] Alex: daily KPI rollup")
    alex_compute_kpi()
    # TODO: Mode 1/2 pipeline review (9am), touch sweep (4pm) once the
    # actual outreach-sending loop is wired to a real channel (email/SMS provider).


# ---------------------------------------------------------------------------
# Taylor's scheduled jobs
# ---------------------------------------------------------------------------

def run_taylor_pending_followups():
    """3pm ET daily."""
    print("[scheduler] Taylor: pending follow-ups sweep")
    pending_followups_sweep()


def run_taylor_closing_day():
    """5pm ET daily."""
    print("[scheduler] Taylor: closing day sweep")
    today = date.today().isoformat()
    closing_day_sweep(today)
    stall_detection_sweep()
    taylor_compute_kpi("daily")


def run_chris_seller_followup_dispatch():
    """
    10am ET daily. The real send side of chris/followup/cadence.py's
    timing logic - finds every follow-up that's actually due and places
    a real Vapi voice call. Before this job existed, cadence.py computed
    correct follow-up timing that nothing ever acted on.
    """
    from chris.followup.dispatcher import run_seller_followup_dispatch

    print("[scheduler] Chris: seller follow-up dispatch")
    result = run_seller_followup_dispatch()
    print(f"[scheduler] Chris: follow-up dispatch result: {result}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup - initialize all three agent databases
    chris_init_db()
    seed_market_zips()
    alex_init_db()
    taylor_init_db()
    seed_node_template()
    seed_title_company_directory()

    scheduler.add_job(run_chris_scout_pass_a, CronTrigger(hour=7, minute=0),
                       id="chris_scout_pass_a", replace_existing=True)
    scheduler.add_job(run_daily_briefing, CronTrigger(hour=7, minute=30),
                       id="daily_briefing", replace_existing=True)
    scheduler.add_job(run_alex_daily_kpi, CronTrigger(hour=20, minute=0),
                       id="alex_daily_kpi", replace_existing=True)
    scheduler.add_job(run_taylor_pending_followups, CronTrigger(hour=15, minute=0),
                       id="taylor_pending_followups", replace_existing=True)
    scheduler.add_job(run_taylor_closing_day, CronTrigger(hour=17, minute=0),
                       id="taylor_closing_day", replace_existing=True)
    scheduler.add_job(run_chris_seller_followup_dispatch, CronTrigger(hour=10, minute=0),
                       id="chris_seller_followup_dispatch", replace_existing=True)
    scheduler.start()

    print("[startup] All 3 agent DBs initialized. Scheduler running:")
    print("  - Chris scout pass A: 7am ET")
    print("  - Daily briefing: 7:30am ET")
    print("  - Alex daily KPI: 8pm ET")
    print("  - Taylor pending follow-ups: 3pm ET")
    print("  - Taylor closing day + stall detection + KPI: 5pm ET")
    yield
    # Shutdown
    scheduler.shutdown()


class BasicAuthMiddleware(BaseHTTPMiddleware):
    """
    Site-wide HTTP Basic Auth. Credentials come from SITE_USERNAME /
    SITE_PASSWORD in .env - both blank (the default until Thomas sets
    them) means the site stays open, since failing open is safer than
    silently locking him out the moment this deploys with no env vars
    set yet. Once both are set, every request - API and static files
    alike - needs them via the browser's built-in login prompt.
    """

    async def dispatch(self, request: Request, call_next):
        expected_user = os.environ.get("SITE_USERNAME")
        expected_pass = os.environ.get("SITE_PASSWORD")
        if not expected_user or not expected_pass:
            return await call_next(request)

        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Basic "):
            try:
                decoded = base64.b64decode(auth_header[6:]).decode("utf-8")
                username, _, password = decoded.partition(":")
                if secrets.compare_digest(username, expected_user) and secrets.compare_digest(password, expected_pass):
                    return await call_next(request)
            except Exception:  # noqa: BLE001 — malformed header should just fall through to 401
                pass

        return Response(
            content="Authentication required.",
            status_code=401,
            headers={"WWW-Authenticate": 'Basic realm="IPSolutions Pipeline Command"'},
        )


app = FastAPI(title="IPSolutions Agents", lifespan=lifespan)
app.add_middleware(BasicAuthMiddleware)
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def dashboard():
    return FileResponse("static/index.html")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/workspace/daily_briefing/send_now")
def trigger_daily_briefing(use_ai_narration: bool = True):
    """On-demand test trigger, so this doesn't need to wait until 7:30am
    to verify it actually works."""
    from shared.daily_briefing import send_daily_briefing

    result = send_daily_briefing(use_ai_narration=use_ai_narration)
    return result


def _load_brain() -> str:
    """
    Loads the actual business knowledge from /brain - AGENTS.md, all
    skills (folder + SKILL.md, per Anthropic's Agent Skills open
    standard), all context files, and the memory file. This is the
    'Thomas Moyd Brain': the portable business knowledge that should
    survive a platform switch, not just live in Python data structures.
    """
    import os

    brain_dir = os.path.join(os.path.dirname(__file__), "brain")
    parts = []

    agents_path = os.path.join(brain_dir, "AGENTS.md")
    if os.path.exists(agents_path):
        with open(agents_path) as f:
            parts.append("=== AGENTS.md ===\n" + f.read())

    # Skills: each is its own folder with a SKILL.md inside
    skills_dir = os.path.join(brain_dir, "skills")
    if os.path.isdir(skills_dir):
        for skill_name in sorted(os.listdir(skills_dir)):
            skill_md_path = os.path.join(skills_dir, skill_name, "SKILL.md")
            if os.path.exists(skill_md_path):
                with open(skill_md_path) as f:
                    parts.append(f"=== skills/{skill_name}/SKILL.md ===\n" + f.read())

    # Context: flat markdown files
    context_dir = os.path.join(brain_dir, "context")
    if os.path.isdir(context_dir):
        for filename in sorted(os.listdir(context_dir)):
            if filename.endswith(".md"):
                with open(os.path.join(context_dir, filename)) as f:
                    parts.append(f"=== context/{filename} ===\n" + f.read())

    # Raw source transcripts - the actual training material, kept
    # verbatim rather than only distilled into skills. This exists so
    # every agent has the primary source directly, not just Claude's
    # summary of it - if a skill file missed a real detail, the raw
    # transcript is still right here to catch it.
    transcripts_dir = os.path.join(brain_dir, "transcripts")
    if os.path.isdir(transcripts_dir):
        for filename in sorted(os.listdir(transcripts_dir)):
            if filename.endswith(".md"):
                with open(os.path.join(transcripts_dir, filename)) as f:
                    parts.append(f"=== transcripts/{filename} ===\n" + f.read())

    # Memory: single file, per Remy Gaskell's framework
    memory_path = os.path.join(brain_dir, "memory", "memory.md")
    if os.path.exists(memory_path):
        with open(memory_path) as f:
            parts.append("=== memory/memory.md ===\n" + f.read())

    return "\n\n".join(parts)


def _gather_workspace_context() -> str:
    """Pulls a live snapshot across all three agents' real databases so the
    workspace chat has actual current numbers, not stale training knowledge."""
    from chris.db.db import get_connection as chris_conn
    from alex.db.db import get_connection as alex_conn
    from taylor.db.db import get_connection as taylor_conn

    lines = []
    try:
        conn = chris_conn()
        leads = conn.execute("SELECT COUNT(*) c FROM leads WHERE is_test_data = 0").fetchone()["c"]
        conn.close()
        lines.append(f"Chris: {leads} lead(s) in the system.")
    except Exception:  # noqa: BLE001
        lines.append("Chris: database not yet queryable.")

    try:
        conn = alex_conn()
        deals = conn.execute("SELECT COUNT(*) c FROM deals").fetchone()["c"]
        fps = conn.execute("SELECT COUNT(*) c FROM financial_partners WHERE is_test_data = 0").fetchone()["c"]
        conn.close()
        lines.append(f"Alex: {deals} deal(s) in the pipeline, {fps} financial partners loaded.")
    except Exception:  # noqa: BLE001
        lines.append("Alex: database not yet queryable.")

    try:
        conn = taylor_conn()
        closings = conn.execute("SELECT COUNT(*) c FROM closings").fetchone()["c"]
        conn.close()
        lines.append(f"Taylor: {closings} closing(s) in the pipeline.")
    except Exception:  # noqa: BLE001
        lines.append("Taylor: database not yet queryable.")

    try:
        from shared.brain_loader import load_memory

        conn = taylor_conn()
        memory_text = load_memory()
        closed_rows = conn.execute(
            "SELECT address FROM closings WHERE status = 'closed' AND archived_at IS NOT NULL "
            "ORDER BY archived_at DESC LIMIT 10"
        ).fetchall()
        conn.close()
        pending = [r["address"] for r in closed_rows if r["address"] not in memory_text]
        if pending:
            lines.append(
                f"PENDING REFLECTIONS: {len(pending)} closed deal(s) have no lesson saved yet "
                f"({', '.join(pending[:3])}{'...' if len(pending) > 3 else ''}). "
                f"If it fits naturally in conversation, ask Thomas if there's anything worth "
                f"saving from one of these before he leaves the chat."
            )
    except Exception:  # noqa: BLE001
        pass

    return "\n".join(lines)


class WorkspaceChatMessage(BaseModel):
    role: str  # "user" or "assistant"
    content: str


class WorkspaceChatRequest(BaseModel):
    messages: list[WorkspaceChatMessage]


class MemoryLessonRequest(BaseModel):
    lesson: str


@app.post("/workspace/memory/add")
def add_memory_lesson(req: MemoryLessonRequest):
    """Appends a new lesson to brain/memory/memory.md - this is how the
    brain actually grows over time instead of staying static."""
    import os
    from datetime import date

    brain_dir = os.path.join(os.path.dirname(__file__), "brain")
    memory_path = os.path.join(brain_dir, "memory", "memory.md")

    entry = f"\n{date.today().isoformat()}: {req.lesson.strip()}\n"
    with open(memory_path, "a") as f:
        f.write(entry)

    return {"success": True}


@app.post("/workspace/chat")
def workspace_chat(req: WorkspaceChatRequest):
    """
    The 'Chief of Staff' chat, embedded directly in the command center.
    Not a separate agent - a live conversational layer with real-time
    visibility into Chris/Alex/Taylor's actual current data, PLUS the
    full business brain (AGENTS.md, skills, context, memory), running on
    the same server, using the same API key already configured.
    """
    from shared.llm_client import get_client, MODEL

    live_context = _gather_workspace_context()
    brain = _load_brain()

    system_prompt = f"""You are the Workspace Chat inside Thomas's IPSolutions
command center - his Chief of Staff for the business. You have live
visibility into Chris (Acquisitions), Alex (Dispositions), and Taylor
(Transaction Coordinator) - three AI agents that run this real estate
wholesaling/novation business.

You reason from the actual business brain below - this is real,
specific knowledge (acquisitions frameworks, dispositions process,
market data, terminology rules, past lessons), not generic real estate
advice. Ground your answers in this material rather than falling back
on general knowledge whenever it's relevant.

=== BUSINESS BRAIN ===
{brain}
=== END BUSINESS BRAIN ===

CURRENT LIVE STATE OF THE BUSINESS (as of this message):
{live_context}

You are not one of the three agents - you're the layer above them, the
way Twin's "Workspace Chat" used to work: Thomas talks to you about
strategy, deal updates, questions, and you have context on what's
actually happening across all three agents. You do not run in the
background 24/7 - you only exist while Thomas is actively chatting with
you, unlike the three agents which run continuously via a scheduler on
the server.

If Thomas tells you something worth remembering for the future (a
lesson from a deal, an objection pattern, a market insight), say so and
offer to save it - real lessons get written to brain/memory/lessons.md
via the /workspace/memory/add endpoint, so the brain actually improves
over time rather than staying static.

Be direct, concise, and grounded in the real numbers and brain content
above - don't invent activity that hasn't happened. If asked about
something outside your visibility (e.g. a call that hasn't been
logged), say so plainly rather than guessing.

Your replies render through markdown, so use it when it actually makes
something clearer:
- "## " for a short section header
- "- " for bullet lists
- GFM pipe tables (with a "|---|---|" divider row) whenever you're
  comparing multiple deals, laying out a priority list, or breaking
  something into columns - the way a sharp operator briefs a CEO
- "**bold**" for emphasis
Keep simple conversational answers as plain short paragraphs - only
reach for structure when there's genuinely multi-part information to
organize."""

    try:
        client = get_client()
        response = client.messages.create(
            model=MODEL,
            max_tokens=1500,
            system=system_prompt,
            messages=[{"role": m.role, "content": m.content} for m in req.messages],
        )
        text = "".join(block.text for block in response.content if hasattr(block, "text"))
        return {"success": True, "reply": text}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "error": str(exc)}


AGENT_PERSONAS = {
    "chris": {
        "name": "Chris",
        "role": "Acquisitions Specialist",
        "focus": (
            "sourcing leads, seller conversations, offer ladder math, and getting "
            "deals to a signed contract. He does NOT handle dispositions, financial "
            "partners, or closing/title work - that's Alex and Taylor's lane."
        ),
    },
    "alex": {
        "name": "Alex",
        "role": "Dispositions Specialist",
        "focus": (
            "taking Chris's locked deals, running the 5-Day Dispo process, managing "
            "the financial partner network, and getting deals assigned at the best "
            "price. He does NOT source leads or run closing/title work."
        ),
    },
    "taylor": {
        "name": "Taylor",
        "role": "Transaction Coordinator",
        "focus": (
            "tracking every deal through the real 36-node closing workflow, EMD, "
            "title company coordination, and flagging stalls. She does NOT source "
            "leads or manage financial partner relationships."
        ),
    },
}


@app.post("/agents/{agent_key}/chat")
def agent_chat(agent_key: str, req: WorkspaceChatRequest):
    """
    Direct, one-on-one chat with a single agent - not the aggregate
    Workspace Chat view. This is the "talk to Sarah directly about that
    lead" pattern: Thomas gives feedback, asks about a specific deal,
    or corrects something, scoped to just that agent's domain and real
    live data, the way you'd message one team member instead of
    broadcasting to the whole channel.
    """
    from shared.llm_client import get_client, MODEL

    persona = AGENT_PERSONAS.get(agent_key)
    if not persona:
        return {"success": False, "error": f"Unknown agent: {agent_key}"}

    live_context = _gather_workspace_context()
    brain = _load_brain()

    system_prompt = f"""You are {persona['name']}, the {persona['role']} for
Intense Property Solutions. Thomas (the owner) is talking to you
directly, one-on-one - not through the aggregate Workspace Chat, this
is your own dedicated channel, the way a real team member would get a
direct message.

Your job: {persona['focus']}

You reason from the real business brain below, and you have live
visibility into current state across the whole business (though you
should mostly speak to your own lane unless Thomas asks about
something cross-agent):

=== BUSINESS BRAIN ===
{brain}
=== END BUSINESS BRAIN ===

CURRENT LIVE STATE:
{live_context}

Speak in first person as {persona['name']} - "I've got 2 leads in the
system" not "Chris has 2 leads." If Thomas gives you feedback or a
correction ("don't do X next time," "here's what I learned from that
deal"), acknowledge it plainly and tell him you'll remember it - real
lessons should be saved via the /workspace/memory/add endpoint if he
wants it written down permanently, so mention that's an option rather
than just saying "noted" and forgetting it.

Your replies render through markdown - use "## " headers, "- " bullets,
and GFM tables when they make a multi-part answer clearer, plain short
paragraphs otherwise. Be direct and grounded in real data - don't
invent activity that hasn't happened."""

    try:
        client = get_client()
        response = client.messages.create(
            model=MODEL,
            max_tokens=1500,
            system=system_prompt,
            messages=[{"role": m.role, "content": m.content} for m in req.messages],
        )
        text = "".join(block.text for block in response.content if hasattr(block, "text"))
        return {"success": True, "reply": text}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "error": str(exc)}


@app.get("/workspace/settings")
def get_site_settings():
    """Real, currently-applied cosmetic settings - the header reads this on every page load."""
    from shared.settings import get_settings

    return get_settings()


class BuilderChatRequest(BaseModel):
    messages: list[WorkspaceChatMessage]


@app.post("/workspace/builder/chat")
def builder_chat(req: BuilderChatRequest):
    """
    The live site builder. Unlike Workspace Chat (read-only visibility),
    this one can actually write: Thomas describes a cosmetic change, the
    LLM decides what to update, and it's saved to
    brain/site_settings.json immediately - the real header reads this
    file on every load, so changes here are genuinely live on the site,
    not a preview or a mockup.

    Deliberately scoped to three cosmetic fields only (tagline, banner
    note, accent color) - not layout, not data, not new tabs. Anything
    bigger than that is real engineering work, not something safe to
    hand an LLM write access to on every message.
    """
    import json as json_lib

    from shared.llm_client import get_client, MODEL
    from shared.settings import get_settings, update_settings

    current = get_settings()

    system_prompt = f"""You are the live site builder for Thomas's
IPSolutions Pipeline Command dashboard. He's watching a real, live
preview of his actual site update in real time next to this chat -
this is not a mockup. Changes you make are genuinely saved and apply
to the real site immediately.

You can change exactly three things:
- tagline: short subtitle under the "Intense Property Solutions" wordmark (current: "{current['tagline']}")
- banner_note: a status/alert line shown at the top of the site, or null to remove it (current: {json_lib.dumps(current['banner_note'])})
- accent_color: the gold/accent hex color used throughout the whole site (current: "{current['accent_color']}")

Respond ONLY with a single JSON object, no markdown fences around the
JSON itself, no prose outside it:
{{"reply": "<markdown-formatted reply to Thomas - use \"## \" headers, \"- \" bullets, and GFM tables when they make the answer clearer, plain short paragraphs otherwise>", "updates": {{"tagline": "<string, or omit>", "banner_note": "<string, null, or omit>", "accent_color": "<hex, or omit>"}}}}

Only include keys in "updates" that should actually change - omit
anything Thomas didn't ask to change. If he asks for something outside
these three things (new tabs, layout, data, functionality), say so
plainly in "reply" and don't fabricate an update for it - that's real
engineering work, not something this chat can do."""

    try:
        client = get_client()
        response = client.messages.create(
            model=MODEL,
            max_tokens=1000,
            system=system_prompt,
            messages=[{"role": m.role, "content": m.content} for m in req.messages],
        )
        text = "".join(block.text for block in response.content if hasattr(block, "text"))
        cleaned = text.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.strip("`")
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
            cleaned = cleaned.strip()

        try:
            parsed = json_lib.loads(cleaned)
        except Exception:  # noqa: BLE001 — if the model didn't return clean JSON, still show something
            return {"success": True, "reply": text, "settings": current}

        new_settings = current
        if parsed.get("updates"):
            new_settings = update_settings(parsed["updates"])

        return {"success": True, "reply": parsed.get("reply", "Done."), "settings": new_settings}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "error": str(exc)}


# ---------------------------------------------------------------------------
# Chris endpoints
# ---------------------------------------------------------------------------

@app.post("/chris/scouts/tax_delinquent_md/run")
def trigger_tax_delinquent_md():
    result = tax_delinquent_md.run()
    return {"triggered": True, "result": result}


class BookAppointmentRequest(BaseModel):
    scheduled_at: str  # ISO datetime string
    duration_minutes: int = 30
    purpose: str = "Property walkthrough"
    notes: str | None = None


@app.post("/chris/leads/{lead_id}/book_appointment")
def book_appointment(lead_id: int, req: BookAppointmentRequest):
    """
    Real internal appointment booking - one of the three capabilities
    REsimpli's native AI would have covered (AI Appointment Setting)
    that Chris didn't have an equivalent for. No external calendar
    integration yet (that needs real Google Calendar credentials, not
    currently in .env) - this is a real, working internal scheduler
    that shows up on the Appointments tab, which is honest functionality
    even without external sync.
    """
    from chris.db.db import get_connection

    conn = get_connection()
    lead = conn.execute("SELECT lead_id FROM leads WHERE lead_id = ?", (lead_id,)).fetchone()
    if lead is None:
        conn.close()
        return {"success": False, "error": "lead_not_found"}

    cur = conn.execute(
        "INSERT INTO appointments (lead_id, scheduled_at, duration_minutes, purpose, notes) "
        "VALUES (?, ?, ?, ?, ?)",
        (lead_id, req.scheduled_at, req.duration_minutes, req.purpose, req.notes),
    )
    conn.commit()
    appointment_id = cur.lastrowid
    conn.close()
    return {"success": True, "appointment_id": appointment_id}


@app.get("/chris/appointments")
def list_appointments(include_past: bool = False):
    from chris.db.db import get_connection

    conn = get_connection()
    where = "" if include_past else "WHERE a.scheduled_at >= datetime('now') AND a.status = 'SCHEDULED'"
    rows = conn.execute(
        f"SELECT a.appointment_id, a.lead_id, a.scheduled_at, a.duration_minutes, a.purpose, "
        f"a.status, a.notes, l.address, l.city, l.state, l.owner_name, l.owner_phone "
        f"FROM appointments a JOIN leads l ON l.lead_id = a.lead_id {where} "
        f"ORDER BY a.scheduled_at ASC"
    ).fetchall()
    conn.close()
    return {"appointments": [dict(r) for r in rows]}


class UpdateAppointmentStatusRequest(BaseModel):
    status: str  # SCHEDULED/COMPLETED/CANCELLED/NO_SHOW


@app.post("/chris/appointments/{appointment_id}/update_status")
def update_appointment_status(appointment_id: int, req: UpdateAppointmentStatusRequest):
    from chris.db.db import get_connection

    if req.status not in ("SCHEDULED", "COMPLETED", "CANCELLED", "NO_SHOW"):
        return {"success": False, "error": f"Invalid status: {req.status}"}

    conn = get_connection()
    conn.execute("UPDATE appointments SET status = ? WHERE appointment_id = ?", (req.status, appointment_id))
    conn.commit()
    conn.close()
    return {"success": True}


@app.post("/chris/leads/backfill_geocode")
def backfill_geocode():
    """
    One-time-per-lead catch-up: geocodes any lead that predates the
    map feature (or had a geocode miss on intake). Safe to call
    repeatedly - only touches rows where lat/lng is still NULL.
    """
    from chris.db.db import get_connection
    from shared.geocode import geocode_address

    conn = get_connection()
    rows = conn.execute(
        "SELECT lead_id, address, city, state, zip FROM leads WHERE lat IS NULL OR lng IS NULL"
    ).fetchall()

    updated = 0
    skipped = []
    for r in rows:
        lat, lng = geocode_address(r["address"], r["city"] or "", r["state"] or "", r["zip"] or "")
        if lat is not None:
            conn.execute("UPDATE leads SET lat = ?, lng = ? WHERE lead_id = ?", (lat, lng, r["lead_id"]))
            updated += 1
        else:
            skipped.append(r["address"])
    conn.commit()
    conn.close()

    return {"success": True, "checked": len(rows), "updated": updated, "skipped": skipped}


@app.get("/chris/conversion")
def chris_conversion():
    """Real conversion funnel, aggregated from actual lead/contract data."""
    from chris.db.db import get_connection

    conn = get_connection()
    total = conn.execute("SELECT COUNT(*) c FROM leads WHERE is_test_data = 0").fetchone()["c"]
    active = conn.execute(
        "SELECT COUNT(*) c FROM leads WHERE is_test_data = 0 AND status NOT IN ('DEAD','DO_NOT_CONTACT')"
    ).fetchone()["c"]
    dead = conn.execute("SELECT COUNT(*) c FROM leads WHERE is_test_data = 0 AND status = 'DEAD'").fetchone()["c"]
    high_motivation = conn.execute(
        "SELECT COUNT(*) c FROM leads WHERE is_test_data = 0 AND motivation = 'HIGH'"
    ).fetchone()["c"]
    contracts = conn.execute("SELECT COUNT(DISTINCT lead_id) c FROM contracts").fetchone()["c"]
    by_source = conn.execute(
        "SELECT l.source, COUNT(*) total, "
        "SUM(CASE WHEN l.status NOT IN ('DEAD','DO_NOT_CONTACT') THEN 1 ELSE 0 END) active, "
        "COUNT(DISTINCT ct.lead_id) contracts "
        "FROM leads l LEFT JOIN contracts ct ON ct.lead_id = l.lead_id "
        "WHERE l.is_test_data = 0 GROUP BY l.source"
    ).fetchall()
    conn.close()
    return {
        "total_leads": total, "active": active, "dead": dead,
        "high_motivation": high_motivation, "contracts": contracts,
        "by_source": [dict(r) for r in by_source],
    }


@app.get("/chris/outreach_summary")
def chris_outreach_summary():
    """Real agent-outreach numbers, from the actual agents + mat_beard_touches tables."""
    from chris.db.db import get_connection

    conn = get_connection()
    total_agents = conn.execute("SELECT COUNT(*) c FROM agents WHERE is_test_data = 0").fetchone()["c"]
    tier_rows = conn.execute(
        "SELECT tier, COUNT(*) c FROM agents WHERE is_test_data = 0 GROUP BY tier"
    ).fetchall()
    tier_counts = {r["tier"]: r["c"] for r in tier_rows}
    touches = conn.execute("SELECT COUNT(*) c FROM mat_beard_touches").fetchone()["c"]
    replies = conn.execute(
        "SELECT COUNT(*) c FROM agents WHERE last_call_outcome IS NOT NULL AND is_test_data = 0"
    ).fetchone()["c"]
    conn.close()
    return {
        "total_agents": total_agents,
        "tier_1": tier_counts.get("TIER_1", 0),
        "tier_2": tier_counts.get("TIER_2", 0),
        "tier_3": tier_counts.get("TIER_3", 0),
        "dead": tier_counts.get("DEAD", 0),
        "touches_sent": touches,
        "replies": replies,
    }


@app.get("/chris/d2s")
def chris_d2s():
    """
    Direct-to-Seller pipeline: every lead NOT sourced via an agent
    referral (the agent-outreach model has its own separate channel,
    see brain/AGENTS.md), with the real next follow-up step attached.
    """
    from chris.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT l.lead_id, l.address, l.city, l.state, l.owner_name, l.source, l.status, "
        "l.arv, l.motivation, l.motivation_reason, "
        "(SELECT fq.drip_step FROM followup_queue fq WHERE fq.lead_id = l.lead_id "
        " ORDER BY fq.queue_id DESC LIMIT 1) AS follow_up_step "
        "FROM leads l WHERE l.source != 'AGENT_REFERRAL' AND l.is_test_data = 0 "
        "ORDER BY l.created_at DESC"
    ).fetchall()
    conn.close()
    return {"leads": [dict(r) for r in rows]}


@app.get("/chris/structuring")
def chris_structuring():
    """
    Real offer-ladder computation for every lead with an ARV on file,
    using the exact same compute_cash_ladder()/decide_exit_strategy()
    logic that /generate_brief uses - not a separate, fake comparison.
    """
    from chris.db.db import get_connection
    from chris.conversation.offer_engine import compute_cash_ladder, decide_exit_strategy

    conn = get_connection()
    leads = conn.execute(
        "SELECT lead_id, address, city, state, owner_name, arv, repairs_estimate, "
        "asking_price FROM leads WHERE arv IS NOT NULL AND arv > 0 AND is_test_data = 0 "
        "ORDER BY created_at DESC"
    ).fetchall()
    conn.close()

    results = []
    for row in leads:
        lead = dict(row)
        arv = lead["arv"]
        repairs = lead["repairs_estimate"] or (arv * 0.25)
        assignment_fee_target = 15000
        ladder = compute_cash_ladder(arv, repairs, assignment_fee_target)
        seller_wants_retail = bool(lead["asking_price"] and lead["asking_price"] >= arv * 0.85)
        exit_strategy = decide_exit_strategy(repairs, seller_wants_retail)
        results.append({
            **lead,
            "repairs_estimate": repairs,
            "t1": round(ladder.t1, 2), "t2": round(ladder.t2, 2), "t3": round(ladder.t3, 2),
            "mao_ceiling": round(ladder.mao_ceiling, 2),
            "exit_strategy": exit_strategy,
        })
    return {"leads": results}


@app.post("/chris/followup/dispatch/run")
def trigger_seller_followup_dispatch():
    """Manual trigger for testing - same logic the 10am daily job runs."""
    from chris.followup.dispatcher import run_seller_followup_dispatch

    result = run_seller_followup_dispatch()
    return {"triggered": True, "result": result}


@app.get("/chris/leads")
def list_leads(limit: int = 50):
    from chris.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT lead_id, address, city, state, zip, lat, lng, owner_name, source, status, motivation, "
        "arv, asking_price, mortgage_balance, equity, distress_score, risk_tier, deal_score, "
        "setup_call_outcome, is_test_data, created_at, "
        "EXISTS(SELECT 1 FROM conversations c WHERE c.lead_id = leads.lead_id AND c.outcome = 'BRIEF_DELIVERED') AS brief_generated, "
        "EXISTS(SELECT 1 FROM contracts ct WHERE ct.lead_id = leads.lead_id) AS locked "
        "FROM leads ORDER BY created_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return {"leads": [dict(r) for r in rows]}


class NewLeadRequest(BaseModel):
    address: str
    city: str
    zip: str
    source: str = "MANUAL"
    owner_name: str | None = None
    owner_phone: str | None = None
    owner_email: str | None = None
    motivation: str | None = None
    arv: float | None = None
    repairs_estimate: float | None = None
    asking_price: float | None = None
    mortgage_balance: float = 0


@app.post("/chris/leads/add")
def add_lead(lead: NewLeadRequest):
    from chris.intake.zip_filter import insert_lead

    result = insert_lead(
        address=lead.address,
        city=lead.city,
        raw_zip=lead.zip,
        source=lead.source,
        owner_name=lead.owner_name,
        owner_phone=lead.owner_phone,
        owner_email=lead.owner_email,
        motivation=lead.motivation,
        arv=lead.arv,
        repairs_estimate=lead.repairs_estimate,
        asking_price=lead.asking_price,
        mortgage_balance=lead.mortgage_balance,
    )
    if not result.accepted:
        return {"accepted": False, "reason": result.reason}
    return {"accepted": True, "lead_id": result.lead_id}


class LockDealRequest(BaseModel):
    contract_price: float
    purchase_agreement_doc_url: str
    assignment_fee_target: float = 15000
    exit_strategy: str = "WHOLESALE_ASSIGNMENT"
    risk_tier: str = "STANDARD"
    days_to_close: int = 14
    double_close_recommended: bool = False


class SetupCallOutcomeRequest(BaseModel):
    outcome: str  # GREEN/RED/PENDING
    notes: str | None = None


@app.post("/chris/leads/{lead_id}/setup_call_outcome")
def record_setup_call_outcome(lead_id: int, req: SetupCallOutcomeRequest):
    """
    Records the setup call's diagnostic result on an agent-referral
    lead - this is what the green-flag gate on lock_deal checks. Only
    meaningful for AGENT_REFERRAL leads, but not hard-restricted to
    them in case the field is useful elsewhere later.
    """
    from chris.db.db import get_connection

    if req.outcome not in ("GREEN", "RED", "PENDING"):
        return {"success": False, "error": f"Invalid outcome: {req.outcome} (must be GREEN/RED/PENDING)"}

    conn = get_connection()
    lead = conn.execute("SELECT lead_id FROM leads WHERE lead_id = ?", (lead_id,)).fetchone()
    if lead is None:
        conn.close()
        return {"success": False, "error": "lead_not_found"}

    new_status = "DEAD" if req.outcome == "RED" else "RESEARCHED"
    conn.execute(
        "UPDATE leads SET setup_call_outcome = ?, status = ? WHERE lead_id = ?",
        (req.outcome, new_status, lead_id),
    )
    conn.commit()
    conn.close()

    try:
        from shared.resimpli_queue import queue_status_update
        queue_status_update(lead_id, new_status)
    except Exception:  # noqa: BLE001 — queuing a future sync should never break the real status update
        pass

    return {"success": True, "lead_id": lead_id, "outcome": req.outcome}


@app.post("/chris/leads/{lead_id}/lock_deal")
def lock_deal(lead_id: int, req: LockDealRequest):
    """
    THE MISSING CONNECTIVE TISSUE: creates the real handoff from Chris to
    Alex once a contract is signed. Before this endpoint existed, Alex's
    ingest_handoff() was built and tested but nothing ever called it -
    each agent was a working island. This is what makes it a real
    assembly line instead of three disconnected stations.

    Also records the signed purchase agreement doc in Chris's contracts
    table - this is what eventually travels through to Taylor (and the
    title company) alongside the assignment agreement, so both real
    documents are on file when title work begins, not just the buyer
    side.
    """
    from chris.db.db import get_connection as chris_conn
    from alex.dispo.handoff_ingest import ingest_handoff

    conn = chris_conn()
    lead = conn.execute("SELECT * FROM leads WHERE lead_id = ?", (lead_id,)).fetchone()
    if lead is None:
        conn.close()
        return {"success": False, "error": "lead_not_found"}
    lead = dict(lead)

    # The green-flag gate: per the agent-outreach model, never send a lead
    # to Alex/the buyer network that hasn't cleared the setup-call
    # diagnostic. Only applies to agent-referral leads specifically -
    # direct-to-seller leads use a different diagnostic flow (Keith
    # Everett personality-read call) and don't set this field at all.
    if lead["source"] == "AGENT_REFERRAL" and lead.get("setup_call_outcome") != "GREEN":
        conn.close()
        return {
            "success": False,
            "error": "green_flag_gate: this lead came from an agent referral and hasn't cleared "
                     "the setup call yet (current outcome: "
                     f"{lead.get('setup_call_outcome') or 'not yet called'}). "
                     "Record a GREEN outcome via /chris/leads/{lead_id}/setup_call_outcome before locking.",
        }

    result = ingest_handoff(
        lead_id=lead_id,
        address=lead["address"],
        city=lead["city"] or "",
        state=lead["state"] or "",
        zip_code=lead["zip"] or "",
        contract_price=req.contract_price,
        assignment_fee_target=req.assignment_fee_target,
        exit_strategy=req.exit_strategy,
        risk_tier=req.risk_tier,
        days_to_close=req.days_to_close,
        double_close_recommended=req.double_close_recommended,
    )

    if not result.accepted:
        conn.close()
        return {"success": False, "error": result.reason}

    conn.execute(
        "INSERT INTO contracts (lead_id, contract_type, signed_amount, signed_at, contract_doc_url) "
        "VALUES (?, 'PURCHASE', ?, datetime('now'), ?)",
        (lead_id, req.contract_price, req.purchase_agreement_doc_url),
    )
    conn.execute("UPDATE leads SET status = 'ACTIVE' WHERE lead_id = ?", (lead_id,))
    conn.commit()
    conn.close()

    try:
        from shared.resimpli_queue import queue_status_update
        queue_status_update(lead_id, "ACTIVE")
    except Exception:  # noqa: BLE001 — queuing a future sync should never break a real deal lock
        pass

    return {"success": True, "alex_deal_id": result.deal_id}


@app.get("/chris/scout_runs")
def list_scout_runs(limit: int = 20):
    from chris.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM scout_runs ORDER BY run_at DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return {"scout_runs": [dict(r) for r in rows]}


@app.post("/chris/leads/{lead_id}/pull_comps")
def pull_comps(lead_id: int):
    """
    Real Zillow lookup via HasData - fills in a lead's ARV from an
    actual property valuation instead of requiring manual entry.
    Manual-trigger for now (not chained into the automatic Tier 1 flow
    yet) until confirmed working against a real response on the live
    server - see shared/hasdata_client.py for the honest caveat about
    unverified response field names.
    """
    from chris.db.db import get_connection
    from shared.hasdata_client import pull_comps_for_address

    conn = get_connection()
    lead = conn.execute("SELECT * FROM leads WHERE lead_id = ?", (lead_id,)).fetchone()
    if lead is None:
        conn.close()
        return {"success": False, "error": "lead_not_found"}
    lead = dict(lead)

    try:
        result = pull_comps_for_address(lead["address"], lead["city"], lead["state"], lead["zip"])
    except Exception as exc:  # noqa: BLE001
        conn.close()
        return {"success": False, "error": f"HasData lookup failed: {exc}"}

    if not result["found"]:
        conn.close()
        return {"success": False, "error": result["reason"]}

    conn.execute(
        "UPDATE leads SET arv = ?, asking_price = ? WHERE lead_id = ?",
        (result["arv_estimate"], result["asking_price"], lead_id),
    )
    conn.commit()
    conn.close()

    return {
        "success": True, "arv_estimate": result["arv_estimate"],
        "asking_price": result["asking_price"], "zillow_url": result["zillow_url"],
    }


@app.post("/chris/leads/{lead_id}/generate_brief")
def generate_brief(lead_id: int):
    """
    Pulls a real lead, computes the offer ladder from its ARV/repairs,
    calls Claude to draft the narrative sections, assembles the full
    12-section brief, and stores it in conversations (matching how the
    real system stores briefs: channel=EMAIL, outcome=BRIEF_DELIVERED).
    """
    from chris.db.db import get_connection
    from chris.conversation.offer_engine import compute_cash_ladder, decide_exit_strategy
    from chris.conversation.brief_generator import generate_llm_sections
    from chris.templates.pre_call_brief import (
        BriefInputs, PropertySnapshot, OwnerIntel, OfferLadder, assemble_full_brief,
    )

    conn = get_connection()
    lead = conn.execute("SELECT * FROM leads WHERE lead_id = ?", (lead_id,)).fetchone()
    if lead is None:
        conn.close()
        return {"success": False, "error": "lead_not_found"}
    lead = dict(lead)

    arv = lead["arv"] or 0
    if arv <= 0:
        conn.close()
        return {"success": False, "error": "Lead needs an ARV before a brief can be generated."}

    # Reasonable default if repairs weren't provided when the lead was added
    repairs = lead["repairs_estimate"] or (arv * 0.25)
    assignment_fee_target = 15000

    ladder = compute_cash_ladder(arv=arv, repairs=repairs, assignment_fee_target=assignment_fee_target)
    exit_strategy = decide_exit_strategy(rehab_cost=repairs, seller_wants_retail=False)

    inputs = BriefInputs(
        lead_id=str(lead_id),
        snapshot=PropertySnapshot(
            address=lead["address"], city=lead["city"] or "", state=lead["state"] or "",
            zip_code=lead["zip"] or "", source=lead["source"], property_type="Residential",
            days_on_market=0, risk_tier=lead["risk_tier"] or "STANDARD",
        ),
        owner=OwnerIntel(
            name=lead["owner_name"] or "Unknown - Discovery Required",
            phone=lead["owner_phone"], email=lead["owner_email"],
        ),
        offer=OfferLadder(
            arv=arv, repairs=repairs, t1_lowball=ladder.t1, mao_ceiling=ladder.mao_ceiling,
            novation_target=arv * 0.90, ask=lead["asking_price"],
        ),
        exit_strategy=exit_strategy,
        personality_hypothesis=None,
    )

    try:
        llm_result = generate_llm_sections(inputs)
    except Exception as exc:  # noqa: BLE001
        conn.close()
        return {"success": False, "error": f"LLM call failed: {exc}"}

    full_brief = assemble_full_brief(inputs, llm_result["text"])

    conn.execute(
        """
        INSERT INTO conversations (lead_id, channel, direction, outcome, body)
        VALUES (?, 'EMAIL', 'OUTBOUND', 'BRIEF_DELIVERED', ?)
        """,
        (lead_id, full_brief),
    )
    conn.execute("UPDATE leads SET status = 'RESEARCHED' WHERE lead_id = ?", (lead_id,))
    conn.commit()
    conn.close()

    # Real follow-up scheduling - previously chris/followup/cadence.py's
    # timing logic existed but nothing ever called it, so no brief ever
    # actually got a scheduled follow-up. This is what makes "AI Follow-Up"
    # real instead of dead code.
    followup_info = None
    try:
        from chris.followup.dispatcher import enqueue_followup

        gap_from_mao = max((lead["asking_price"] or ladder.mao_ceiling) - ladder.mao_ceiling, 0)
        followup_info = enqueue_followup(lead_id, gap_from_mao, lead.get("motivation"))
    except Exception:  # noqa: BLE001 — brief delivery must never fail because follow-up scheduling hiccupped
        pass

    try:
        from shared.resimpli_queue import queue_status_update
        queue_status_update(lead_id, "RESEARCHED")
    except Exception:  # noqa: BLE001
        pass

    return {
        "success": True,
        "brief": full_brief,
        "terminology_clean": llm_result["terminology_clean"],
        "spread_safety_clean": llm_result["spread_safety_clean"],
        "warnings": llm_result["warnings"],
        "followup_scheduled": followup_info,
    }


# ---------------------------------------------------------------------------
# Chris's daily KPI computation (mirrors alex/dispo/kpi_rollup.py's pattern -
# Chris never had an equivalent module built, so /chris/kpi computes live
# as a fallback when no daily_kpi row exists yet for today, rather than
# silently returning null.)
# ---------------------------------------------------------------------------

def _compute_chris_kpi_live(today: str) -> dict:
    from chris.db.db import get_connection

    conn = get_connection()
    leads_today = conn.execute(
        "SELECT COUNT(*) as c FROM leads WHERE date(created_at) = ? AND is_test_data = 0", (today,)
    ).fetchone()["c"]
    conversations_today = conn.execute(
        "SELECT COUNT(*) as c FROM conversations WHERE date(timestamp) = ?", (today,)
    ).fetchone()["c"]
    offers_today = conn.execute(
        "SELECT COUNT(*) as c FROM offers WHERE date(created_at) = ?", (today,)
    ).fetchone()["c"]
    contracts_today = conn.execute(
        "SELECT COUNT(*) as c FROM contracts WHERE date(signed_at) = ?", (today,)
    ).fetchone()["c"]
    fb_ad_leads = conn.execute(
        "SELECT COUNT(*) as c FROM leads WHERE date(created_at) = ? AND source = 'FB_AD'", (today,)
    ).fetchone()["c"]
    fsbo_leads = conn.execute(
        "SELECT COUNT(*) as c FROM leads WHERE date(created_at) = ? AND source = 'FSBO'", (today,)
    ).fetchone()["c"]
    scout_leads = conn.execute(
        "SELECT COUNT(*) as c FROM leads WHERE date(created_at) = ? AND source NOT IN ('FB_AD', 'FSBO')",
        (today,),
    ).fetchone()["c"]
    mat_beard_touches = conn.execute(
        "SELECT COUNT(*) as c FROM mat_beard_touches WHERE date(sent_at) = ?", (today,)
    ).fetchone()["c"]
    conn.close()

    return {
        "kpi_date": today,
        "leads_today": leads_today,
        "conversations_today": conversations_today,
        "offers_today": offers_today,
        "contracts_today": contracts_today,
        "fb_ad_leads": fb_ad_leads,
        "fsbo_leads": fsbo_leads,
        "scout_leads": scout_leads,
        "mat_beard_touches": mat_beard_touches,
    }


class AddAgentRequest(BaseModel):
    name: str
    phone: str
    email: str | None = None
    brokerage: str | None = None
    tier: str = "TIER_3"
    notes: str | None = None


@app.post("/chris/agents/add")
def add_agent(req: AddAgentRequest):
    """Adds a real estate agent contact - the missing piece that existed
    as tiering logic in mat_beard.py but had nowhere to actually store
    agent records until now."""
    from chris.db.db import get_connection

    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO agents (name, phone, email, brokerage, tier, notes) VALUES (?, ?, ?, ?, ?, ?)",
        (req.name, req.phone, req.email, req.brokerage, req.tier, req.notes),
    )
    agent_id = cur.lastrowid
    conn.commit()
    conn.close()
    return {"success": True, "agent_id": agent_id}


@app.get("/chris/agents")
def list_agents(limit: int = 50):
    from chris.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT agent_id, name, phone, email, brokerage, tier, last_contact_at, "
        "last_call_outcome FROM agents WHERE is_test_data = 0 ORDER BY agent_id DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return {"agents": [dict(r) for r in rows]}


class TransitionTierRequest(BaseModel):
    requested_tier: str  # TIER_1/TIER_2/TIER_3/DEAD
    reason: str
    address: str | None = None   # if given and resulting tier is TIER_1, creates a lead
    city: str | None = None
    zip_code: str | None = None


@app.post("/chris/agents/{agent_id}/transition_tier")
def transition_agent_tier(agent_id: int, req: TransitionTierRequest):
    """
    The ONLY correct way to change an agent's tier - routes through
    chris/scouts/agent_tier_transitions.py, which enforces the hard
    rules (tier-lock, DEAD permanence, deal_closed lock) rather than
    allowing a raw UPDATE that could silently bypass them. Returns the
    ACTUAL resulting tier, which may differ from what was requested if
    a hard rule corrected it (e.g. requesting TIER_3 on an agent who's
    already reached TIER_1 gets corrected to TIER_2).

    If an address is given and the resulting tier is TIER_1, also
    creates the corresponding lead (source=AGENT_REFERRAL) via
    chris/scouts/agent_lead_creation.py - this is what an agent handing
    over a property actually means downstream. Runs every time an
    address is given, not just the first time this agent reaches
    Tier 1 - a proven relationship can produce a second or third deal.
    """
    from chris.db.db import get_connection
    from chris.scouts.mat_beard import AgentTier
    from chris.scouts.agent_tier_transitions import transition_tier, InvalidTierTransition
    from chris.scouts.agent_lead_creation import create_lead_from_agent_referral

    try:
        requested = AgentTier(req.requested_tier)
    except ValueError:
        return {"success": False, "error": f"Invalid tier: {req.requested_tier}"}

    conn = get_connection()
    try:
        actual_tier = transition_tier(conn, agent_id, requested, req.reason)
    except InvalidTierTransition as exc:
        conn.close()
        return {"success": False, "error": str(exc)}
    conn.close()

    corrected = actual_tier.value != req.requested_tier

    lead_id = None
    lead_warning = None
    analysis_result = None
    if actual_tier == AgentTier.TIER_1 and req.address:
        if not req.city or not req.zip_code:
            lead_warning = "Address given but city/zip_code missing - lead not created, add them and retry."
        else:
            result = create_lead_from_agent_referral(
                agent_id=agent_id, address=req.address, city=req.city, raw_zip=req.zip_code,
            )
            if result.accepted:
                lead_id = result.lead_id

                # Real fix for a gap Matt's model doesn't allow: property
                # analysis must fire automatically the moment a lead hits
                # Tier 1, BEFORE the setup call - not a separate manual
                # "Pull Comps" button a human has to remember to click.
                # "This should happen before any human or voice-bot call -
                # the call should already have this context loaded."
                try:
                    from shared.hasdata_client import pull_comps_for_address

                    analysis_conn = get_connection()
                    new_lead_row = analysis_conn.execute(
                        "SELECT state FROM leads WHERE lead_id = ?", (lead_id,)
                    ).fetchone()
                    lead_state = new_lead_row["state"] if new_lead_row else None

                    comps = pull_comps_for_address(req.address, req.city, lead_state, req.zip_code)
                    if comps.get("found"):
                        analysis_conn.execute(
                            "UPDATE leads SET arv = ?, asking_price = ? WHERE lead_id = ?",
                            (comps["arv_estimate"], comps["asking_price"], lead_id),
                        )
                        analysis_conn.commit()
                        analysis_result = {"ran": True, "arv_estimate": comps["arv_estimate"]}
                    else:
                        analysis_result = {"ran": True, "found": False, "reason": comps.get("reason")}
                    analysis_conn.close()
                except Exception as exc:  # noqa: BLE001 — a failed auto-analysis should never block lead creation or the setup call
                    analysis_result = {"ran": False, "error": str(exc)}
            else:
                lead_warning = f"Lead not created: {result.reason}"

    setup_call_triggered = False
    setup_call_warning = None
    if lead_id is not None:
        agent_conn = get_connection()
        agent = agent_conn.execute(
            "SELECT name, phone FROM agents WHERE agent_id = ?", (agent_id,)
        ).fetchone()
        agent_conn.close()

        if agent and agent["phone"]:
            from shared.vapi_client import trigger_setup_call

            try:
                trigger_setup_call(agent["name"], agent["phone"], agent_id, lead_id)
                setup_call_triggered = True
            except Exception as exc:  # noqa: BLE001
                # A failed auto-call should never block the tier update or
                # lead creation that already succeeded - surface it as a
                # warning so it can be triggered manually instead.
                setup_call_warning = f"Auto setup-call failed: {exc}. Use the Call via Brielle button instead."
        else:
            setup_call_warning = "Lead created but agent has no phone on file - setup call not triggered."

    return {
        "success": True, "resulting_tier": actual_tier.value, "corrected": corrected,
        "lead_id": lead_id, "lead_warning": lead_warning, "property_analysis": analysis_result,
        "setup_call_triggered": setup_call_triggered, "setup_call_warning": setup_call_warning,
    }


@app.post("/chris/agents/{agent_id}/call")
def call_agent(agent_id: int):
    """
    Triggers Brielle (via Vapi) to actually call this agent - real voice
    outreach, sidestepping the A2P 10DLC SMS registration process
    entirely since this is a phone call, not a text message.
    """
    from chris.db.db import get_connection
    from shared.vapi_client import trigger_agent_outbound_call

    conn = get_connection()
    agent = conn.execute("SELECT * FROM agents WHERE agent_id = ?", (agent_id,)).fetchone()
    if agent is None:
        conn.close()
        return {"success": False, "error": "agent_not_found"}
    agent = dict(agent)

    if not agent["phone"]:
        conn.close()
        return {"success": False, "error": "This agent has no phone number on file."}

    try:
        result = trigger_agent_outbound_call(agent["name"], agent["phone"], agent_id)
    except Exception as exc:  # noqa: BLE001
        conn.close()
        return {"success": False, "error": f"Vapi call failed: {exc}"}

    vapi_call_id = result.get("id")
    conn.execute(
        "UPDATE agents SET last_contact_at = datetime('now'), last_vapi_call_id = ? WHERE agent_id = ?",
        (vapi_call_id, agent_id),
    )
    conn.execute(
        "INSERT INTO agent_call_log (agent_id, vapi_call_id, direction, call_started_at) "
        "VALUES (?, ?, 'OUTBOUND', datetime('now'))",
        (agent_id, vapi_call_id),
    )
    conn.commit()
    conn.close()

    return {"success": True, "vapi_call_id": vapi_call_id}


@app.post("/vapi/webhook")
async def vapi_webhook(request: Request):
    """
    Receives call events back from Vapi once a call ends - the transcript
    and outcome. This is what lets Chris actually learn from agent calls
    instead of them disappearing into Vapi with no record on our side.

    Also handles automatic setup-call outcome classification: if the
    call was tagged call_type=setup_call (see shared/vapi_client.py
    trigger_setup_call), the real transcript is run through
    chris/scouts/setup_call_classifier.py against the actual
    setup-call-script rules, and the result is written directly to the
    lead's setup_call_outcome - this is what makes Brielle's calls
    auto-triggered on Tier 1 actually usable end to end, rather than
    still requiring a human to listen and click Green/Red afterward.
    """
    from chris.db.db import get_connection

    payload = await request.json()
    message = payload.get("message", {})

    if message.get("type") != "end-of-call-report":
        return {"received": True, "ignored": True}

    call = message.get("call", {})
    vapi_call_id = call.get("id")
    transcript = message.get("transcript", "")
    ended_reason = message.get("endedReason", "")
    metadata = call.get("metadata", {}) or {}

    conn = get_connection()
    agent_row = conn.execute(
        "SELECT agent_id FROM agents WHERE last_vapi_call_id = ?", (vapi_call_id,)
    ).fetchone()

    if agent_row:
        agent_id = agent_row["agent_id"]
        conn.execute(
            "UPDATE agents SET last_call_outcome = ? WHERE agent_id = ?",
            (ended_reason, agent_id),
        )
        conn.execute(
            "UPDATE agent_call_log SET transcript = ?, outcome = ?, call_ended_at = datetime('now') "
            "WHERE vapi_call_id = ?",
            (transcript, ended_reason, vapi_call_id),
        )
        conn.commit()

    classification = None
    if metadata.get("call_type") == "setup_call" and metadata.get("lead_id"):
        from chris.scouts.setup_call_classifier import classify_setup_call_outcome

        lead_id = metadata["lead_id"]
        try:
            classification = classify_setup_call_outcome(transcript)
            conn.execute(
                "UPDATE leads SET setup_call_outcome = ?, status = ? WHERE lead_id = ?",
                (
                    classification["outcome"],
                    "DEAD" if classification["outcome"] == "RED" else "RESEARCHED",
                    lead_id,
                ),
            )
            conn.commit()
        except Exception as exc:  # noqa: BLE001
            # Classification failing should never lose the transcript or
            # block the webhook - leave setup_call_outcome as PENDING
            # (unset) so a human can still review manually.
            classification = {"outcome": "ERROR", "reasoning": str(exc)}

    # Real inbound call handling - a seller calling IN, not us calling
    # out. NOTE: per Chris's real locked instructions, ALL Vapi voice
    # (inbound or outbound) is Phase 2 scope - Phase 1's real model is
    # "operator dials/answers through REsimpli, REsimpli auto-records,
    # Chris transcribes/grades." This code is real and will work once
    # Phase 2 begins, but Thomas should NOT configure a live inbound
    # Vapi phone number yet. The correct Phase 1 build (not done yet)
    # is a separate endpoint that ingests a REsimpli call recording/
    # transcript after the fact, not a live-answering AI line.
    inbound_result = None
    if call.get("type") == "inboundPhoneCall" and not agent_row and metadata.get("call_type") != "setup_call":
        from chris.scouts.inbound_call_intake import extract_inbound_seller_call
        from chris.intake.zip_filter import insert_lead

        caller_phone = call.get("customer", {}).get("number", "")
        extracted = extract_inbound_seller_call(transcript, caller_phone)

        existing_lead = None
        if caller_phone:
            existing_lead = conn.execute(
                "SELECT lead_id FROM leads WHERE owner_phone = ?", (caller_phone,)
            ).fetchone()

        if existing_lead:
            conn.execute(
                "INSERT INTO conversations (lead_id, channel, direction, outcome, transcript, body) "
                "VALUES (?, 'CALL', 'INBOUND', 'INBOUND_CALL_RECEIVED', ?, ?)",
                (existing_lead["lead_id"], transcript, extracted["summary"]),
            )
            conn.commit()
            inbound_result = {"matched_existing_lead_id": existing_lead["lead_id"], "extracted": extracted}
        elif extracted["address"] and extracted["zip"]:
            intake_result = insert_lead(
                address=extracted["address"], city=extracted["city"] or "",
                raw_zip=extracted["zip"], source="INBOUND_CALL",
                owner_name=extracted["name"], owner_phone=caller_phone,
                motivation=extracted["motivation"] if extracted["motivation"] != "UNKNOWN" else None,
            )
            inbound_result = {"new_lead": intake_result.accepted, "reason": intake_result.reason, "extracted": extracted}
        else:
            # Real caller, but not enough info to create a lead (no
            # address given, or outside market ZIPs) - log the
            # transcript against no specific lead so it isn't lost,
            # rather than forcing a bad/incomplete lead record.
            inbound_result = {"new_lead": False, "reason": "Insufficient info to create a lead", "extracted": extracted}

    conn.close()
    return {"received": True, "setup_call_classification": classification, "inbound_call": inbound_result}


@app.get("/chris/kpi")
def chris_kpi():
    from chris.db.db import get_connection

    today = date.today().isoformat()
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM daily_kpi WHERE kpi_date = ?", (today,)
    ).fetchone()
    conn.close()

    if row:
        return {"kpi": dict(row)}
    # No scheduled rollup has run yet today - compute live rather than
    # returning null, so the dashboard always shows something real.
    return {"kpi": _compute_chris_kpi_live(today)}


# ---------------------------------------------------------------------------
# Alex endpoints
# ---------------------------------------------------------------------------

@app.post("/alex/kpi/run")
def trigger_alex_kpi():
    return {"triggered": True, "result": alex_compute_kpi()}


@app.get("/alex/deals")
def list_alex_deals(limit: int = 50):
    from alex.db.db import get_connection as alex_conn
    from chris.db.db import get_connection as chris_conn

    conn = alex_conn()
    rows = conn.execute(
        "SELECT deal_id, lead_id, dispo_status, exit_strategy, dispo_day, "
        "fp_facing_price, fp_assigned_id, created_at FROM deals ORDER BY created_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    deals = [dict(r) for r in rows]

    # Cross-db read to show the real address next to each deal - address
    # lives on Chris's side, deals only store the lead_id reference.
    if deals:
        chris_c = chris_conn()
        for deal in deals:
            lead = chris_c.execute(
                "SELECT address, city, state FROM leads WHERE lead_id = ?", (deal["lead_id"],)
            ).fetchone()
            deal["address"] = f"{lead['address']}, {lead['city']} {lead['state']}" if lead else "Unknown"
        chris_c.close()

    return {"deals": deals}


class AssignFPRequest(BaseModel):
    fp_id: int


@app.post("/alex/deals/{deal_id}/assign_fp")
def assign_fp(deal_id: int, req: AssignFPRequest):
    """Assigns a financial partner to a deal - the step that has to happen
    before handoff_to_taylor can work, since that endpoint requires
    fp_assigned_id to already be set."""
    from alex.db.db import get_connection

    conn = get_connection()
    fp = conn.execute("SELECT fp_id, entity_name FROM financial_partners WHERE fp_id = ?", (req.fp_id,)).fetchone()
    if fp is None:
        conn.close()
        return {"success": False, "error": "financial_partner_not_found"}

    conn.execute("UPDATE deals SET fp_assigned_id = ? WHERE deal_id = ?", (req.fp_id, deal_id))
    conn.commit()
    conn.close()

    try:
        from alex.db.resimpli_queue import queue_resimpli_action
        queue_resimpli_action(deal_id, "SEND_E_SIGN_ASSIGNMENT", detail=f"FP: {fp['entity_name']}")
    except Exception:  # noqa: BLE001 — queuing a future sync should never break a real FP assignment
        pass

    return {"success": True, "fp_name": fp["entity_name"]}


@app.get("/alex/financial_partners")
def list_financial_partners(limit: int = 50):
    from alex.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT fp_id, entity_name, contact_name, vip_tier, dispo_tier, relationship_stage, "
        "total_deals_closed, phone, email, preferred_states, reputation_score, capacity_max "
        "FROM financial_partners WHERE is_test_data = 0 "
        "ORDER BY fp_id LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return {"financial_partners": [dict(r) for r in rows]}


class UpdateFPContactRequest(BaseModel):
    email: str | None = None
    phone: str | None = None


@app.post("/alex/financial_partners/{fp_id}/update_contact")
def update_fp_contact(fp_id: int, req: UpdateFPContactRequest):
    """
    Fills in missing contact info for a real financial partner - this is
    what unblocks the Alex to Taylor handoff, since Taylor requires a
    complete email before a real deal can hand off. Only updates fields
    that were actually provided, so a partial edit doesn't wipe out an
    existing phone number when only adding an email, or vice versa.
    """
    from alex.db.db import get_connection

    if req.email is None and req.phone is None:
        return {"success": False, "error": "Provide at least an email or phone to update."}

    conn = get_connection()
    fp = conn.execute("SELECT fp_id FROM financial_partners WHERE fp_id = ?", (fp_id,)).fetchone()
    if fp is None:
        conn.close()
        return {"success": False, "error": "financial_partner_not_found"}

    if req.email is not None:
        conn.execute("UPDATE financial_partners SET email = ? WHERE fp_id = ?", (req.email, fp_id))
    if req.phone is not None:
        conn.execute("UPDATE financial_partners SET phone = ? WHERE fp_id = ?", (req.phone, fp_id))
    conn.commit()
    conn.close()

    return {"success": True}


@app.get("/alex/five_day_board")
def five_day_board():
    """
    The 5-Day Dispo board - real TTB, walkthrough, and magic-question
    tracking data that's existed in the deals table since it was built,
    but never had a dedicated view. This is the real Matt Beard 5-day
    process, not a mock.
    """
    from alex.db.db import get_connection as alex_conn
    from chris.db.db import get_connection as chris_conn

    conn = alex_conn()
    rows = conn.execute(
        "SELECT deal_id, lead_id, dispo_day, dispo_clock_started_at, first_blast_at, "
        "ttb_hours, ttb_target_met, day1_blast_ready, walkthrough_interested_count, "
        "magic_question_asked, fomo_texts_sent_count, fp_facing_price, dispo_status "
        "FROM deals WHERE dispo_status NOT IN ('TAYLOR_HANDOFF', 'DEAD') "
        "ORDER BY dispo_day DESC"
    ).fetchall()
    conn.close()
    deals = [dict(r) for r in rows]

    if deals:
        chris_c = chris_conn()
        for deal in deals:
            lead = chris_c.execute(
                "SELECT address, city, state FROM leads WHERE lead_id = ?", (deal["lead_id"],)
            ).fetchone()
            deal["address"] = f"{lead['address']}, {lead['city']} {lead['state']}" if lead else "Unknown"
        chris_c.close()

    return {"deals": deals}


@app.get("/alex/kpi")
def alex_kpi():
    from alex.db.db import get_connection

    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM dispo_kpi ORDER BY kpi_date DESC LIMIT 1"
    ).fetchone()
    conn.close()
    return {"kpi": dict(row) if row else None}


@app.get("/alex/ceo_alerts")
def alex_ceo_alerts(limit: int = 20):
    from alex.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM ceo_alerts ORDER BY fired_at DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return {"alerts": [dict(r) for r in rows]}


class HandoffToTaylorRequest(BaseModel):
    emd_amount: float
    emd_received_at: str
    close_date_target: str
    assignment_signed_doc_url: str
    photos_package_url: str
    days_to_close: int = 14


@app.post("/alex/deals/{deal_id}/handoff_to_taylor")
def handoff_to_taylor(deal_id: int, req: HandoffToTaylorRequest):
    """
    THE SECOND MISSING CONNECTIVE PIECE: creates the real handoff from
    Alex to Taylor once a financial partner is signed. Pulls the deal's
    FP details from Alex's own database, and the address from Chris's
    leads table via the deal's lead_id (cross-db read, same pattern
    used everywhere else in this system).
    """
    from alex.db.db import get_connection as alex_conn
    from chris.db.db import get_connection as chris_conn
    from taylor.nodes.engine import ingest_new_handoff

    conn = alex_conn()
    deal = conn.execute("SELECT * FROM deals WHERE deal_id = ?", (deal_id,)).fetchone()
    if deal is None:
        conn.close()
        return {"success": False, "error": "deal_not_found"}
    deal = dict(deal)

    if not deal.get("fp_assigned_id"):
        conn.close()
        return {"success": False, "error": "No financial partner assigned to this deal yet."}

    fp = conn.execute(
        "SELECT * FROM financial_partners WHERE fp_id = ?", (deal["fp_assigned_id"],)
    ).fetchone()
    conn.close()
    if fp is None:
        return {"success": False, "error": "Assigned financial partner not found."}
    fp = dict(fp)

    # Address AND the signed purchase agreement live on Chris's side -
    # cross-db reads via the deal's lead_id. Both the seller's purchase
    # agreement and the buyer's assignment agreement need to reach
    # Taylor (and eventually the title company) - not just the buyer side.
    chris_conn_obj = chris_conn()
    lead = chris_conn_obj.execute(
        "SELECT address, city, state, zip FROM leads WHERE lead_id = ?", (deal["lead_id"],)
    ).fetchone()
    purchase_contract = chris_conn_obj.execute(
        "SELECT contract_doc_url FROM contracts WHERE lead_id = ? AND contract_type = 'PURCHASE' "
        "ORDER BY contract_id DESC LIMIT 1",
        (deal["lead_id"],),
    ).fetchone()
    chris_conn_obj.close()
    if lead is None:
        return {"success": False, "error": "Could not find the originating lead's address."}
    lead = dict(lead)
    seller_contract_doc_url = purchase_contract["contract_doc_url"] if purchase_contract else None

    handoff_payload = {
        "deal_id": deal_id,
        "address": lead["address"],
        "city": lead["city"],
        "state": lead["state"],
        "zip": lead["zip"],
        "fp_name": fp["entity_name"],
        "fp_email": fp["email"],
        "fp_phone": fp["phone"],
        "fp_entity": fp["entity_name"],
        "emd_amount": req.emd_amount,
        "emd_received_at": req.emd_received_at,
        "close_date_target": req.close_date_target,
        "seller_contract_doc_url": seller_contract_doc_url,
        "assignment_signed_doc_url": req.assignment_signed_doc_url,
        "photos_package_url": req.photos_package_url,
        "days_to_close": req.days_to_close,
    }

    result = ingest_new_handoff(handoff_payload)
    if result.get("accepted"):
        conn = alex_conn()
        conn.execute("UPDATE deals SET dispo_status = 'TAYLOR_HANDOFF' WHERE deal_id = ?", (deal_id,))
        conn.commit()
        conn.close()
        response = {"success": True, "taylor_closing_id": result["closing_id"]}
        if seller_contract_doc_url is None:
            response["warning"] = (
                "No purchase agreement was found on file for this lead - Taylor's "
                "Node 5 (seller contract confirmation) will be blocked until it's added."
            )
        return response

    return {"success": False, "error": result.get("message", "Handoff was not accepted by Taylor.")}


# ---------------------------------------------------------------------------
# Taylor endpoints
# ---------------------------------------------------------------------------

@app.post("/taylor/sweeps/pending_followups/run")
def trigger_taylor_followups():
    return {"triggered": True, "result": pending_followups_sweep()}


@app.post("/taylor/sweeps/closing_day/run")
def trigger_taylor_closing_day():
    today = date.today().isoformat()
    return {"triggered": True, "result": closing_day_sweep(today)}


@app.get("/taylor/closings")
def list_closings(limit: int = 50):
    from taylor.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT closing_id, address, current_node, status, risk_tier, "
        "close_date_target, started_at FROM closings ORDER BY started_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return {"closings": [dict(r) for r in rows]}


@app.get("/taylor/closings/{closing_id}/nodes")
def get_closing_nodes(closing_id: int):
    from taylor.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        """
        SELECT cn.node_number, cn.status, cn.blocking_reason, cn.notes,
               nt.title, nt.phase
        FROM closing_nodes cn
        JOIN node_template nt ON nt.node_number = cn.node_number
        WHERE cn.closing_id = ?
        ORDER BY cn.node_number
        """,
        (closing_id,),
    ).fetchall()
    conn.close()
    return {"nodes": [dict(r) for r in rows]}


@app.get("/taylor/emd")
def emd_tracking():
    """
    Real EMD tracking - expected vs received amounts, refundable status,
    per closing. Data has existed in Taylor's emd_status table since it
    was built, joined here with closings for the real address.
    """
    from taylor.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT e.emd_id, e.closing_id, e.expected_amount, e.received_amount, "
        "e.received_at, e.emd_tier, e.expected_by, e.non_refundable_portion, "
        "e.refundable_status, c.address "
        "FROM emd_status e JOIN closings c ON c.closing_id = e.closing_id "
        "ORDER BY e.emd_id DESC"
    ).fetchall()
    conn.close()
    return {"emd_records": [dict(r) for r in rows]}


@app.get("/taylor/ceo_alerts")
def taylor_ceo_alerts(limit: int = 20):
    from taylor.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM ceo_alerts ORDER BY fired_at DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return {"alerts": [dict(r) for r in rows]}


@app.get("/workspace/handoffs_overview")
def handoffs_overview():
    """
    The unified deal-journey view - shows every active lead's real
    position across Chris, Alex, and Taylor at once. Not an audit log
    table (nothing writes to one), but a live computed view joining the
    three real pipelines by their actual foreign key chain
    (leads.lead_id -> deals.lead_id -> closings.deal_id).
    """
    from chris.db.db import get_connection as chris_conn
    from alex.db.db import get_connection as alex_conn
    from taylor.db.db import get_connection as taylor_conn

    chris_c = chris_conn()
    leads = chris_c.execute(
        "SELECT lead_id, address, city, state, status FROM leads "
        "WHERE is_test_data = 0 ORDER BY created_at DESC"
    ).fetchall()
    leads = [dict(r) for r in leads]
    chris_c.close()

    alex_c = alex_conn()
    deals_by_lead = {}
    for row in alex_c.execute("SELECT deal_id, lead_id, dispo_status, fp_assigned_id FROM deals").fetchall():
        deals_by_lead[row["lead_id"]] = dict(row)
    alex_c.close()

    taylor_c = taylor_conn()
    closings_by_deal = {}
    for row in taylor_c.execute("SELECT closing_id, deal_id, current_node, status FROM closings").fetchall():
        if row["deal_id"] is not None:
            closings_by_deal[row["deal_id"]] = dict(row)
    taylor_c.close()

    journey = []
    for lead in leads:
        deal = deals_by_lead.get(lead["lead_id"])
        closing = closings_by_deal.get(deal["deal_id"]) if deal else None

        journey.append({
            "address": f"{lead['address']}, {lead['city']} {lead['state']}",
            "chris_status": lead["status"],
            "alex_status": deal["dispo_status"] if deal else None,
            "alex_fp_assigned": bool(deal and deal["fp_assigned_id"]),
            "taylor_node": closing["current_node"] if closing else None,
            "taylor_status": closing["status"] if closing else None,
        })

    return {"journey": journey}


@app.get("/workspace/pending_reflections")
def pending_reflections():
    """
    The memory 'habit' mechanism: rather than relying on Thomas to
    remember to save a lesson, surface a prompt for every closed deal
    that doesn't yet have a memory entry mentioning its address. Crude
    heuristic (address-string match against memory.md) but genuinely
    functional - this is what turns memory from a passive text field
    into something the system actively nudges toward filling in.
    """
    from taylor.db.db import get_connection
    from shared.brain_loader import load_memory

    memory_text = load_memory()

    conn = get_connection()
    rows = conn.execute(
        "SELECT closing_id, address, archived_at FROM closings "
        "WHERE status = 'closed' AND archived_at IS NOT NULL "
        "ORDER BY archived_at DESC LIMIT 10"
    ).fetchall()
    conn.close()

    pending = [
        {"closing_id": r["closing_id"], "address": r["address"], "archived_at": r["archived_at"]}
        for r in rows
        if r["address"] not in memory_text
    ]
    return {"pending": pending}
