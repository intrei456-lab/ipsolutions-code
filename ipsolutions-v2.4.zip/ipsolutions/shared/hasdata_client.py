"""
shared/hasdata_client.py

HasData's Zillow scraper API (confirmed against real docs at
docs.hasdata.com/apis/zillow/listing and .../property, July 2026).
Two real endpoints chained together, since our leads only have a raw
address, not a Zillow URL:

1. Listing API (search by keyword/location) -> finds the matching
   property and its Zillow URL
2. Property API (fetch by URL) -> full details including price/
   Zestimate - this is the one that costs 5 credits per call

NOTE: only tested against real documentation, not a live call - no
network access in the build sandbox and no access to Thomas's real
API key. The request shape below matches HasData's documented
examples exactly; the exact response JSON structure for the Listing
endpoint wasn't fully documented in what I could access, so
_extract_zillow_url below may need a small adjustment once tested
against a real response - flagged clearly in that function.

Real limitation worth knowing: this only finds properties that exist
(or existed) on Zillow. A genuinely off-market property that's never
been listed won't have a Zillow record at all - this gets the subject
property's own data/Zestimate, not neighborhood comps around it.
"""

import os

import requests

HASDATA_BASE_URL = "https://api.hasdata.com/scrape/zillow"


def _get_api_key() -> str:
    api_key = os.environ.get("HASDATA_API_KEY")
    if not api_key:
        raise RuntimeError("HASDATA_API_KEY must be set in .env")
    return api_key


def search_property_by_address(address: str, city: str, state: str, zip_code: str) -> dict:
    """
    Step 1: search HasData's Zillow Listing API using the full address
    as the search keyword. Returns the raw response - callers should
    check for a match before assuming one exists (see pull_comps below).
    """
    response = requests.get(
        f"{HASDATA_BASE_URL}/listing",
        headers={"Content-Type": "application/json", "x-api-key": _get_api_key()},
        params={
            "keyword": f"{address}, {city}, {state} {zip_code}",
            "type": "forSale",
        },
        timeout=20,
    )
    response.raise_for_status()
    return response.json()


def get_property_details(zillow_url: str) -> dict:
    """Step 2: fetch full details (price, Zestimate, features) for a
    specific Zillow property URL. Costs 5 API credits per call."""
    response = requests.get(
        f"{HASDATA_BASE_URL}/property",
        headers={"Content-Type": "application/json", "x-api-key": _get_api_key()},
        params={"url": zillow_url},
        timeout=20,
    )
    response.raise_for_status()
    return response.json()


def _extract_zillow_url(listing_response: dict) -> str | None:
    """
    Pulls the first matching property's URL out of the Listing API
    response. NOT verified against a real response payload - built
    against the documented pattern (a results/properties array with a
    url or detailUrl field per common scraper-API conventions). If this
    doesn't match the real shape on first live test, the fix is just
    adjusting the key names below once we see an actual response.
    """
    results = listing_response.get("properties") or listing_response.get("results") or []
    if not results:
        return None
    first = results[0]
    return first.get("url") or first.get("detailUrl") or first.get("zillowUrl")


def pull_comps_for_address(address: str, city: str, state: str, zip_code: str) -> dict:
    """
    The combined, single entry point: search for the address, then pull
    full details if found. Returns:
      {"found": True, "arv_estimate": float, "asking_price": float|None, "raw": dict}
      or
      {"found": False, "reason": str}

    Costs both a search + a property-detail call (real credit cost) -
    only call this when a real lookup is actually wanted, not
    speculatively.
    """
    listing = search_property_by_address(address, city, state, zip_code)
    zillow_url = _extract_zillow_url(listing)

    if not zillow_url:
        return {
            "found": False,
            "reason": "No matching Zillow listing found for this address - likely genuinely "
                      "off-market (never listed) or the address didn't match closely enough.",
        }

    details = get_property_details(zillow_url)

    # Zestimate/price field names per HasData's documented common fields
    # (zestimate, price) - same caveat as _extract_zillow_url above,
    # worth confirming against a real response.
    arv_estimate = details.get("zestimate") or details.get("price")
    asking_price = details.get("price")

    return {
        "found": True,
        "arv_estimate": arv_estimate,
        "asking_price": asking_price,
        "zillow_url": zillow_url,
        "raw": details,
    }
