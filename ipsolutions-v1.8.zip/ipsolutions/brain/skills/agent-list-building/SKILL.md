---
name: agent-list-building
description: Use when building or refining a list of real estate agents to contact for outreach - the filtering logic (which agents to prioritize), the property-vs-agent-record distinction for phone number quality, and the real KPI benchmarks that define whether a campaign is healthy. Precedes agent-outreach-script (this is sourcing the list; that skill is the conversation itself).
---

# Skill: Agent List Building

Source: Matt Beard, real estate business-building training. Describes
the real process using a data platform (Batch Leads in the source
material - the same filtering logic applies to any comparable list
platform, e.g. PropStream, BatchLeads, etc.)

## The filtering sequence (in order)

1. **Draw a boundary around the target metro market** (see
   [[jv-partner-structuring]] for why one market, not many)
2. **Filter to residential, single-family** properties
3. **Filter to on-market listings only** (active or pending) - this is
   the single most important filter, see reasoning below
4. **Filter out anything above a reasonable price ceiling** for the
   market (e.g. exclude listings priced well above what a distressed-
   property buyer would ever pursue)
5. **Filter to individual/homeowner-represented listings**, excluding
   institutional sellers (iBuyers like Opendoor, Offerpad) - these are
   identifiable by brokerage name or listing agent's email domain.
   Institutional-owned listings are not going to have the kind of
   "ugly house" opportunity this outreach is built around.

## Why active listings first, not the full licensed-agent universe

Roughly **70% of everyone holding a real estate license did not sell
a single property in the prior year.** An agent with a current active
or pending listing is, by definition, not in that inactive majority -
they are a real, currently-transacting professional. Reaching out to
the full licensed-agent list (which can be 5-10x larger than the
active-listing list) is a valid second-tier expansion once the
active-listing list is exhausted, but it should not be the starting
point - response quality and phone number accuracy are both worse on
that broader list.

## Pull property records, not agent records, for phone numbers

Data platforms typically offer two different list types: a general
"agent outreach" list (one row per agent, aggregated), and property-
level records (one row per listing, with MLS-sourced contact info tied
to that specific listing). **Prefer the property-level record's phone
number over the generic agent-list number** - the MLS-sourced number
tied to an active listing tends to be more current and accurate than a
general aggregated agent contact list, which accumulates outdated
numbers for agents who've gone inactive, changed brokerages, or
retired.

## The real KPI benchmarks (what "healthy" looks like)

Use these to diagnose whether a campaign is actually working, not just
running:

- **500 texts/day**, once a campaign has matured (running at
  least 1-2 weeks), should produce roughly a **10% response rate**,
  yielding **3-8 off-market properties per day**
- That volume supports **1-2 closed deals per month** at most
- To close **1 deal per week**, the real volume needed is closer to
  **1,000 texts per day**
- **A2P registration takes 3-5 business days** to get approved before
  any real sending volume can begin (see the real, more precise 10DLC
  timeline already captured in prior sessions - this is the same
  underlying process, described here from the campaign-planning side)
- Overall lead-to-close ratio when running well: **12-20 off-market
  leads per closed deal** (matches the ratio already captured in
  [[agent-outreach-script]]); **20-30** is still healthy for a
  consistent, profitable operation that isn't yet optimized; anything
  meaningfully worse than that signals a real problem in how leads are
  being worked, not a lead-quality or lead-volume problem

## The diagnostic principle: more leads without more deals means a working problem, not a lead problem

If sending volume increases but closed deals don't follow, the honest
default conclusion is that leads aren't being worked correctly -
follow-up timing, lead categorization, or pipeline discipline - not
that the leads themselves are bad. This is diagnosable and fixable:
check follow-up cadence, check whether leads are actually being
categorized into the tier system (see [[agent-outreach-script]])
rather than sitting unprocessed, and check that the pipeline stages
are actually being used rather than leads going stale in an inbox.

## Speed matters more than the six-hour rule suggests

Once a lead reaches Tier 1 (gave an address), the ideal response time
is **minutes, not hours** - the earlier "within six hours" guidance is
a maximum, not a target. The faster a property-analysis and outreach
response happens after a Tier 1 tag, the higher the likelihood of
actually connecting before the seller/agent moves on or loses
interest. If a call isn't answered, retry daily until it connects,
rather than giving up after one attempt.
