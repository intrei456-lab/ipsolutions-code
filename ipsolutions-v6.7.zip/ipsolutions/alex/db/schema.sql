-- Alex (Dispositions) database schema.
-- Cross-agent reads: Chris's leads/contracts/offers/market_zips (read-only),
-- Taylor's handoffs/assignments_signed/emd_tracking (read-only, mirrored here).

CREATE TABLE IF NOT EXISTS deals (
    deal_id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER,                          -- FK to Chris's leads.lead_id (cross-db, not enforced)
    source_track TEXT DEFAULT 'OWN',          -- OWN / JV
    jv_partner_id INTEGER,
    dispo_status TEXT DEFAULT 'NEW',          -- NEW/OUTREACH/NEGOTIATING/ASSIGNMENT_SENT/ASSIGNMENT_SIGNED/TAYLOR_HANDOFF/CLOSED/DEAD
    exit_strategy TEXT DEFAULT 'WHOLESALE_ASSIGNMENT',  -- WHOLESALE_ASSIGNMENT/NOVATION/SUBTO/JUNIOR_BROKERAGE
    risk_tier TEXT DEFAULT 'STANDARD',        -- STANDARD/PROTECT_SPREAD, propagated read-only from Chris
    risk_tier_flipped_at TEXT,
    risk_tier_reason TEXT,
    closing_method TEXT DEFAULT 'STANDARD_ASSIGNMENT',  -- STANDARD_ASSIGNMENT/DOUBLE_CLOSE
    contract_price REAL,
    assignment_fee_target REAL,
    fp_facing_price REAL,                     -- contract_price + assignment_fee_target, NEVER expose contract_price to FP
    fp_assigned_id INTEGER,
    -- 5-Day Dispo tracking
    dispo_day INTEGER DEFAULT 0,              -- 0-5
    dispo_clock_started_at TEXT,
    first_blast_at TEXT,
    ttb_hours REAL,
    ttb_target_met INTEGER DEFAULT 0,
    day1_blast_ready INTEGER DEFAULT 0,
    walkthrough_interested_count INTEGER DEFAULT 0,
    magic_question_asked INTEGER DEFAULT 0,
    magic_question_bump_amount REAL DEFAULT 0,
    fomo_texts_sent_count INTEGER DEFAULT 0,
    dispo_extended INTEGER DEFAULT 0,
    dispo_extension_reason TEXT,
    -- Novation-specific
    novation_ips_profit_estimate REAL,
    novation_seller_net REAL,
    novation_listing_price REAL,
    novation_rehab_cost REAL,
    novation_listing_agent_id INTEGER,
    novation_listed_at TEXT,
    novation_contract_listing_clause INTEGER DEFAULT 0,
    novation_poa_signed INTEGER DEFAULT 0,
    novation_poa_notarized INTEGER DEFAULT 0,
    novation_poa_notarization TEXT,           -- IN_PERSON / VIRTUAL_RON
    novation_legal_cleared INTEGER DEFAULT 0,
    novation_offer_received_at TEXT,
    novation_offer_price REAL,
    -- Photos
    photos_status TEXT DEFAULT 'PENDING',     -- PENDING/DELIVERED
    photos_source TEXT,                       -- THOMAS_SELF (MD) / TASKRABBIT (FL/NC)
    photos_package_url TEXT,
    photos_delivered_at TEXT,
    -- Title / closing prep
    title_company TEXT,
    fp_type_recommended TEXT,                 -- COLD_CASH / PRIVATE_HARD_MONEY
    assignment_sent_at TEXT,
    assignment_signed_at TEXT,
    assignment_fee_collected REAL,
    taylor_handoff_at TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS financial_partners (
    fp_id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_name TEXT,
    contact_name TEXT,
    phone TEXT,
    email TEXT,
    linkedin_url TEXT,
    fp_type TEXT,                              -- COLD_CASH / PRIVATE_HARD_MONEY
    vip_tier TEXT DEFAULT 'COLD',               -- VIP / WARM / COLD
    dispo_tier TEXT DEFAULT 'C',                -- A / B / C (see fp_network/tiering.py)
    relationship_stage TEXT DEFAULT 'COLD',     -- COLD/WARM/ACTIVE/REPEAT
    source TEXT,                                -- PROACTIVE_HUNT/DEAL_SPECIFIC_HUNT/REFERRAL/RESIMPLI_BUYERS/MANUAL
    referral_source_fp_id INTEGER,
    buy_box_zips TEXT,                          -- JSON array
    buy_box_price_min REAL,
    buy_box_price_max REAL,
    buy_box_condition_preference TEXT,
    preferred_states TEXT,                      -- JSON array
    capacity_min REAL,
    capacity_max REAL,
    reputation_score INTEGER DEFAULT 50,
    total_deals_closed INTEGER DEFAULT 0,
    last_deal_closed_at TEXT,
    last_touch_at TEXT,
    last_touch_type TEXT,
    avg_response_hours REAL,
    proactive_touches_count INTEGER DEFAULT 0,
    verification_status TEXT DEFAULT 'UNVERIFIED', -- UNVERIFIED/VERIFICATION_PENDING/VERIFIED_BUYER/SUSPECTED_WHOLESALER/CONFIRMED_WHOLESALER
    verification_requested_at TEXT,
    verification_completed_at TEXT,
    verification_notes TEXT,
    pof_type TEXT,                               -- BANK_STATEMENT/LOC_LETTER/HUD_STATEMENT/HM_PREAPPROVAL
    last_closed_address TEXT,
    last_closed_date TEXT,
    entity_formation_date TEXT,
    entity_state_registry TEXT,
    entity_verified INTEGER DEFAULT 0,
    propwire_entity_confirmed INTEGER DEFAULT 0,
    wholesaler_red_flags TEXT,                   -- JSON array of red-flag codes
    wholesaler_red_flag_count INTEGER DEFAULT 0,
    redirected_to_jv INTEGER DEFAULT 0,
    is_test_data INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS jv_partners (
    jv_partner_id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_name TEXT,
    contact_name TEXT,
    email TEXT,
    phone TEXT,
    reputation_tier TEXT DEFAULT 'A',            -- A/B/C
    downgrade_count INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS jv_deals (
    jv_deal_id INTEGER PRIMARY KEY AUTOINCREMENT,
    jv_partner_id INTEGER REFERENCES jv_partners(jv_partner_id),
    status TEXT DEFAULT 'INTAKE',                -- INTAKE/RUN_TRACK_A/GRACE/REJECTED
    partner_quoted_arv REAL,
    partner_quoted_repairs REAL,
    verified_arv REAL,
    verified_repairs REAL,
    verified_mao REAL,
    comp_method TEXT,                            -- JSON array: RESIMPLI/CHATGPT_SUPPLEMENTAL/PROPWIRE_BROWSER
    comp_radius_blocks INTEGER DEFAULT 6,
    comp_lookback_months INTEGER DEFAULT 12,
    gate_run_count INTEGER DEFAULT 0,
    grace_window_started_at TEXT,
    grace_window_expires_at TEXT,
    affidavit_filed INTEGER DEFAULT 0,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS fp_outreach (
    outreach_id INTEGER PRIMARY KEY AUTOINCREMENT,
    fp_id INTEGER REFERENCES financial_partners(fp_id),
    deal_id INTEGER REFERENCES deals(deal_id),
    outreach_type TEXT,                          -- PROACTIVE/DEAL_SPECIFIC/POST_CLOSE_DEEPEN
    dispo_tier TEXT,                             -- A/B/C at time of send
    dispo_day INTEGER,                           -- 0-5
    channel TEXT,                                -- EMAIL/SMS/CALL/LINKEDIN/WALKTHROUGH
    direction TEXT DEFAULT 'OUTBOUND',
    personalization_basis TEXT,
    subject TEXT,
    message TEXT,
    fp_response TEXT DEFAULT 'NO_REPLY',
    fp_offer_amount REAL,
    sent_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS fp_hunt_log (
    hunt_id INTEGER PRIMARY KEY AUTOINCREMENT,
    mode TEXT,                                    -- MODE_1_PROACTIVE / MODE_2_DEAL_SPECIFIC
    source TEXT,                                  -- PROPWIRE/CRAIGSLIST/BIGGERPOCKETS/FACEBOOK_GROUP/REFERRAL/INVESTOR_BASE
    deal_id INTEGER REFERENCES deals(deal_id),
    new_fps_found INTEGER DEFAULT 0,
    duplicates_skipped INTEGER DEFAULT 0,
    propwire_credits_consumed INTEGER DEFAULT 0,
    run_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS assignments_signed (
    assignment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    deal_id INTEGER REFERENCES deals(deal_id),
    fp_id INTEGER REFERENCES financial_partners(fp_id),
    esign_provider TEXT,
    esign_doc_id TEXT,
    doc_url TEXT,
    assignment_fee REAL,
    signed_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS emd_tracking (
    emd_id INTEGER PRIMARY KEY AUTOINCREMENT,
    deal_id INTEGER REFERENCES deals(deal_id),
    total_emd_amount REAL,
    non_refundable_portion REAL DEFAULT 2000,
    refundable_portion REAL,
    emd_tier TEXT,
    held_by TEXT,                                 -- title company name
    received_at TEXT,
    refundable_status TEXT DEFAULT 'HELD'
);

CREATE TABLE IF NOT EXISTS handoffs (
    handoff_id INTEGER PRIMARY KEY AUTOINCREMENT,
    deal_id INTEGER REFERENCES deals(deal_id),
    direction TEXT,                                -- INBOUND_FROM_CHRIS / OUTBOUND_TO_TAYLOR
    to_team_member TEXT,
    reason TEXT,
    status TEXT DEFAULT 'ACKNOWLEDGED',
    risk_tier TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS dispo_kpi (
    kpi_date TEXT PRIMARY KEY,
    active_deals_own INTEGER DEFAULT 0,
    active_deals_jv INTEGER DEFAULT 0,
    avg_days_on_market REAL,
    fp_touches_today INTEGER DEFAULT 0,
    deals_touched_today INTEGER DEFAULT 0,
    assignments_sent_today INTEGER DEFAULT 0,
    assignments_signed_today INTEGER DEFAULT 0,
    avg_assignment_fee REAL,
    total_assignment_fee REAL,
    avg_ttb_hours REAL,
    ttb_breaches INTEGER DEFAULT 0,
    tier_a_count INTEGER DEFAULT 0,
    tier_b_count INTEGER DEFAULT 0,
    tier_c_count INTEGER DEFAULT 0,
    alerts_fired_today INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS ceo_alerts (
    alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_type TEXT NOT NULL,
    severity TEXT DEFAULT 'WARN',
    deal_id INTEGER REFERENCES deals(deal_id),
    message TEXT,
    fired_at TEXT DEFAULT (datetime('now')),
    email_sent_at TEXT
);

CREATE TABLE IF NOT EXISTS resimpli_sync_queue (
    queue_id INTEGER PRIMARY KEY AUTOINCREMENT,
    deal_id INTEGER REFERENCES deals(deal_id),
    action TEXT NOT NULL,
    detail TEXT,
    status TEXT DEFAULT 'QUEUED',
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS a2p_compliance_log (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    fp_id INTEGER REFERENCES financial_partners(fp_id),
    channel TEXT,
    sent_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS taskrabbit_queue (
    task_id INTEGER PRIMARY KEY AUTOINCREMENT,
    deal_id INTEGER REFERENCES deals(deal_id),
    status TEXT DEFAULT 'QUEUED',
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_deals_status ON deals(dispo_status);
CREATE INDEX IF NOT EXISTS idx_deals_dispo_day ON deals(dispo_day);
CREATE INDEX IF NOT EXISTS idx_fp_vip_tier ON financial_partners(vip_tier);
CREATE INDEX IF NOT EXISTS idx_fp_dispo_tier ON financial_partners(dispo_tier);
CREATE INDEX IF NOT EXISTS idx_fp_test_data ON financial_partners(is_test_data);
CREATE INDEX IF NOT EXISTS idx_outreach_deal ON fp_outreach(deal_id);
CREATE INDEX IF NOT EXISTS idx_outreach_fp ON fp_outreach(fp_id);
