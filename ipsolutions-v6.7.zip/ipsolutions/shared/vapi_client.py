"""
Vapi integration - triggers Brielle (the voice assistant already built and
configured in Thomas's Vapi account) to place real calls. This sidesteps
A2P 10DLC entirely, since voice calls aren't SMS.

Real API confirmed against Vapi's docs (docs.vapi.ai/api-reference/calls/create):
POST https://api.vapi.ai/call/phone, Bearer auth, phoneNumberId + assistantId
+ customer.number. Per-call prompt overrides use assistantOverrides.model.messages
(see docs.vapi.ai/assistants/dynamic-variables) - this lets every call type use
its own real script (shared/vapi_prompts.py) off one base Vapi assistant, instead
of every call type sharing a single generic prompt.

NOTE: requires real VAPI_API_KEY/VAPI_ASSISTANT_ID/VAPI_PHONE_NUMBER_ID and
network access - not testable in this sandbox. Worth double-checking in the
Vapi dashboard after the first real test call that assistantOverrides actually
reaches Brielle's dual-trigger logic as expected.

BUGFIX NOTE: trigger_setup_call previously lost its own `def` line during an
earlier edit in this session, silently merging its body into
trigger_seller_followup_call as unreachable dead code - meaning any code that
called trigger_setup_call would have failed with a NameError. Fixed here.
"""

import os

import requests

from shared.vapi_prompts import (
    AGENT_OUTREACH_PROMPT,
    SELLER_INITIAL_CALL_PROMPT,
    SELLER_FOLLOWUP_PROMPT,
    SETUP_CALL_PROMPT,
)

VAPI_BASE_URL = "https://api.vapi.ai"


def _get_credentials() -> dict:
    from shared.config import CURRENT_PHASE_VOICE

    if CURRENT_PHASE_VOICE < 2:
        raise RuntimeError(
            "BLOCKED BY PHASE 1 VOICE RULE (LOCKED): Chris does not make "
            "outbound voice calls in Phase 1 - the operator dials through "
            "REsimpli and Chris only transcribes/grades the recording. "
            "This function is real Phase 2 (Vapi/Synthflow AI voice) "
            "functionality, not yet in scope. Set CURRENT_PHASE_VOICE = 2 "
            "in shared/config.py once Thomas has decided Phase 2 voice is "
            "genuinely ready - this is independent of A2P/SMS approval."
        )

    api_key = os.environ.get("VAPI_API_KEY")
    assistant_id = os.environ.get("VAPI_ASSISTANT_ID")
    phone_number_id = os.environ.get("VAPI_PHONE_NUMBER_ID")
    if not all([api_key, assistant_id, phone_number_id]):
        raise RuntimeError(
            "VAPI_API_KEY, VAPI_ASSISTANT_ID, and VAPI_PHONE_NUMBER_ID must all be "
            "set in .env for Brielle's calling integration to work."
        )
    return {"api_key": api_key, "assistant_id": assistant_id, "phone_number_id": phone_number_id}


def _place_call(creds: dict, phone: str, name: str, metadata: dict, system_prompt: str) -> dict:
    """Shared real call-placement logic - every trigger function below
    builds its own metadata/prompt and calls this once, instead of
    duplicating the requests.post block four times."""
    payload = {
        "phoneNumberId": creds["phone_number_id"],
        "assistantId": creds["assistant_id"],
        "customer": {"number": phone, "name": name},
        "metadata": metadata,
        "assistantOverrides": {
            "model": {"messages": [{"role": "system", "content": system_prompt}]}
        },
    }
    response = requests.post(
        f"{VAPI_BASE_URL}/call/phone",
        headers={"Authorization": f"Bearer {creds['api_key']}", "Content-Type": "application/json"},
        json=payload,
        timeout=15,
    )
    response.raise_for_status()
    return response.json()


def trigger_agent_outbound_call(agent_name: str, agent_phone: str, agent_id: int) -> dict:
    """
    Triggers Brielle to call a real estate agent (cold outreach). Tags the
    customer as an agent via metadata so Brielle's AGENT OUTREACH MODE
    dual-trigger fires (per the routing logic worked out directly with
    Vapi) - this is the 'Chris will also let her know it's an agent when
    he sends it through' tagging Thomas described.
    """
    creds = _get_credentials()
    return _place_call(
        creds, agent_phone, agent_name,
        metadata={"isAgent": True, "agentType": "agent", "source": "chris_agent_outreach", "agent_id": agent_id},
        system_prompt=AGENT_OUTREACH_PROMPT,
    )


def trigger_setup_call(agent_name: str, agent_phone: str, agent_id: int, lead_id: int) -> dict:
    """
    Triggers Brielle's SETUP CALL specifically - distinct from the general
    agent-outreach call above. This is the diagnostic call that happens
    automatically once an agent hits Tier 1 with a new address (see
    chris/skills/setup-call-script). Tagged with call_type=setup_call and
    lead_id in metadata so /vapi/webhook can tell it apart from a general
    outreach call and knows which lead's setup_call_outcome to update.

    Vapi echoes back the metadata sent here in the end-of-call-report
    webhook payload - this is what makes automatic outcome classification
    possible without any manual tagging after the fact.
    """
    creds = _get_credentials()
    return _place_call(
        creds, agent_phone, agent_name,
        metadata={
            "isAgent": True, "agentType": "agent", "source": "chris_setup_call",
            "call_type": "setup_call", "agent_id": agent_id, "lead_id": lead_id,
        },
        system_prompt=SETUP_CALL_PROMPT,
    )


def trigger_seller_initial_call(lead_name: str, lead_phone: str, lead_id: int) -> dict:
    """
    Triggers Brielle's FIRST call to a seller directly (not a follow-up,
    not an agent). Uses Keith Everett's full DM-gate + 7-pain-dig framework.
    """
    creds = _get_credentials()
    return _place_call(
        creds, lead_phone, lead_name,
        metadata={"isAgent": False, "source": "chris_seller_initial", "call_type": "seller_initial", "lead_id": lead_id},
        system_prompt=SELLER_INITIAL_CALL_PROMPT,
    )


def trigger_seller_followup_call(lead_name: str, lead_phone: str, lead_id: int, followup_reason: str) -> dict:
    """
    Triggers Brielle to call a SELLER for a scheduled follow-up (not an
    agent, not a first call) - the actual send side of
    chris/followup/cadence.py's timing logic, which previously computed
    when to follow up but had nothing that actually placed the call.
    Tagged call_type=seller_followup so /vapi/webhook can log the outcome
    against the right lead without confusing it with an agent call.

    Now injects real Context-Aware Memory - a summary of this lead's
    actual prior conversation history - into the call prompt, so this
    follow-up references what was really said before instead of
    starting cold every time.
    """
    from chris.followup.memory import get_recent_conversation_summary

    creds = _get_credentials()
    memory_summary = get_recent_conversation_summary(lead_id)
    prompt_with_memory = (
        f"{SELLER_FOLLOWUP_PROMPT}\n\n"
        f"REAL PRIOR CONVERSATION HISTORY FOR THIS LEAD (reference this directly, "
        f"don't start over):\n{memory_summary}\n\n"
        f"REASON FOR THIS FOLLOW-UP: {followup_reason}"
    )
    return _place_call(
        creds, lead_phone, lead_name,
        metadata={
            "isAgent": False, "source": "chris_seller_followup", "call_type": "seller_followup",
            "lead_id": lead_id, "followup_reason": followup_reason,
        },
        system_prompt=prompt_with_memory,
    )
