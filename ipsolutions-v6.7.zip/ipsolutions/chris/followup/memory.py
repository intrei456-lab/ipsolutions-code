"""
Context-Aware Memory - the piece that lets Brielle's follow-up calls
actually reference what a seller said before, instead of starting cold
every time. Previously SELLER_FOLLOWUP_PROMPT said "reference the prior
conversation" but nothing ever supplied what that conversation was.

Two steps: pull the real recent conversation rows for a lead, then
summarize them into something short enough to inject into a call's
system prompt (the raw transcripts are too long and too noisy to hand
to a live voice call directly).
"""

from chris.db.db import get_connection
from shared.llm_client import draft_content


def get_recent_conversation_summary(lead_id: int, max_conversations: int = 5) -> str:
    """
    Returns a short, real summary of this lead's actual conversation
    history, or an honest "no prior conversation" string if there isn't
    one - never fabricates history that doesn't exist.
    """
    conn = get_connection()
    rows = conn.execute(
        "SELECT channel, direction, outcome, transcript, body, call_grade, personality_read, timestamp "
        "FROM conversations WHERE lead_id = ? ORDER BY timestamp DESC LIMIT ?",
        (lead_id, max_conversations),
    ).fetchall()
    conn.close()

    if not rows:
        return "No prior conversation on file for this lead - this is effectively a first real contact."

    # Oldest-first for the summarizer, so the narrative reads in the order it happened
    rows = list(reversed(rows))
    raw_history = []
    for r in rows:
        content = r["transcript"] or r["body"] or ""
        if not content.strip():
            continue
        raw_history.append(
            f"[{r['timestamp']}] {r['channel']} ({r['direction']})"
            f"{' - grade ' + r['call_grade'] if r['call_grade'] else ''}: {content[:800]}"
        )

    if not raw_history:
        return "Prior contact is logged for this lead, but no transcript/content was captured."

    system_prompt = """Summarize this seller's real conversation history for Brielle,
who is about to place a follow-up call. Extract ONLY what was actually said - never invent
detail. Keep it to 3-5 sentences: their stated pain/reason for selling, their price
position or objections if any, and anything specific worth referencing by name so this
follow-up doesn't feel like starting over."""

    result = draft_content(
        system_prompt, "\n\n".join(raw_history), max_tokens=250, check_safety=False
    )
    return result["text"].strip()
