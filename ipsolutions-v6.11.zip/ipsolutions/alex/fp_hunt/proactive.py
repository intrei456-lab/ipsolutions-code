"""
Mode 1: Proactive FP building — builds a warm bench BEFORE deals arrive.
The #1 goal is collecting buy-box data, not introducing the company.
"""

from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Mode allocation by pipeline depth
# ---------------------------------------------------------------------------

def mode_allocation(active_deals_count: int) -> dict:
    """
    Pipeline < 3 active deals -> 60% Mode 1 (proactive) / 40% Mode 2 (deal-specific)
    Pipeline >= 3 active deals -> 20% Mode 1 / 80% Mode 2
    Mode 1 never stops entirely, even with a full pipeline.
    """
    if active_deals_count < 3:
        return {"mode_1_pct": 0.60, "mode_2_pct": 0.40}
    return {"mode_1_pct": 0.20, "mode_2_pct": 0.80}


# ---------------------------------------------------------------------------
# The 5 buy-box questions (buy-box-first, not company-first)
# ---------------------------------------------------------------------------

BUY_BOX_QUESTIONS = [
    "Are you still actively buying right now?",
    "What areas or ZIP codes are you focused on?",
    "What price range works for you?",
    "What condition — distressed/as-is OK, or turnkey only?",
    "Cash or financing? What's your typical close timeline?",
]

PROACTIVE_OUTREACH_PRINCIPLE = (
    "Every proactive touch leads with buy-box questions, not a pitch about "
    "the company. Same peer-to-peer tone throughout - never expose "
    "internal FP categorization (tiers, scores, match logic) to the FP "
    "themselves."
)


# ---------------------------------------------------------------------------
# VIP tier promotion logic (distinct axis from A/B/C dispo tier -
# this is about buy-box completeness, dispo tier is about proven track record)
# ---------------------------------------------------------------------------

def compute_vip_tier(
    buy_box_zips: list | None,
    buy_box_price_min: float | None,
    buy_box_price_max: float | None,
    buy_box_condition_preference: str | None,
    fp_type_confirmed: bool,
) -> str:
    """
    VIP: all 5 buy-box fields populated -> gets FIRST look at every matching deal
    WARM: some fields populated -> gets deals after VIPs pass
    COLD: no buy-box response -> gets deals last, reduce outreach after 3 unanswered touches
    """
    fields = [buy_box_zips, buy_box_price_min, buy_box_price_max,
              buy_box_condition_preference, fp_type_confirmed]
    populated_count = sum(1 for f in fields if f)

    if populated_count == 5:
        return "VIP"
    if populated_count > 0:
        return "WARM"
    return "COLD"


def should_reduce_outreach_frequency(proactive_touches_count: int, has_responded: bool) -> bool:
    """No response after 3 proactive touches -> stays COLD, drop to once/30 days."""
    return proactive_touches_count >= 3 and not has_responded



COLD_FP_REDUCED_CADENCE_DAYS = 30

# ---------------------------------------------------------------------------
# Real hunt logging - the piece that was missing. mode_allocation() and the
# source list above were pure logic with nothing calling them; these two
# functions are what actually write to fp_hunt_log and trigger real CEO
# tasks, mirroring how Chris's Mat Beard engine actually runs rather than
# just existing as unused math.
# ---------------------------------------------------------------------------

def log_fp_hunt(mode: str, source: str, deal_id: int | None = None,
                 new_fps_found: int = 0, duplicates_skipped: int = 0) -> int:
    """
    Records a real hunt result. Investor Base and PropWire have no API -
    Thomas (or whoever runs the pull) reports back what they found via
    this function/its endpoint, closing the loop so mode_allocation's
    "Mode 1 never stops entirely" rule can actually be checked against
    real history instead of assumed.
    """
    from alex.db.db import get_connection as get_alex_connection
    conn = get_alex_connection()
    try:
        cur = conn.execute(
            """
            INSERT INTO fp_hunt_log (mode, source, deal_id, new_fps_found, duplicates_skipped)
            VALUES (?, ?, ?, ?, ?)
            """,
            (mode, source, deal_id, new_fps_found, duplicates_skipped),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def trigger_deal_specific_hunt(deal_id: int, address: str, city: str, state: str) -> None:
    """
    Fires the moment a new FP-network-bound deal lands - the real
    equivalent of Chris reaching out to gatekeepers the moment a lead
    comes in. Investor Base can't be called by API, so this creates a
    real CEO alert with the exact radius-search task instead of
    pretending to automate a pull that has to happen by hand.
    """
    from alex.db.db import get_connection as get_alex_connection
    log_fp_hunt(mode="MODE_2_DEAL_SPECIFIC", source="INVESTOR_BASE", deal_id=deal_id)
    conn = get_alex_connection()
    try:
        conn.execute(
            """
            INSERT INTO ceo_alerts (alert_type, severity, deal_id, message)
            VALUES ('FP_HUNT_NEEDED', 'WARN', ?, ?)
            """,
            (deal_id, f"Mode 2 checkbook hunt needed - pull Investor Base "
                       f"5-mile radius around {address}, {city}, {state}."),
        )
        conn.commit()
    finally:
        conn.close()


def next_proactive_hunt_source(days_since_last_mode1_hunt: int) -> HuntSource | None:
    """
    Mode 1 general prospecting never stops entirely, per the real
    allocation rule above. If it's been a week or more since the last
    logged Mode 1 hunt, rotates to the next source in the list rather
    than always suggesting the same one.
    """
    if days_since_last_mode1_hunt < 7:
        return None
    rotation_index = (days_since_last_mode1_hunt // 7) % len(PROACTIVE_HUNT_SOURCES)
    return PROACTIVE_HUNT_SOURCES[rotation_index]


# ---------------------------------------------------------------------------
# Proactive hunt sources
# ---------------------------------------------------------------------------

@dataclass
class HuntSource:
    name: str
    description: str
    log_source_code: str


PROACTIVE_HUNT_SOURCES: list[HuntSource] = [
    HuntSource(
        name="PropWire cash-buyer search",
        description=(
            "Search for LLCs/individuals that purchased 3+ properties via "
            "cash in the last 12 months within our market ZIPs. On-demand "
            "browser session, ~50-150 credits per pull, first session "
            "requires manual login."
        ),
        log_source_code="PROPWIRE",
    ),
    HuntSource(
        name="Investor Base",
        description=(
            "Confirmed real, live tool (Thomas uses this directly) - radius-based "
            "search around a specific property or ZIP for recent cash purchasers "
            "and flippers, shown on a map with a bulk-downloadable contact list. "
            "This is THE real checkbook-hunting tool from the actual Matt Beard "
            "source material, distinct from the generic PropWire pull above. "
            "Real benchmark from source material: a single ~5-mile-radius pull "
            "around one property returned 83 matched buyers in one search."
        ),
        log_source_code="INVESTOR_BASE",
    ),
    HuntSource(
        name="Craigslist 'we buy houses' ads",
        description="Scrape for ads containing 'we buy houses' / 'cash for homes' / 'sell your house fast' in our markets.",
        log_source_code="CRAIGSLIST",
    ),
    HuntSource(
        name="BiggerPockets forums",
        description="Search for users posting buy-box criteria in our markets; extract stated ZIPs/price range/condition preference directly from their post.",
        log_source_code="BIGGERPOCKETS",
    ),
    HuntSource(
        name="Facebook RE investor groups",
        description="Draft outreach for Thomas to post/send in local investor groups.",
        log_source_code="FACEBOOK_GROUP",
    ),
    HuntSource(
        name="Referral from existing FPs",
        description="After any successful deal or warm conversation: 'Who else in your network does deals in [ZIP area]?'",
        log_source_code="REFERRAL",
    ),
]
