"""
Shared email sending — Gmail SMTP integration used by all three agents
to send as ipsolutionsmd@gmail.com (operational/internal) or
info@intensepropertysolutions.com (seller-facing), matching the routing
already defined in shared/config.py.

SETUP REQUIRED (one-time, free, no paid service needed):
  1. Enable 2-factor authentication on the sending Gmail account
  2. Generate an "App Password": Google Account -> Security -> 2-Step
     Verification -> App Passwords -> generate one for "Mail"
  3. Put that 16-character app password in .env as GMAIL_APP_PASSWORD
     (NOT your real Gmail password - the app password is a separate,
     revocable credential scoped just to this use)
  4. Put the sending address in .env as GMAIL_SENDER_ADDRESS

This uses Gmail's SMTP servers directly (smtp.gmail.com:587) - no
external paid API, no separate hosting requirement beyond wherever the
rest of this app already runs.

NOTE: Gmail enforces sending limits (~500/day for regular Gmail accounts,
~2000/day for Workspace). If Chris's agent outreach volume grows past
that, a dedicated transactional email provider (e.g. Postmark, SendGrid)
would be the next step - but for KPI reports, briefs, CEO alerts, and
FP outreach at the current scale, Gmail SMTP is sufficient and free.
"""

import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from shared.config import OPERATOR_EMAIL, SELLER_FACING_EMAIL
from shared.terminology import check_terminology

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587


def _get_credentials() -> tuple[str, str]:
    sender = os.environ.get("GMAIL_SENDER_ADDRESS")
    app_password = os.environ.get("GMAIL_APP_PASSWORD")
    if not sender or not app_password:
        raise RuntimeError(
            "GMAIL_SENDER_ADDRESS and GMAIL_APP_PASSWORD must be set in .env. "
            "See the setup instructions in shared/email.py's module docstring."
        )
    return sender, app_password


def send_email(
    to_address: str,
    subject: str,
    body: str,
    check_safety: bool = True,
) -> dict:
    """
    Sends a plain-text email via Gmail SMTP. Runs the terminology filter
    on the body before sending (auto-fixes safe misspellings like
    innovation->novation, raises on context-sensitive violations like
    "cash buyers" so a human catches it rather than it silently going out).
    """
    if check_safety:
        result = check_terminology(body)
        if not result.clean:
            raise ValueError(
                f"Terminology violation in outbound email (subject: {subject!r}): "
                f"{result.violations}. Fix before sending."
            )
        body = result.auto_fixed_text

    sender, app_password = _get_credentials()

    msg = MIMEMultipart()
    msg["From"] = sender
    msg["To"] = to_address
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(sender, app_password)
            server.sendmail(sender, to_address, msg.as_string())
        return {"sent": True, "to": to_address, "subject": subject}
    except smtplib.SMTPAuthenticationError as exc:
        return {
            "sent": False,
            "error": "auth_failed",
            "detail": (
                "Gmail rejected the credentials. Make sure GMAIL_APP_PASSWORD "
                "is an App Password (not your regular Gmail password) and "
                "2FA is enabled on the account."
            ),
        }
    except Exception as exc:  # noqa: BLE001
        return {"sent": False, "error": "send_failed", "detail": str(exc)}


def send_operator_alert(subject: str, body: str) -> dict:
    """Convenience wrapper for internal alerts (CEO alerts, KPI reports) -
    always goes to ipsolutionsmd@gmail.com per shared/config.py routing."""
    return send_email(OPERATOR_EMAIL, subject, body)


def send_seller_facing(to_address: str, subject: str, body: str) -> dict:
    """Convenience wrapper for seller-facing docs - uses the seller-facing
    from-address routing convention, though the actual From header still
    resolves to whatever GMAIL_SENDER_ADDRESS is configured. If Thomas
    wants seller-facing mail to literally come FROM
    info@intensepropertysolutions.com, that address needs its own Gmail/
    Workspace account and app password - this function is a placeholder
    for that until it's set up."""
    return send_email(to_address, subject, body)
