"""
Address -> lat/lng, used once per lead on intake so the Hot Leads map
has real pins instead of nothing.

Uses the US Census Bureau's free geocoder — no API key, no cost, no
rate-limit surprises, and every lead here is a US address anyway. This
intentionally fails soft: geocoding is a nice-to-have for the map, not
something that should ever block a lead from being saved. If it fails
or times out, the lead still gets inserted with lat/lng = NULL, and
just won't show up as a pin until re-geocoded.
"""

import requests

CENSUS_GEOCODER_URL = "https://geocoding.geo.census.gov/geocoder/locations/onelineaddress"
TIMEOUT_SECONDS = 5


def geocode_address(address: str, city: str, state: str, zip_code: str) -> tuple[float | None, float | None]:
    one_line = f"{address}, {city}, {state} {zip_code}"
    try:
        resp = requests.get(
            CENSUS_GEOCODER_URL,
            params={"address": one_line, "benchmark": "Public_AR_Current", "format": "json"},
            timeout=TIMEOUT_SECONDS,
        )
        resp.raise_for_status()
        matches = resp.json().get("result", {}).get("addressMatches", [])
        if not matches:
            return None, None
        coords = matches[0]["coordinates"]
        return float(coords["y"]), float(coords["x"])  # y=lat, x=lng
    except Exception:  # noqa: BLE001 — geocoding must never break lead intake
        return None, None
