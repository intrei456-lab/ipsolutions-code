"""
Shared configuration constants for the IPSolutions agent system.
Single source of truth referenced by Chris, Alex, and Taylor so nothing drifts
between agents (EMD tiers, title routing, ZIPs, branding).
"""

# ---------------------------------------------------------------------------
# 45 in-market ZIPs (7 MD primary / 18 FL secondary / 20 NC tertiary)
# TODO(Thomas): confirm/replace with your exact 45 ZIPs. Placeholders below
# use the ZIPs that appeared in the FL county map + screenshots you sent.
# ---------------------------------------------------------------------------

MARKET_ZIPS = {
    "MD": {
        "tier": "primary",
        "multifamily_strong": False,
        "zips": [
            "21206", "21212", "21213", "21214", "21216", "21218", "21239",
        ],
    },
    "FL": {
        "tier": "secondary",
        "multifamily_strong": False,
        "zips": [
            "32901", "32955",                       # Brevard
            "33060", "33064", "33068",               # Broward
            "33169",                                 # Miami-Dade
            "33405", "33407", "33415", "33435", "33487",  # Palm Beach
            "33455",                                 # Treasure Coast (Martin)
            "33853", "33881",                        # Polk
            "34748",                                 # Lake
            "34946", "34947", "34950",                # Treasure Coast (St. Lucie)
        ],
    },
    "NC": {
        "tier": "tertiary",
        "multifamily_strong": True,
        "zips": [
            "27262", "27265", "27284",
            "27526", "27608",
            "28117",
            "28301", "28302", "28303", "28304", "28305", "28306", "28307",
            "28308", "28309", "28310", "28311", "28312", "28313", "28314",
        ],
    },
}

# Flat lookup: zip -> (state, region_tier, multifamily_strong)
ZIP_LOOKUP = {
    z: {"state": state, "tier": info["tier"], "multifamily_strong": info["multifamily_strong"]}
    for state, info in MARKET_ZIPS.items()
    for z in info["zips"]
}

# ---------------------------------------------------------------------------
# FL county government scout modules (8 counties)
# ---------------------------------------------------------------------------

FL_COUNTY_MAP = {
    "Brevard": {
        "zips": ["32901", "32955"],
        "portal": "brevardclerk.us / brevardcounty.us",
        "data_types": ["tax_delinquent", "code_violations"],
    },
    "Broward": {
        "zips": ["33060", "33064", "33068"],
        "portal": "broward.org/RecordsTaxesTreasury",
        "data_types": ["tax_delinquent", "code_violations", "liens"],
    },
    "Palm Beach": {
        "zips": ["33405", "33407", "33415", "33435", "33487"],
        "portal": "pbcgov.org/papa",
        "data_types": ["tax_delinquent", "code_violations", "liens"],
    },
    "Miami-Dade": {
        "zips": ["33169"],
        "portal": "miamidade.gov/finance",
        "data_types": ["tax_delinquent", "code_violations", "liens"],
    },
    "Polk": {
        "zips": ["33853", "33881"],
        "portal": "polktaxes.com",
        "data_types": ["tax_delinquent", "code_violations"],
    },
    "Lake": {
        "zips": ["34748"],
        "portal": "lakecountyfl.gov",
        "data_types": ["tax_delinquent", "code_violations"],
    },
    "St. Lucie": {
        "zips": ["34946", "34947", "34950"],
        "portal": "stlucieclerk.com",
        "data_types": ["tax_delinquent", "code_violations", "liens"],
    },
    "Martin": {
        "zips": ["33455"],
        "portal": "martin.fl.us",
        "data_types": ["tax_delinquent", "code_violations"],
    },
}

FL_LEAD_CAP_PER_RUN = 50
FL_COUNTIES_PER_RUN = 3
FL_AUTO_PAUSE_FAILURES = 3

# ---------------------------------------------------------------------------
# EMD tiers (single wire to title-company escrow, $2,000 non-refundable
# carve-out to Assignor). Shared by Alex (assignment) and Taylor (verification).
# ---------------------------------------------------------------------------

NON_REFUNDABLE_CARVEOUT = 2000

EMD_TIERS = {
    14: {"total": 3000, "non_refundable": 2000, "applies_to_price": 1000},
    30: {"total": 5000, "non_refundable": 2000, "applies_to_price": 3000},
    60: {"total_min": 7500, "total_max": 10000, "non_refundable": 2000},
    "novation_200k_plus": {"total_min": 5000, "total_max": 10000, "non_refundable": 2000},
}


def emd_tier_for_close_window(days_to_close: int) -> dict:
    """Return the EMD tier dict for a given close window in days."""
    if days_to_close <= 14:
        return EMD_TIERS[14]
    if days_to_close <= 30:
        return EMD_TIERS[30]
    return EMD_TIERS[60]


# ---------------------------------------------------------------------------
# Title company routing (state -> primary/secondary)
# ---------------------------------------------------------------------------

TITLE_COMPANY_DIRECTORY = {
    "MD": {"primary": "Maryland First Title", "secondary": None, "contact": None},
    "FL": {"primary": "Donna Hearne-Gousse PA", "secondary": "Liberty Title", "contact": "Donna Hearne-Gousse"},
    "NC": {"primary": None, "secondary": None, "contact": None},  # TBD - Taylor must alert Thomas on first NC deal
}

# Additional title companies known to Alex (not yet in Taylor's primary
# directory) - relevant for novation deals specifically. Per Thomas,
# these should be merged into TITLE_COMPANY_DIRECTORY once needed live:
#   - Dulaney Title (Towson, MD)
#   - Cooperative Title (FL) - used for double-close transactional funding
#   - TitleClearing.net (48 states) - novation-experienced, per Rich's
#     material on novation title company requirements
ALEX_REFERENCE_TITLE_COMPANIES = {
    "Dulaney Title & Escrow": {"state": "MD", "notes": "Towson, MD - handled Biddle St deal"},
    "Cooperative Title Agency": {"state": "FL", "notes": "Cooper City, FL - handled S Ocean Blvd deal; used for double-close / transactional funding"},
    "TitleClearing.net": {"state": "ALL", "notes": "Operates in 48 states, novation-experienced - Rich's recommended novation specialist"},
    "Abode Settlements": {"state": "MD", "notes": "Stored in Alex's reference docs, not yet in Taylor's primary directory"},
    "Maryland First Title LTD (contact: Kim Wade)": {
        "state": "MD",
        "notes": "kfw@hsclaw.com, (410) 863-1552 ext 319 - specific contact at the primary MD title company",
    },
}

# ---------------------------------------------------------------------------
# Novation defaults
# ---------------------------------------------------------------------------

NOVATION_MIN_IPS_PROFIT = 15000
NOVATION_DEFAULTS = {
    "agent_commission_pct": 0.04,
    "closing_cost_pct": 0.02,
    "flipper_profit_pct": 0.12,
    "loan_interest_pct": 0.12,
    "reno_per_sqft": 15,
    "holding_months": 2.5,
}

# ---------------------------------------------------------------------------
# Offer ladder (cash tiers)
# ---------------------------------------------------------------------------

CASH_TIER_MULTIPLIERS = {"T1": 0.60, "T2": 0.65, "T3": 0.70}
MAO_BREATHING_ROOM = 15000

# ---------------------------------------------------------------------------
# A2P 10DLC Phase 1 compliance caps
# ---------------------------------------------------------------------------

PHASE1_SMS_CAP_PER_DAY = 30  # personal-cell manual texts, relationship-based only
PHASE1_SPEED_TO_LEAD_MINUTES = 2

# ---------------------------------------------------------------------------
# Branding
# ---------------------------------------------------------------------------

BRAND = {
    "charcoal": "#1A1A1A",
    "gold_light": "#C9A961",
    "gold_dark": "#D4A017",
    "company_name": "Intense Property Solutions LLC",
    "tagline": "REAL SERVICE. REAL SOLUTIONS.",
}

# ---------------------------------------------------------------------------
# Terminology lock (banned -> required replacement)
# Used by shared/terminology.py's filter; kept here so all agents reference
# the same list.
# ---------------------------------------------------------------------------

BANNED_TERMS = {
    "buyer": "financial partner",
    "buyers": "financial partners",
    "cash buyer": "financial partner",
    "cash buyers": "financial partners",
    "investor list": "funding network",
    "wholesale": "assignment",  # context-dependent; filter flags for manual review
    "reselling": "assignment",
    "innovation": "novation",  # common misspelling catch, NOT a synonym swap
}

ROLE_FRAMEWORK = {
    "property_specialist": "Property Specialist",
    "transactional_specialist": "Transactional Specialist",
    "acquisition_specialist": "Buyer/Acquisition Specialist",
    "finance_manager": "Vanessa Carter",
    "finance_department": "Finance Department",
    "funds_to_the_side": "Funds to the Side",
}

# Why this terminology exists (source: Keith Everett's "expert terminology"
# transcript) - not just enforcement, but the actual reasoning, kept here
# for anyone maintaining this system later:
#   - "Property Specialist" not "boots on the ground" -> sounds professional
#     to the seller, not internal-jargon-casual.
#   - "Transactional Specialist" not "transactional coordinator" -> same idea,
#     smoother handoff framing for the seller.
#   - "Finance Department" / "Finance Manager" -> borrowed deliberately from
#     the car-dealership sales model; creates an internal-approval-authority
#     perception that supports the Higher-Authority Hold-Back tactic.
#   - "Financial partners" not "cash buyers" or "contractors" -> per Keith,
#     literally caused a real problem once: people showed up to a property
#     introduced as "contractors" and didn't look the part. The company
#     switched to "financial partners" to cover cash buyers, contractors,
#     AND actual capital partners under one consistent, vaguer term.
#   - "Company policy" (e.g. the 24-hour funds window) -> converts an
#     arbitrary internal choice into an external-sounding rule, which
#     manufactures urgency without appearing to pressure the seller directly.
TERMINOLOGY_RATIONALE_NOTE = (
    "This vocabulary set was deliberately designed to (a) sound more "
    "professional than casual internal jargon, and (b) manufacture "
    "perceived authority/urgency (finance department, company policy) that "
    "supports specific negotiation tactics like the Higher-Authority "
    "Hold-Back. Worth knowing this is a persuasion design, not just a "
    "style guide, when deciding how far to lean on it."
)

# ---------------------------------------------------------------------------
# Operator / email routing
# ---------------------------------------------------------------------------

OPERATOR_EMAIL = "ipsolutionsmd@gmail.com"        # internal alerts/KPI
SELLER_FACING_EMAIL = "info@intensepropertysolutions.com"  # external docs
