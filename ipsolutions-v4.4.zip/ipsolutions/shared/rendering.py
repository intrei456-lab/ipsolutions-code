"""
Spread-invisibility rendering — the single function every agent calls
before sending anything to an external party (financial partner, seller,
title company). Strips internal-only fields so the assignment spread and
internal FP-matching metadata never leak into outbound content.

This exists as ONE shared function specifically so the "never show X" rule
doesn't get reimplemented three slightly-different ways across Chris,
Alex, and Taylor.
"""

from dataclasses import dataclass, field

# Fields that must NEVER appear in FP-facing, seller-facing, or
# title-facing rendered content.
INTERNAL_ONLY_FIELDS = {
    "contract_price",
    "assignment_fee_target",
    "assignment_fee",
    "assignment_fee_collected",
    "novation_ips_profit_estimate",
    "novation_seller_net",          # internal calc input, not seller-facing net
    "fp_type",
    "capacity_min",
    "capacity_max",
    "preferred_zips",
    "last_touch_at",
    "avg_response_hours",
    "reputation_score",
    "match_score",
    "vip_tier",
    "dispo_tier",
    "wholesaler_red_flags",
    "verification_notes",
}

# Phrases that describe HOW an FP was selected internally — banned from
# any FP-facing copy even if the underlying field isn't directly rendered.
BANNED_FP_FACING_PHRASES = [
    "fast-turn",
    "cold cash partner",
    "private money partner",
    "hard money partner",
    "your preferred zips include",
    "your capacity aligns",
    "your response time",
    "your reputation tier",
]

# Only these fields are allowed to appear in FP-facing deal communications.
FP_FACING_ALLOWED_FIELDS = {
    "fp_facing_price",
    "address",
    "city",
    "state",
    "zip",
    "arv",
    "repairs_estimate",
    "close_date_target",
    "emd_amount",
    "emd_tier",
    "photos_url",
    "condition_notes",
    "title_company",
}


@dataclass
class RenderCheckResult:
    safe: bool
    stripped_fields: list[str] = field(default_factory=list)
    flagged_phrases: list[str] = field(default_factory=list)


def strip_internal_fields(payload: dict) -> dict:
    """
    Return a copy of `payload` with every internal-only field removed.
    Use this when building the data dict that feeds an FP/seller/title
    email template, BEFORE rendering, not after.
    """
    return {k: v for k, v in payload.items() if k not in INTERNAL_ONLY_FIELDS}


def check_outbound_safe(rendered_text: str) -> RenderCheckResult:
    """
    Final safety check on fully-rendered outbound text (after template
    fill) — catches banned phrasing that might have been drafted by the
    LLM even if the raw fields were correctly stripped upstream.
    """
    flagged = [
        phrase for phrase in BANNED_FP_FACING_PHRASES
        if phrase.lower() in rendered_text.lower()
    ]
    return RenderCheckResult(safe=len(flagged) == 0, flagged_phrases=flagged)


def assert_outbound_safe_or_raise(rendered_text: str, context: str = "") -> None:
    result = check_outbound_safe(rendered_text)
    if not result.safe:
        raise ValueError(
            f"Spread-invisibility violation in outbound content"
            f"{f' ({context})' if context else ''}: {result.flagged_phrases}"
        )


def build_fp_facing_price(contract_price: float, assignment_fee: float) -> float:
    """The only price an FP should ever see."""
    return contract_price + assignment_fee
