"""
Shared utility for loading content out of /brain — the single source of
truth for business knowledge (per Remy Gaskell's context-engineering
framework: AGENTS.md, skills, context files, memory).

Every LLM-drafting module (Chris's brief_generator, Alex's
outreach_generator, Workspace Chat) should read narrative/instructional
content through these functions rather than importing hardcoded text
from conversation modules directly. This keeps one copy of "what to say"
living in /brain, while classification logic (which personality type
matched, which objection matched) and deterministic math (offer ladder
calculations) stay in Python, since those are genuinely code, not
business knowledge.
"""

import os

_BRAIN_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "brain")


def load_skill(skill_name: str) -> str:
    """Reads brain/skills/{skill_name}/SKILL.md. Returns empty string
    (not an error) if the skill doesn't exist, so callers can degrade
    gracefully rather than crashing a live LLM call over a missing file."""
    path = os.path.join(_BRAIN_DIR, "skills", skill_name, "SKILL.md")
    if not os.path.exists(path):
        return ""
    with open(path) as f:
        return f.read()


def load_context(filename: str) -> str:
    """Reads brain/context/{filename}."""
    path = os.path.join(_BRAIN_DIR, "context", filename)
    if not os.path.exists(path):
        return ""
    with open(path) as f:
        return f.read()


def load_agents_md() -> str:
    """Reads the full brain/AGENTS.md."""
    path = os.path.join(_BRAIN_DIR, "AGENTS.md")
    if not os.path.exists(path):
        return ""
    with open(path) as f:
        return f.read()


def load_memory() -> str:
    """Reads brain/memory/memory.md."""
    path = os.path.join(_BRAIN_DIR, "memory", "memory.md")
    if not os.path.exists(path):
        return ""
    with open(path) as f:
        return f.read()


def extract_section(skill_text: str, heading_marker: str) -> str:
    """
    Pulls just one '## Heading' section out of a loaded skill file, so a
    caller can inject only the relevant slice (e.g. just the GREEN
    personality section) rather than the whole file, when context space
    matters. Falls back to the full text if the marker isn't found.
    """
    if heading_marker not in skill_text:
        return skill_text

    lines = skill_text.split("\n")
    start = next((i for i, line in enumerate(lines) if heading_marker in line), None)
    if start is None:
        return skill_text

    end = len(lines)
    for i in range(start + 1, len(lines)):
        if lines[i].startswith("## "):
            end = i
            break

    return "\n".join(lines[start:end]).strip()
