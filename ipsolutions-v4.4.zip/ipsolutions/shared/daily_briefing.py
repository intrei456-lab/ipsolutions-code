"""
The daily briefing - Thomas's morning digest across all three agents,
matching exactly what Matt Beard demonstrates as the crown jewel of his
own dashboard: "Matt, these people are still in your tier ones, here's
your new activity from yesterday, you might want to check these out."

Gathers real, live data from all three databases, optionally asks
Claude to narrate it into a short readable summary (grounded in
/brain), and sends it via the existing Gmail integration. Designed to
run as a scheduled job each morning, but also callable on-demand.
"""

from datetime import datetime, timedelta


def gather_daily_briefing_data() -> dict:
    """
    Pulls real, live signals across all three agents - the raw material
    for the briefing. Kept separate from the narration step so this part
    stays testable without needing network access.
    """
    from chris.db.db import get_connection as chris_conn
    from alex.db.db import get_connection as alex_conn
    from taylor.db.db import get_connection as taylor_conn
    from shared.brain_loader import load_memory

    data = {}
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")

    # Chris: new leads needing action, leads with no brief generated yet
    try:
        conn = chris_conn()
        new_leads = conn.execute(
            "SELECT lead_id, address, city, state, arv FROM leads "
            "WHERE status = 'NEW' AND is_test_data = 0 ORDER BY created_at DESC"
        ).fetchall()
        needs_brief = conn.execute(
            "SELECT lead_id, address FROM leads WHERE status = 'NEW' "
            "AND arv IS NOT NULL AND is_test_data = 0"
        ).fetchall()
        conn.close()
        data["chris_new_leads"] = [dict(r) for r in new_leads]
        data["chris_needs_brief"] = [dict(r) for r in needs_brief]
    except Exception:  # noqa: BLE001
        data["chris_new_leads"] = []
        data["chris_needs_brief"] = []

    # Alex: deals with TTB approaching/breached, deals with no FP assigned yet
    try:
        conn = alex_conn()
        deals_no_fp = conn.execute(
            "SELECT deal_id, fp_facing_price, dispo_day FROM deals "
            "WHERE fp_assigned_id IS NULL AND dispo_status NOT IN ('DEAD', 'TAYLOR_HANDOFF')"
        ).fetchall()
        recent_alerts = conn.execute(
            "SELECT alert_type, severity, message FROM ceo_alerts "
            "WHERE fired_at >= ? ORDER BY fired_at DESC", (yesterday,)
        ).fetchall()
        conn.close()
        data["alex_deals_no_fp"] = [dict(r) for r in deals_no_fp]
        data["alex_recent_alerts"] = [dict(r) for r in recent_alerts]
    except Exception:  # noqa: BLE001
        data["alex_deals_no_fp"] = []
        data["alex_recent_alerts"] = []

    # Taylor: stalled closings, closings needing attention soon
    try:
        conn = taylor_conn()
        active_closings = conn.execute(
            "SELECT closing_id, address, current_node, close_date_target FROM closings "
            "WHERE status = 'in_progress' ORDER BY close_date_target ASC"
        ).fetchall()
        recent_alerts = conn.execute(
            "SELECT alert_type, severity, message FROM ceo_alerts "
            "WHERE fired_at >= ? ORDER BY fired_at DESC", (yesterday,)
        ).fetchall()
        conn.close()
        data["taylor_active_closings"] = [dict(r) for r in active_closings]
        data["taylor_recent_alerts"] = [dict(r) for r in recent_alerts]
    except Exception:  # noqa: BLE001
        data["taylor_active_closings"] = []
        data["taylor_recent_alerts"] = []

    # The memory habit nudge - same logic as /workspace/pending_reflections
    try:
        conn = taylor_conn()
        memory_text = load_memory()
        closed_rows = conn.execute(
            "SELECT address FROM closings WHERE status = 'closed' AND archived_at IS NOT NULL "
            "ORDER BY archived_at DESC LIMIT 10"
        ).fetchall()
        conn.close()
        data["pending_reflections"] = [r["address"] for r in closed_rows if r["address"] not in memory_text]
    except Exception:  # noqa: BLE001
        data["pending_reflections"] = []

    return data


def render_plain_briefing(data: dict) -> str:
    """
    Deterministic, no-LLM-needed rendering - the 'clean templatebased
    briefing, fast, no API' option Matt's own build offers as an
    alternative to the AI-narrated version. Always available as a
    fallback even if the LLM call fails or isn't wanted.
    """
    lines = [f"IPSolutions Daily Briefing — {datetime.now().strftime('%B %d, %Y')}", ""]

    lines.append(f"CHRIS (Acquisitions): {len(data['chris_new_leads'])} new lead(s) waiting.")
    for lead in data["chris_new_leads"][:5]:
        arv_str = f"${lead['arv']:,.0f}" if lead["arv"] else "no ARV yet"
        lines.append(f"  - {lead['address']}, {lead['city']} {lead['state']} ({arv_str})")
    if data["chris_needs_brief"]:
        lines.append(f"  {len(data['chris_needs_brief'])} lead(s) ready for a brief but none generated yet.")
    lines.append("")

    lines.append(f"ALEX (Dispositions): {len(data['alex_deals_no_fp'])} deal(s) with no financial partner assigned yet.")
    if data["alex_recent_alerts"]:
        lines.append(f"  {len(data['alex_recent_alerts'])} CEO alert(s) in the last 24h:")
        for alert in data["alex_recent_alerts"][:5]:
            lines.append(f"    [{alert['severity']}] {alert['alert_type']}: {alert['message']}")
    lines.append("")

    lines.append(f"TAYLOR (Closing): {len(data['taylor_active_closings'])} closing(s) in progress.")
    for closing in data["taylor_active_closings"][:5]:
        lines.append(f"  - {closing['address']} (node {closing['current_node']}/36, target close {closing['close_date_target']})")
    if data["taylor_recent_alerts"]:
        lines.append(f"  {len(data['taylor_recent_alerts'])} CEO alert(s) in the last 24h:")
        for alert in data["taylor_recent_alerts"][:5]:
            lines.append(f"    [{alert['severity']}] {alert['alert_type']}: {alert['message']}")
    lines.append("")

    if data["pending_reflections"]:
        lines.append(f"BRAIN: {len(data['pending_reflections'])} closed deal(s) with no lesson saved yet:")
        for addr in data["pending_reflections"][:5]:
            lines.append(f"  - {addr}")

    return "\n".join(lines)


def generate_ai_narrated_briefing(data: dict) -> str:
    """
    The 'AI generated morning briefing using Claude' option - matches
    what Matt's own build offers as the richer alternative to the plain
    template. Grounded in /brain so the narration reflects real business
    priorities, not generic summary language.
    """
    from shared.brain_loader import load_agents_md
    from shared.llm_client import draft_content

    plain = render_plain_briefing(data)
    agents_context = load_agents_md()

    system_prompt = f"""You are writing Thomas's daily morning briefing for
Intense Property Solutions. You have real, live data below - turn it
into a short, direct summary of what actually needs his attention today,
prioritized by urgency. Don't just restate the data - tell him what to
focus on and why, the way a sharp operations manager would.

BUSINESS CONTEXT:
{agents_context[:2000]}
"""
    user_prompt = f"""Here's today's real data:

{plain}

Write a short morning briefing (under 200 words) - what should Thomas
focus on today, in priority order? Be direct and specific, referencing
real addresses/numbers from the data above."""

    result = draft_content(system_prompt, user_prompt, max_tokens=500, check_safety=False)
    return result["text"]


def send_daily_briefing(use_ai_narration: bool = True) -> dict:
    """
    The actual scheduled job - gathers data, renders it (AI-narrated or
    plain template), and sends via the existing Gmail integration.
    """
    from shared.email import send_operator_alert

    data = gather_daily_briefing_data()

    if use_ai_narration:
        try:
            body = generate_ai_narrated_briefing(data)
        except Exception as exc:  # noqa: BLE001
            # Fall back to the plain template if the LLM call fails -
            # a briefing with slightly less polish beats no briefing at all.
            body = render_plain_briefing(data) + f"\n\n[AI narration failed: {exc}]"
    else:
        body = render_plain_briefing(data)

    result = send_operator_alert("IPSolutions Daily Briefing", body)
    return {"sent": result.get("sent", False), "body": body}
