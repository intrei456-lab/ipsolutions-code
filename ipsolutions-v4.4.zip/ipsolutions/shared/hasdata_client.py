"""
shared/hasdata_client.py

HasData's Zillow scraper API (confirmed against real docs at
docs.hasdata.com/apis/zillow/listing and .../property, July 2026).
Two real endpoints chained together, since our leads only have a raw
address, not a Zillow URL:

1. Listing API (search by keyword/location) -> finds the matching
   property and its Zillow URL
2. Property API (fetch by URL) -> full details including price/
   Zestimate - this is the one that costs 5 credits per call

NOTE: only tested against real documentation, not a live call - no
network access in the build sandbox and no access to Thomas's real
API key. The request shape below matches HasData's documented
examples exactly; the exact response JSON structure for the Listing
endpoint wasn't fully documented in what I could access, so
_extract_zillow_url below may need a small adjustment once tested
against a real response - flagged clearly in that function.

Real limitation worth knowing: this only finds properties that exist
(or existed) on Zillow. A genuinely off-market property that's never
been listed won't have a Zillow record at all - this gets the subject
property's own data/Zestimate, not neighborhood comps around it.
"""

import os

import requests

HASDATA_BASE_URL = "https://api.hasdata.com/scrape/zillow"


def _get_api_key() -> str:
    api_key = os.environ.get("HASDATA_API_KEY")
    if not api_key:
        raise RuntimeError("HASDATA_API_KEY must be set in .env")
    return api_key


def search_property_by_address(address: str, city: str, state: str, zip_code: str, max_pages: int = 5) -> dict:
    """
    Step 1: search HasData's Zillow Listing API.

    REAL FIX #1 (confirmed via HasData's own README example - keyword:
    'new york, ny'): "keyword" is an AREA search, not a specific street
    address. Search the area, then filter results for the target
    address - this is what _find_address_match does.

    REAL FIX #2 (confirmed via a live raw curl test on 2026-07-17):
    the Listing API paginates - a real search for "Baltimore, MD 21212"
    returned 75 total results across multiple pages (41 on page 1, 34
    on page 2), and a specific known-good address (4713 Alhambra Ave)
    was only present on page 2. The response includes a real
    pagination.currentPage field and confirms `page` as a working query
    param. Without checking multiple pages, a real, currently-listed
    property can come back as a false "not found" - this is exactly
    what happened during testing before this fix.

    Tries sold first (most valuable for ARV work - real transaction
    price), then forSale, then forRent. Within each type, checks up to
    max_pages pages (default 5) before giving up and moving to the next
    type - keeps a genuinely-not-found result from taking forever on a
    huge market, while still covering enough ground that a real match
    on page 2 or 3 (like the confirmed test case) gets found.
    """
    api_key = _get_api_key()
    area_keyword = f"{city}, {state} {zip_code}" if zip_code else f"{city}, {state}"

    last_response = None
    for listing_type in ("sold", "forSale", "forRent"):
        for page in range(1, max_pages + 1):
            params = {"keyword": area_keyword, "type": listing_type}
            if page > 1:
                params["page"] = page

            response = requests.get(
                f"{HASDATA_BASE_URL}/listing",
                headers={"Content-Type": "application/json", "x-api-key": api_key},
                params=params,
                timeout=20,
            )
            response.raise_for_status()
            data = response.json()
            last_response = data

            match = _find_address_match(data, address)
            if match:
                data["_matched_type"] = listing_type
                data["_matched_page"] = page
                data["_matched_listing"] = match
                return data

            # Stop paginating this type once there's genuinely no next
            # page, rather than continuing to request pages that don't
            # exist - real signal confirmed in the live test response.
            if not data.get("pagination", {}).get("nextPage"):
                break

    return last_response


def _address_to_string(addr) -> str:
    """
    Real HasData response confirmed (via live test) that the address
    field can be a nested object (e.g. {"streetAddress": ..., "city":
    ..., "state": ..., "zipcode": ...}) rather than a flat string -
    this wasn't knowable from the docs alone. Handles both shapes
    defensively so a field-shape surprise doesn't crash the whole
    lookup - falls back to str() for any shape not anticipated here.
    """
    if isinstance(addr, str):
        return addr
    if isinstance(addr, dict):
        parts = [
            addr.get("streetAddress") or addr.get("street") or "",
            addr.get("city") or "",
            addr.get("state") or "",
            addr.get("zipcode") or addr.get("zip") or "",
        ]
        joined = " ".join(p for p in parts if p)
        if joined:
            return joined
    return str(addr) if addr else ""


def _find_address_match(listing_response: dict, target_address: str) -> dict | None:
    """
    Filters a Listing API response (an area's worth of properties) for
    the one whose own address matches our target street address.
    Normalizes both sides (lowercase, strip common abbreviations) for
    a looser but still reliable match, since Zillow's own formatting
    (e.g. 'St' vs 'Street') may not exactly match what's in our leads
    table.
    """
    results = listing_response.get("properties") or listing_response.get("results") or listing_response.get("data") or []
    if not results:
        return None

    def normalize(addr: str) -> str:
        addr = addr.lower().strip()
        for full, abbr in [("street", "st"), ("avenue", "ave"), ("drive", "dr"),
                            ("terrace", "ter"), ("road", "rd"), ("boulevard", "blvd"),
                            ("lane", "ln"), ("court", "ct")]:
            addr = addr.replace(f" {full}", f" {abbr}").replace(f" {full}.", f" {abbr}")
        return " ".join(addr.split())

    target_norm = normalize(target_address)

    for listing in results:
        listing_address_raw = listing.get("address") or listing.get("streetAddress") or ""
        listing_address = _address_to_string(listing_address_raw)
        if not listing_address:
            continue
        if target_norm in normalize(listing_address) or normalize(listing_address) in target_norm:
            return listing

    return None


def get_property_details(zillow_url: str) -> dict:
    """Step 2: fetch full details (price, Zestimate, features) for a
    specific Zillow property URL. Costs 5 API credits per call."""
    response = requests.get(
        f"{HASDATA_BASE_URL}/property",
        headers={"Content-Type": "application/json", "x-api-key": _get_api_key()},
        params={"url": zillow_url},
        timeout=20,
    )
    response.raise_for_status()
    return response.json()


def pull_comps_for_address(address: str, city: str, state: str, zip_code: str) -> dict:
    """
    The combined, single entry point: search the area for the address,
    then pull full details if a match was found. Returns:
      {"found": True, "arv_estimate": float, "asking_price": float|None, "raw": dict}
      or
      {"found": False, "reason": str}

    Costs both a search + a property-detail call (real credit cost) -
    only call this when a real lookup is actually wanted, not
    speculatively.
    """
    listing = search_property_by_address(address, city, state, zip_code)
    match = listing.get("_matched_listing")

    if not match:
        return {
            "found": False,
            "reason": "No matching Zillow listing found for this address in "
                      f"{city}, {state} (checked sold, for-sale, and for-rent) - likely "
                      "genuinely off-market (never listed), or the address format didn't "
                      "match closely enough to what Zillow has on file.",
        }

    zillow_url = match.get("url") or match.get("detailUrl") or match.get("zillowUrl")

    # REAL FIX: the live curl test confirmed the listing match itself
    # already carries "price" and "zestimate" as top-level fields
    # (e.g. "price": 375000, "zestimate": 373500) - these are CONFIRMED
    # real field names, unlike the separate Property endpoint's
    # response shape, which has never been tested against a live call
    # and was returning $0 for exactly that reason (guessed field names
    # that didn't match reality). Use the listing's own confirmed
    # fields as the primary source - cheaper too, since it skips the
    # second 5-credit Property call entirely when the listing already
    # has what we need.
    arv_estimate = match.get("zestimate") or match.get("price")
    asking_price = match.get("price")

    if arv_estimate:
        return {
            "found": True,
            "arv_estimate": arv_estimate,
            "asking_price": asking_price,
            "zillow_url": zillow_url,
            "raw": match,
        }

    # Fallback only: if the listing match somehow didn't carry a price/
    # zestimate, try the Property endpoint as a secondary attempt -
    # this path is unconfirmed and may need its own field-name fix if
    # it's ever actually exercised.
    if not zillow_url:
        return {
            "found": True,
            "reason": "Matched a listing but it has no price/zestimate and no URL to look up "
                      "further details - check raw_match for what's actually there.",
            "raw_match": match,
        }

    details = get_property_details(zillow_url)
    arv_estimate = details.get("zestimate") or details.get("price")
    asking_price = details.get("price")

    return {
        "found": True,
        "arv_estimate": arv_estimate,
        "asking_price": asking_price,
        "zillow_url": zillow_url,
        "raw": details,
    }

