"""
Shared LLM client — the single place every agent calls through to reach
Claude. Centralizing this means the terminology filter and spread-
invisibility check run on every LLM-drafted output automatically, rather
than each call site needing to remember to check.
"""

import os

from shared.rendering import check_outbound_safe
from shared.terminology import check_terminology

MODEL = "claude-sonnet-4-6"


def get_client():
    """Lazy import so this module can be imported/tested without the
    anthropic package installed (e.g. in environments without network
    access to pip). The real dependency is only needed at call time."""
    from anthropic import Anthropic

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError(
            "ANTHROPIC_API_KEY not set. Add it to your .env file - see .env.example."
        )
    return Anthropic(api_key=api_key)


def draft_content(
    system_prompt: str,
    user_prompt: str,
    max_tokens: int = 2000,
    check_safety: bool = True,
) -> dict:
    """
    Single entry point for LLM-drafted content (offer scripts, briefs,
    outreach messages, anything customer/FP/seller-facing). Runs the
    terminology filter and spread-invisibility check on the output before
    returning it, so unsafe content surfaces immediately rather than
    silently going out the door.
    """
    client = get_client()
    response = client.messages.create(
        model=MODEL,
        max_tokens=max_tokens,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    )

    text = "".join(block.text for block in response.content if hasattr(block, "text"))

    result = {
        "text": text,
        "terminology_clean": True,
        "spread_safety_clean": True,
        "warnings": [],
    }

    if check_safety:
        term_check = check_terminology(text)
        if not term_check.clean:
            result["terminology_clean"] = False
            result["warnings"].extend(term_check.violations)
            text = term_check.auto_fixed_text  # apply safe auto-fixes at minimum

        safety_check = check_outbound_safe(text)
        if not safety_check.safe:
            result["spread_safety_clean"] = False
            result["warnings"].extend(
                [f"banned phrase detected: {p}" for p in safety_check.flagged_phrases]
            )

        result["text"] = text

    return result
