"""
Follow-up cadence — Keith Everett's "fortune is in the follow-up" framework.
Real thresholds from the transcript (not the more abstract table in the
original agent spec — this is the actual source it was derived from).
"""

from dataclasses import dataclass
from enum import Enum


class LeadFollowUpType(str, Enum):
    NO_ANSWER = "NO_ANSWER"
    INTERESTED = "INTERESTED"           # within 20k of MAO
    NOT_INTERESTED = "NOT_INTERESTED"   # more than 20k from MAO
    DEAD_DEAL = "DEAD_DEAL"             # contract fell through


@dataclass
class FollowUpCadence:
    lead_type: LeadFollowUpType
    frequency_description: str
    frequency_days_min: int
    frequency_days_max: int


# Price gap from MAO determines base cadence
def cadence_from_price_gap(gap_from_mao: float) -> FollowUpCadence:
    """
    Real thresholds from transcript:
      <= $20k from MAO -> follow up in 3 days to 1 week
      >  $20k from MAO -> extend out, up to a month
      way too far off  -> 3 to 6 months
    """
    if gap_from_mao <= 20000:
        return FollowUpCadence(LeadFollowUpType.INTERESTED, "3 days to 1 week", 3, 7)
    elif gap_from_mao <= 50000:  # "a little over 20k" - reasonable threshold, not explicit in transcript
        return FollowUpCadence(LeadFollowUpType.NOT_INTERESTED, "up to 1 month", 14, 30)
    else:
        return FollowUpCadence(LeadFollowUpType.NOT_INTERESTED, "3 to 6 months", 90, 180)


def adjust_for_motivation(base: FollowUpCadence, motivation: str) -> FollowUpCadence:
    """
    Motivation shortens or extends the cadence within the price-gap band:
    more motivated -> follow up sooner; less motivated -> extend it out.
    """
    if motivation == "HIGH":
        # Pull the window in - short-term follow-up regardless of price gap
        return FollowUpCadence(base.lead_type, "shortened (high motivation)",
                                max(1, base.frequency_days_min // 2), base.frequency_days_min)
    if motivation == "LOW":
        return FollowUpCadence(base.lead_type, "extended (low motivation)",
                                base.frequency_days_max, base.frequency_days_max * 2)
    return base


# ---------------------------------------------------------------------------
# 4 lead types and their follow-up rules
# ---------------------------------------------------------------------------

LEAD_TYPE_RULES = {
    LeadFollowUpType.NO_ANSWER: (
        "Consistently follow up - these leads are still warm or hot even "
        "without an answer, since leads are pre-filtered before they reach "
        "the follow-up stage."
    ),
    LeadFollowUpType.INTERESTED: (
        "Within $20k of MAO - follow up daily. Highest priority follow-up bucket."
    ),
    LeadFollowUpType.NOT_INTERESTED: (
        "More than $20k from MAO - follow up every 1-6 months depending on "
        "motivation. Batch these rather than treating individually."
    ),
    LeadFollowUpType.DEAD_DEAL: (
        "Contract fell through - re-check every 30 days. A meaningful "
        "percentage of dead deals come back to life with a price reduction "
        "on re-contact."
    ),
}

DEAD_DEAL_RECHECK_DAYS = 30


# ---------------------------------------------------------------------------
# Task discipline
# ---------------------------------------------------------------------------

TASK_DISCIPLINE_RULE = (
    "Past-due tasks are the FIRST priority every session - check the task "
    "and past-due-task queue before calling any new leads. Anything not "
    "completed in a day becomes a past-due task the next day, not a "
    "dropped task."
)

CONSISTENCY_RULE = (
    "Follow up with hot leads at least 3 times in a single day (e.g. "
    "morning, noon, evening) - sellers work different schedules, and a "
    "single daily attempt at the wrong time will systematically miss "
    "reachable sellers."
)

PIPELINE_SHEET_NOTE = (
    "Every hot/warm lead and every scheduled callback goes on the pipeline "
    "sheet with an explicit next-touch task - 'keep the seller in front of "
    "you' at all times, the same way a basketball player keeps their "
    "defensive assignment in front of them."
)
