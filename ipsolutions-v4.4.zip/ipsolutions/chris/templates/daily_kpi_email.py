"""
Daily KPI email — real format confirmed against an actual sent report.
Pure data assembly, no LLM needed.
"""

from dataclasses import dataclass, field

from shared.config import BRAND

BENCHMARKS = {
    "leads": "target 30-50",
    "conversations": "100->20 benchmark",
    "offers": "20->5 benchmark",
    "contracts": "5->1 benchmark",
}


@dataclass
class HotQueueItem:
    address: str
    exit_strategy: str          # CASH / NOVATION / NURTURE
    motivation_note: str        # e.g. "HIGH - Vacant/Code Viol"
    risk_tier: str = "STANDARD"


@dataclass
class DailyKPIInputs:
    report_date: str
    leads_today: int
    conversations_today: int
    offers_today: int
    contracts_today: int
    fb_ad_leads: int = 0
    fsbo_leads: int = 0
    scout_leads: int = 0
    mat_beard_touches: int = 0
    scout_module_breakdown: dict = field(default_factory=dict)  # {module_name: "X new / Y in-market"}
    hot_queue: list[HotQueueItem] = field(default_factory=list)
    speed_to_lead_breaches: int = 0
    protect_spread_activations: int = 0
    drafts_awaiting_thomas: int = 0


def render_daily_kpi_email(inputs: DailyKPIInputs) -> str:
    hot_queue_lines = [
        f"{item.address} — {item.exit_strategy} / {item.motivation_note} / {item.risk_tier}"
        for item in inputs.hot_queue
    ]
    scout_lines = [f"{name}: {detail}" for name, detail in inputs.scout_module_breakdown.items()]

    return f"""{BRAND['company_name'].upper()}
{BRAND['tagline']}

Daily KPI Report
{inputs.report_date} — Acquisitions (Chris)

LEADS: {inputs.leads_today} ({BENCHMARKS['leads']})
CONVERSATIONS: {inputs.conversations_today} ({BENCHMARKS['conversations']})
OFFERS: {inputs.offers_today} ({BENCHMARKS['offers']})
CONTRACTS: {inputs.contracts_today} ({BENCHMARKS['contracts']})

LEAD SOURCES
FB Ad Webhook: {inputs.fb_ad_leads}
FSBO (Zillow/Redfin/Craigslist/FB Marketplace): {inputs.fsbo_leads}
Scout Modules (12+): {inputs.scout_leads}
Mat Beard Agent Touches: {inputs.mat_beard_touches}

SCOUT MODULE BREAKDOWN
{chr(10).join(scout_lines) if scout_lines else '(none today)'}

HOT QUEUE — READY FOR THOMAS
{chr(10).join(hot_queue_lines) if hot_queue_lines else '(empty)'}

SLA Status — Speed-to-lead breaches today: {inputs.speed_to_lead_breaches}. Drafts awaiting Thomas: {inputs.drafts_awaiting_thomas}. PROTECT_SPREAD activations today: {inputs.protect_spread_activations}.

CHRIS — ACQUISITIONS — INTENSEPROPERTYSOLUTIONS.COM"""
