"""
Mat Beard module — Chris's PRIMARY realtor/agent outreach engine.
Named after and built from Matt Beard's "No Fluff Real Estate" model
transcripts (gatekeeper outreach, 3-tier system, 3-C conversion framework).

Core insight from source material: off-market deals sourced through real
estate agents ("gatekeepers") are dramatically cheaper to acquire than
direct-to-seller marketing (~$100-150/deal vs $2,000-10,000/deal), because
agents already have the trust relationship with the seller.
"""

from dataclasses import dataclass
from enum import Enum


# ---------------------------------------------------------------------------
# Agent tier system (Phase 1: Lead Generation)
# ---------------------------------------------------------------------------

class AgentTier(str, Enum):
    TIER_1 = "TIER_1"  # gave an address (on-market or off-market)
    TIER_2 = "TIER_2"  # gave an address but it fell through
    TIER_3 = "TIER_3"  # no address yet, agreed to periodic check-ins
    DEAD = "DEAD"       # explicitly asked not to be contacted again


AGENT_TIER_RULES = {
    AgentTier.TIER_1: "Agent gave an address - highest priority, move to Phase 2 (Call/Comp/Close) immediately.",
    AgentTier.TIER_2: "Gave an address before but it didn't convert - stays in its own follow-up sequence, distinct tone from Tier 3.",
    AgentTier.TIER_3: "No address yet, but agreed to occasional check-ins - lowest-touch automated follow-up sequence.",
    AgentTier.DEAD: "Explicitly declined further contact - remove from all outreach immediately, same DNC discipline as seller leads.",
}

# Real benchmark metrics from source material - useful as sanity-check
# targets when the actual outreach engine is live and producing numbers.
BENCHMARK_METRICS = {
    "texts_per_day_per_deal_target": 500,          # to generate 3-8 properties/day at scale
    "properties_per_day_per_500_texts": (3, 8),
    "pct_addresses_off_market": (0.22, 0.40),      # 22-40% of addresses given are off-market
    "off_market_leads_to_close_ratio": (12, 20),   # 12-20 off-market leads -> 1 closed deal
    "repeat_agent_rate_same_year": 1 / 3,           # ~1 in 3 agents do a 2nd deal same calendar year
    "cost_per_deal_via_agents_usd": (100, 150),     # vs $2,000-10,000 via direct-to-seller marketing
}


# ---------------------------------------------------------------------------
# Phase 2: Lead conversion - the "3 C's" (Call, Comp, Close)
# ---------------------------------------------------------------------------

PHASE_2_CALL_NOTES = """
The first call is about building rapport, NOT presenting an offer or
negotiating. Goals for this call ("lay of the land"):
  - Are there other offers on the table already?
  - What does the agent think the property is worth after work?
  - What condition issues does the agent believe exist (kitchen, bath, etc)?
  - Respect the agent's opinion explicitly - do not correct or educate them,
    even if their estimate seems off. This is a trust-building call.
  - Set the expectation BEFORE underwriting: "I know you're hoping for
    around $X, let me do some homework - I probably won't hit that number
    exactly, how much flexibility is there?" This primes the agent for a
    below-ask offer before you ever name a number.
"""

PHASE_2_COMP_NOTES = """
Underwrite fast - ideally within 12 hours of getting the address. Speed
matters because good off-market deals move quickly. If there are skill
gaps (e.g. unfamiliar market), loop in a JV partner rather than slow down.
"""

PHASE_2_CLOSE_NOTES = """
Only present an offer to someone ready to make a decision NOW. If the
agent says "we'll know by Sunday" and it's Thursday, do not make an offer
today - call back Sunday instead. A verbal ballpark ("probably somewhere
around $240-245k") is often enough at this stage; it doesn't need to be
a written offer yet - get verbal alignment, then put it in writing.
"""


# ---------------------------------------------------------------------------
# Agent objection handling
# ---------------------------------------------------------------------------

@dataclass
class AgentObjection:
    trigger_phrases: list[str]
    response: str


AGENT_OBJECTION_RULE = (
    "Every objection response MUST end with a question back to the agent "
    "to keep the conversation moving forward - never let an objection "
    "answer be a dead end."
)

AGENT_OBJECTIONS: list[AgentObjection] = [
    AgentObjection(
        trigger_phrases=["proof of funds", "can you show funds", "pof"],
        response=(
            "Absolutely, I can email over our proof of funds and our buy "
            "box right now. If a home fits our criteria we can be very "
            "competitive with our offer — how often do you run across "
            "properties that need some work?"
        ),
    ),
    AgentObjection(
        trigger_phrases=["what's your buy box", "buy box", "what are you looking for"],
        response=(
            "Happy to send that over — we're pretty flexible on condition "
            "and ZIP within [market]. What kind of properties do you "
            "typically see come across your desk that need work?"
        ),
    ),
    AgentObjection(
        trigger_phrases=["are you an investor", "are you a wholesaler", "flipping it"],
        response=(
            "Yes, we purchase properties that need work and either renovate "
            "or reposition them — do you have anything coming up that fits "
            "that description?"
        ),
    ),
]


def find_agent_objection_response(text: str) -> str | None:
    text_lower = text.lower()
    for obj in AGENT_OBJECTIONS:
        if any(p in text_lower for p in obj.trigger_phrases):
            return obj.response
    return None


# ---------------------------------------------------------------------------
# Gatekeeper outreach opener
# ---------------------------------------------------------------------------

GATEKEEPER_OUTREACH_OPENER = (
    "Hey, do you have anything coming up that needs some work? Always "
    "looking for off-market opportunities in [market]."
)

GATEKEEPER_QUALIFICATION_FILTER = {
    "off_market": "Not currently listed on MLS",
    "condition": "Needs meaningful work, not move-in ready",
    "price_signal": "Asking price at or below ~60-70% of automated value estimate (e.g. Zillow Zestimate)",
}

# ---------------------------------------------------------------------------
# Tier 1 speed-to-lead SLA
# ---------------------------------------------------------------------------

TIER_1_CALL_SLA_HOURS = (3, 6)
TIER_1_SLA_RATIONALE = (
    "Good off-market deals sell within a day. Calling a Tier 1 agent lead "
    "(one that gave an address) within 3-6 hours is the single highest-"
    "leverage habit in this whole model - waiting even a day can mean the "
    "deal is already gone. Vet the LEAD (property condition) and the "
    "OPPORTUNITY (where they are in the process, existing offers) on the "
    "SAME call, before doing any underwriting or pulling comps."
)

CALL_BEFORE_COMP_RULE = (
    "Do NOT underwrite or pull comps before making the Tier 1 vetting call. "
    "The call comes first - it's the highest-value use of time, and "
    "underwriting a property that turns out to be a bad fit wastes the "
    "time pressure you need to move fast on the ones that ARE a fit."
)


# ---------------------------------------------------------------------------
# Off-market-only filter strategy (conversion math)
# ---------------------------------------------------------------------------

OFF_MARKET_FILTER_STRATEGY = (
    "Accepting only off-market addresses roughly DOUBLES conversion rate "
    "versus accepting any address an agent sends (on-market included): "
    "~1-in-14-to-20 off-market leads convert to a deal, versus ~1-in-41-"
    "to-62 when accepting everything. Fewer total leads, but dramatically "
    "less wasted time per closed deal. On-market leads are usually not "
    "worth pursuing unless the property has sat a long time AND needs "
    "heavy work - otherwise, politely tell the agent it's not a fit rather "
    "than spending underwriting time on it."
)

CONVERSION_RATIOS = {
    "off_market_only": (14, 20),   # leads per closed deal
    "all_addresses": (41, 62),     # leads per closed deal, no off-market filter
}

POLITE_DECLINE_SCRIPT = (
    "I really appreciate you sending this over — I'm typically looking for "
    "properties that need some work and haven't hit the market yet. I "
    "don't have the deepest pockets, but I try to be fair with our offers "
    "when something fits. Keep me in mind if anything off-market comes up!"
)


# ---------------------------------------------------------------------------
# Agent follow-up cadence (distinct from seller follow-up cadence)
# ---------------------------------------------------------------------------

AGENT_FOLLOWUP_CADENCE_RULE = (
    "Agents get a MONTHLY check-in cadence by default - NOT weekly. "
    "Checking in too frequently gets you marked as spam. Rationale: a "
    "typical productive agent closes ~6 deals/year (about one every other "
    "month) - checking in more often than that outpaces how often they "
    "actually have something new to share."
)

AGENT_FOLLOWUP_TRACKS = {
    "NOT_INTERESTED_IN_CREATIVE": {
        "cadence": "biweekly",
        "script": (
            "Hey, I know [structure] didn't work for your last listing, "
            "but keep us in mind if anything changes."
        ),
    },
    "GENERAL_NURTURE": {
        "cadence": "monthly",
        "script": (
            "Hope you're doing amazing and business is great! Just "
            "checking in - let us know if there's anything we can do to "
            "add value to your business."
        ),
    },
}

AGENT_TONE_RULE = (
    "Keep agent outreach business-to-business: direct, concise, no need "
    "for the same rapport-building patience used with sellers. 'Hey, I'm "
    "here because we want to do deals together, just checking back in, "
    "hope you're doing amazing' - straight to the point, no filler."
)
