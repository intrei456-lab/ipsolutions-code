"""
Mat Beard agent outreach — exact templates pulled directly from the live
Twin build (16 total across 5 categories). Rotation exists specifically to
avoid carrier spam-detection on repeated identical SMS bodies.
"""

import random
from dataclasses import dataclass


@dataclass
class OutreachTemplate:
    category: str
    text: str


FIRST_TOUCH_TEMPLATES: list[OutreachTemplate] = [
    OutreachTemplate("FIRST_TOUCH", "Hey {agent_name}, I work with investors in {market}. If you ever have a listing sitting or a tough seller, I can usually make it work and you still get paid. Worth a quick chat?"),
    OutreachTemplate("FIRST_TOUCH", "Hi {agent_name} - we buy properties in {market}, close fast, and agents keep their full commission. Got anything that needs a creative solution?"),
    OutreachTemplate("FIRST_TOUCH", "{agent_name}, Thomas w/ IPSolutions. We close on problem properties in {market} - agents still get paid. If you have one collecting dust, I can probably move it. Interested?"),
    OutreachTemplate("FIRST_TOUCH", "Hey {agent_name}, quick Q - do you ever have listings in {market} that just will not sell the traditional way? We take those off agents hands and you still earn. LMK if worth a convo."),
    OutreachTemplate("FIRST_TOUCH", "{agent_name} - IPSolutions here. We are end buyers in {market} focused on fix and flip. If you have a property that needs work or a motivated seller, we close fast. You keep your commission."),
]

TIER_1_FOLLOWUP_TEMPLATES: list[OutreachTemplate] = [
    OutreachTemplate("TIER_1", "Hey {agent_name}, following up on the property you mentioned. I ran numbers - can I share what I am seeing? Quick call today?"),
    OutreachTemplate("TIER_1", "{agent_name}, got the comps back on that address. Looks like we can make it work. When works for a 5-min call to go over the range?"),
    OutreachTemplate("TIER_1", "Hi {agent_name}, just checking in on that deal. My finance team has funds set aside - want to move quickly before we allocate elsewhere. Free for a call?"),
]

TIER_2_FOLLOWUP_TEMPLATES: list[OutreachTemplate] = [
    OutreachTemplate("TIER_2", "Hey {agent_name}, no worries on that last one. Keep me in mind - I can usually make most situations work. Anything else come across your desk?"),
    OutreachTemplate("TIER_2", "{agent_name}, just touching base. We are still buying in {market}. If another one pops up, you know I can move fast. Hope you are well."),
    OutreachTemplate("TIER_2", "Hi {agent_name} - still active in {market} and closing deals. If you run into another one that needs a creative approach, I am a text away."),
]

TIER_3_FOLLOWUP_TEMPLATES: list[OutreachTemplate] = [
    OutreachTemplate("TIER_3", "Hey {agent_name}, just checking in. Anything come across your desk that needs a creative solution? We are closing fast in {market} right now."),
    OutreachTemplate("TIER_3", "{agent_name}, hope you are having a good week. Still buying in {market} - if something comes up, I can usually make it work and you keep your full commission."),
    OutreachTemplate("TIER_3", "Hi {agent_name}, quick check-in. We just closed one in {market} last week. Always looking for the next one - LMK if you hear of anything."),
]

RE_ENGAGE_TEMPLATES: list[OutreachTemplate] = [
    OutreachTemplate("RE_ENGAGE", "Hey {agent_name}, it has been a while. We are still buying in {market} and just expanded our team. If you have anything that needs a creative offer, I can move fast. Hope you are well."),
    OutreachTemplate("RE_ENGAGE", "{agent_name} - Thomas from IPSolutions. We have closed a few more in {market} since we last spoke. If anything comes across your desk, I am a text away."),
]

ALL_TEMPLATES_BY_CATEGORY = {
    "FIRST_TOUCH": FIRST_TOUCH_TEMPLATES,
    "TIER_1": TIER_1_FOLLOWUP_TEMPLATES,
    "TIER_2": TIER_2_FOLLOWUP_TEMPLATES,
    "TIER_3": TIER_3_FOLLOWUP_TEMPLATES,
    "RE_ENGAGE": RE_ENGAGE_TEMPLATES,
}


def get_template(category: str, agent_name: str, market: str, exclude_texts: list[str] | None = None) -> str:
    """
    Selects a template for the given category, avoiding recently-used
    texts for this agent where possible (carrier spam detection avoidance -
    sending identical bodies repeatedly to the same recipient class is
    exactly the kind of pattern that gets flagged).
    """
    candidates = ALL_TEMPLATES_BY_CATEGORY.get(category, [])
    if not candidates:
        raise ValueError(f"Unknown outreach category: {category}")

    exclude_texts = exclude_texts or []
    available = [t for t in candidates if t.text not in exclude_texts]
    if not available:
        available = candidates  # exhausted rotation, allow repeats rather than failing

    chosen = random.choice(available)
    return chosen.text.format(agent_name=agent_name, market=market)


def category_for_agent_tier(tier: str, has_address: bool, deal_fell_through: bool) -> str:
    """
    Maps Chris's agent tier state to the correct template category.
      TIER_1 (gave an address) -> TIER_1 followup templates
      TIER_2 (gave address, fell through) -> TIER_2 followup templates
      TIER_3 (no address, nurture) -> TIER_3 followup templates
      First contact -> FIRST_TOUCH
      Cold/dormant re-activation -> RE_ENGAGE
    """
    if tier == "FIRST_CONTACT":
        return "FIRST_TOUCH"
    if tier == "TIER_1" and has_address and not deal_fell_through:
        return "TIER_1"
    if deal_fell_through:
        return "TIER_2"
    if tier == "TIER_3":
        return "TIER_3"
    return "RE_ENGAGE"
