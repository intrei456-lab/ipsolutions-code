"""
chris/scouts/setup_call_classifier.py

Single job: given a real setup-call transcript, classify it as
GREEN/RED/PENDING using the exact red/green flag rules already
documented in brain/skills/setup-call-script/SKILL.md - not a
reimplementation of those rules, a direct application of them.

This is the automatic alternative to a human listening to the call and
clicking Green/Red on the dashboard (see /chris/leads/{id}/setup_call_outcome
in main.py) - triggered from /vapi/webhook once a setup call ends.

Deliberately a narrow, single-purpose function per the narrow-agent
design principle in AGENTS.md: this module only classifies, it doesn't
trigger calls (see shared/vapi_client.py) or write to the database
(that's done by the caller in main.py's webhook handler).
"""

from shared.brain_loader import load_skill
from shared.llm_client import draft_content


def classify_setup_call_outcome(transcript: str) -> dict:
    """
    Returns {"outcome": "GREEN"|"RED"|"PENDING", "reasoning": str}.

    PENDING covers genuinely ambiguous calls (missing info, cut short,
    not enough signal either way) - this should not be a common result;
    it exists so a bad transcript doesn't get silently forced into a
    wrong classification.
    """
    if not transcript or not transcript.strip():
        return {"outcome": "PENDING", "reasoning": "No transcript available - call may not have connected."}

    script_rules = load_skill("setup-call-script")

    system_prompt = f"""You are classifying a real setup call transcript
between an IPSolutions team member (or Brielle, our voice assistant) and
a real estate agent, using the exact rules below. Apply them precisely -
do not invent new criteria.

{script_rules}

Respond in EXACTLY this format, nothing else:
OUTCOME: GREEN, RED, or PENDING
REASONING: one or two sentences citing the specific flag(s) that drove the decision"""

    user_prompt = f"""Here is the real call transcript:

{transcript}

Classify this call as GREEN (worth pursuing further), RED (disqualify,
per the red flags and hard rules), or PENDING (genuinely ambiguous -
not enough signal, call was cut short, or critical info is missing)."""

    result = draft_content(system_prompt, user_prompt, max_tokens=200, check_safety=False)
    text = result["text"].strip()

    outcome = "PENDING"
    reasoning = text
    for line in text.splitlines():
        if line.upper().startswith("OUTCOME:"):
            value = line.split(":", 1)[1].strip().upper()
            if value in ("GREEN", "RED", "PENDING"):
                outcome = value
        if line.upper().startswith("REASONING:"):
            reasoning = line.split(":", 1)[1].strip()

    return {"outcome": outcome, "reasoning": reasoning}
