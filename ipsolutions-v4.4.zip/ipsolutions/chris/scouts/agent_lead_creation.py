"""
chris/scouts/agent_lead_creation.py

Single job: when an agent gives an address (reaching or re-reaching
Tier 1), create the corresponding property lead in Chris's normal
leads pipeline - same pipeline as direct-to-seller leads, just tagged
source=AGENT_REFERRAL and linked back to the agent via agent_id.

Deliberately NOT folded into agent_tier_transitions.py - that module's
only job is tier state, per the narrow-agent design principle in
AGENTS.md. This module's only job is lead creation. The API endpoint
in main.py is what calls both, in sequence.

Note on repeat addresses: an agent can give multiple addresses over
time (this is the whole point of the "golden bucket" - a proven
relationship can produce a second, third deal). Every address given
creates its own lead, regardless of whether this agent has reached
Tier 1 before.
"""

from chris.intake.zip_filter import insert_lead, IntakeResult


def create_lead_from_agent_referral(
    *,
    agent_id: int,
    address: str,
    city: str,
    raw_zip: str,
) -> IntakeResult:
    """
    Creates the lead for an agent-given address. Uses the exact same
    ZIP-gate and intake logic as every other lead source (insert_lead
    is the single entry point for all of them) - the only difference
    is source=AGENT_REFERRAL and agent_id being set, which is what lets
    the green-flag gate on lock_deal (see main.py) find its way back to
    the originating agent relationship.
    """
    return insert_lead(
        address=address,
        city=city,
        raw_zip=raw_zip,
        source="AGENT_REFERRAL",
        agent_id=agent_id,
    )
