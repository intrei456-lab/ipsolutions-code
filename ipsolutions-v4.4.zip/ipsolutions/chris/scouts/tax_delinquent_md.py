"""
Scout module: Tax Delinquent - Maryland (Baltimore city.gov)

This is the FIRST scout module, built to validate the end-to-end pattern
before replicating it to the other 11+ modules. Every scout module follows
this same shape: fetch -> parse -> ZIP filter (via intake) -> enrich ->
insert -> log run.

WHAT'S REAL: the run logging, dedup, ZIP filtering, and lead insertion.
WHAT'S STUBBED: the actual scrape of Baltimore's tax sale portal. That
portal's structure (login wall? CSV export? paginated HTML table?) needs
to be inspected live before this can pull real data — I can't reliably
know that from training data since city portals change often. Fill in
`fetch_raw_records()` once you or I inspect the actual page.

Per the spec's scraping priority order: Apify actors first, then direct
scrape, then browser agent fallback, then web search aggregator, then
manual pull, then Zillow/Redfin proxy signal.
"""

from datetime import datetime, timezone

from chris.db.db import get_connection
from chris.intake.zip_filter import insert_lead

SOURCE_NAME = "TAX_DELINQUENT"
MD_TAX_PORTAL_URL = "https://cityservices.baltimorecity.gov"  # TODO: confirm exact tax sale list URL


def fetch_raw_records() -> list[dict]:
    """
    TODO: implement the actual fetch against Baltimore's tax delinquent
    list. Return a list of dicts shaped like:
        {"address": "...", "city": "Baltimore", "zip": "21216",
         "owner_name": "...", "amount_owed": 1234.56}

    Recommended approach, in priority order (per spec):
      1. Check if an Apify actor already exists for Baltimore city tax data
      2. Direct requests/BeautifulSoup scrape if the portal is plain HTML
      3. Playwright/browser-agent fallback if it requires JS rendering or login
      4. web_search aggregator as a last resort
    For now this returns an empty list so the module runs safely with
    zero results until the real scrape is implemented.
    """
    return []


def enrich_record(record: dict) -> dict:
    """
    Placeholder enrichment step. Real version should estimate ARV (e.g.
    via a comps API or LLM-assisted estimate) and repairs based on
    property age/condition signals, matching how the offer engine expects
    `arv` and `repairs_estimate` to be populated.
    """
    record.setdefault("arv", None)
    record.setdefault("repairs_estimate", None)
    return record


def run() -> dict:
    """
    Entry point called by the scheduler. Returns a summary dict for
    logging, and writes a row to scout_runs regardless of outcome.
    """
    conn = get_connection()
    run_started_at = datetime.now(timezone.utc).isoformat()

    raw_results = 0
    in_market_results = 0
    new_leads = 0
    portal_status = "OK"

    try:
        records = fetch_raw_records()
        raw_results = len(records)

        for record in records:
            enriched = enrich_record(record)
            result = insert_lead(
                address=enriched["address"],
                city=enriched.get("city", "Baltimore"),
                raw_zip=enriched.get("zip", ""),
                source=SOURCE_NAME,
                owner_name=enriched.get("owner_name"),
                arv=enriched.get("arv"),
                repairs_estimate=enriched.get("repairs_estimate"),
            )
            if result.accepted:
                in_market_results += 1
                new_leads += 1
            # If not accepted (out of market ZIP), it's simply not counted -
            # matches spec's "log to scout_runs.in_market_results denominator"

    except Exception as exc:  # noqa: BLE001 - log and continue, don't crash the scheduler
        portal_status = "ERROR"
        print(f"[{SOURCE_NAME}] scout run failed: {exc}")

    conn.execute(
        """
        INSERT INTO scout_runs (module, county_or_zip, run_at, raw_results,
                                 in_market_results, new_leads, portal_status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (SOURCE_NAME, "Baltimore City, MD", run_started_at,
         raw_results, in_market_results, new_leads, portal_status),
    )
    conn.commit()
    conn.close()

    summary = {
        "module": SOURCE_NAME,
        "raw_results": raw_results,
        "in_market_results": in_market_results,
        "new_leads": new_leads,
        "portal_status": portal_status,
    }
    print(f"[{SOURCE_NAME}] {summary}")
    return summary


if __name__ == "__main__":
    run()
