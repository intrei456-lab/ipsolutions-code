-- chris/db/migration_agent_tier_upgrade.sql
--
-- Run this once against an EXISTING chris.db that already has the
-- `agents` table from before agent_tier_transitions.py existed.
-- Fresh installs (via init_db()) get these automatically from
-- schema.sql and do not need this file.
--
-- Usage:
--   sqlite3 chris/db/chris.db < chris/db/migration_agent_tier_upgrade.sql

ALTER TABLE agents ADD COLUMN ever_reached_tier_1 INTEGER DEFAULT 0;
ALTER TABLE agents ADD COLUMN deal_closed INTEGER DEFAULT 0;

-- Backfill: any agent already sitting at TIER_1 or TIER_2 must have
-- reached TIER_1 at some point, so the flag needs to reflect that
-- retroactively or the tier-lock rule won't protect existing agents.
UPDATE agents SET ever_reached_tier_1 = 1 WHERE tier IN ('TIER_1', 'TIER_2');

CREATE TABLE IF NOT EXISTS agent_tier_history (
    history_id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id INTEGER NOT NULL REFERENCES agents(agent_id),
    from_tier TEXT,
    to_tier TEXT NOT NULL,
    reason TEXT,
    changed_at TEXT DEFAULT (datetime('now'))
);
