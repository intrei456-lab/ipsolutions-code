"""
No Deal Lost strategy — Keith Everett's 8-tool framework for recovering a
deal when rapport breaks, price stalls, or the seller goes quiet.

Trigger conditions (from transcript): broke rapport with the seller,
uncertain whether the seller is shopping the deal around, trying to
extract the best possible price, or a deal that simply didn't close.
"""

from dataclasses import dataclass


@dataclass
class NoDealLostTool:
    name: str
    description: str
    when_to_use: str


NO_DEAL_LOST_TOOLS: list[NoDealLostTool] = [
    NoDealLostTool(
        name="Multiple managers",
        description=(
            "Send a second acquisition manager to re-approach the seller "
            "after the first one couldn't close or broke rapport."
        ),
        when_to_use="Rapport broken, or seller unresponsive to the original rep.",
    ),
    NoDealLostTool(
        name="Multiple LLCs",
        description=(
            "A second entity re-approaches with a 'fresh' offer, presented "
            "as an entirely different company, if the first entity got burned "
            "or rejected."
        ),
        when_to_use="First company/offer was explicitly rejected or burned.",
    ),
    NoDealLostTool(
        name="Multiple contracts",
        description=(
            "The second contract should have MORE teeth (longer, more "
            "detailed, more addenda/extension options) than the first — this "
            "signals the second company is more serious/professional."
        ),
        when_to_use="Following up after a first contract attempt fell through.",
    ),
    NoDealLostTool(
        name="Multiple property specialists",
        description=(
            "Use a different property specialist (photo/condition rep) for "
            "the second approach — don't reuse the same person the seller "
            "already saw."
        ),
        when_to_use="Any re-approach with a different manager/entity.",
    ),
    NoDealLostTool(
        name="Reset expectations (dual-manager price play)",
        description=(
            "If unsure whether the seller will accept your number, have a "
            "second acquisition manager call and offer LOWER — this resets "
            "the seller's expectations and makes your original offer look "
            "like the right number. Can also run in reverse: have the second "
            "manager offer HIGHER to make your number seem like it wasn't "
            "the real ceiling, if you're trying to protect margin on a deal "
            "you're unsure about."
        ),
        when_to_use="Uncertain whether the seller will accept your price, or suspect they're shopping around.",
    ),
    NoDealLostTool(
        name="Get back in when locked out",
        description="New approach, new angle, new value proposition after being turned away.",
        when_to_use="Seller went cold or explicitly said no to the current approach.",
    ),
    NoDealLostTool(
        name="Place a lien / memorandum",
        description=(
            "File an Affidavit & Memorandum of Agreement (~$25 county filing) "
            "to protect your position on a juicy deal you don't want to lose "
            "to a competing wholesaler."
        ),
        when_to_use="High-value deal where double-selling risk is real. Confirm with closing attorney - filing rules vary by state.",
    ),
    NoDealLostTool(
        name="Always have a backup manager",
        description="Never run out of escalation options — always have another manager/entity in reserve.",
        when_to_use="Standing readiness, not a specific trigger.",
    ),
]
