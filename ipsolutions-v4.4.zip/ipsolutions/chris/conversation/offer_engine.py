"""
Offer engine — combines Keith Everett's "how to present an offer" formula
(6-point script, verbatim source in offer_presentation transcript) with
the numeric tier-ladder math from the original agent spec / shared config.

Keith's core rule, quoted directly: "pain + property condition + company
benefits = a great offer. Never make an offer without all three."
"""

from dataclasses import dataclass

from shared.config import (
    CASH_TIER_MULTIPLIERS,
    MAO_BREATHING_ROOM,
    NOVATION_DEFAULTS,
    NOVATION_MIN_IPS_PROFIT,
)


# ---------------------------------------------------------------------------
# Offer presentation script (Keith Everett's 6-point formula)
# ---------------------------------------------------------------------------

OFFER_PRESENTATION_RULES = """
Never present an offer without all three of these present:
  1. Seller's SPECIFIC pain (their own words, from the 7-pain-dig)
  2. Property condition (specific issues: roof, HVAC, kitchen, bathrooms, etc.)
  3. Company benefits (cash advance, close in 10 days, pay closing costs,
     buy as-is, realtor helps find new home, transactional specialist)

Always in LOW tonality. Always end with the ask — do NOT name your price
first: "What do you think is the absolute best you could do on this
property?"
"""


def build_offer_presentation_script(
    seller_name: str,
    pain_summary: str,          # seller's own words from the pain dig, e.g. "you had to evict a tenant..."
    condition_issues: list[str],  # e.g. ["the roof", "the HVAC", "the kitchen"]
    close_days: int = 10,
) -> str:
    """
    Renders Keith's exact 6-point offer script structure, filled in with
    this specific lead's pain/condition. This is the template Chris's
    conversation engine should render right before presenting a number.
    """
    condition_text = ", ".join(condition_issues) if condition_issues else "the areas we discussed"
    return (
        f"Mr./Mrs. {seller_name}, I totally understand you're looking to get "
        f"the property off your hands, and trust me — I want to move as "
        f"quick as possible for you. I know you said {pain_summary}. "
        f"What if I was able to take the property off your hands — you never "
        f"have to worry about fixing anything up. And knowing the "
        f"condition — {condition_text} — you don't have to put any more "
        f"money into it. I'll also give you a cash advance for moving "
        f"expenses. If I can do all of that and close in {close_days} "
        f"business days — you don't come out of pocket for anything — "
        f"what do you think is the absolute best you could do on this "
        f"property?"
    )


# ---------------------------------------------------------------------------
# Exit strategy decision (run BEFORE computing offer numbers)
# ---------------------------------------------------------------------------

EXIT_STRATEGY_WHOLESALE_ASSIGNMENT = "WHOLESALE_ASSIGNMENT"
EXIT_STRATEGY_NOVATION = "NOVATION"
EXIT_STRATEGY_SUBTO = "SUBTO"
EXIT_STRATEGY_JUNIOR_BROKERAGE = "JUNIOR_BROKERAGE"
EXIT_STRATEGY_NO_DEAL = "PROBABLY_NO_DEAL"


def decide_exit_strategy(rehab_cost: float, seller_wants_retail: bool) -> str:
    """
    Table from the spec:
      Heavy rehab ($30k+) + will take low price  -> WHOLESALE_ASSIGNMENT
      Heavy rehab ($30k+) + wants high price      -> PROBABLY_NO_DEAL
      Light rehab ($5-20k) + will take low price  -> WHOLESALE_ASSIGNMENT (easy for FP)
      Light rehab ($5-20k) + wants close to retail -> NOVATION
      Move-in ready + wants retail                -> NOVATION or JUNIOR_BROKERAGE
    """
    heavy_rehab = rehab_cost >= 30000
    if heavy_rehab:
        return EXIT_STRATEGY_NO_DEAL if seller_wants_retail else EXIT_STRATEGY_WHOLESALE_ASSIGNMENT
    # light rehab or move-in ready
    return EXIT_STRATEGY_NOVATION if seller_wants_retail else EXIT_STRATEGY_WHOLESALE_ASSIGNMENT


# ---------------------------------------------------------------------------
# Wholesale assignment tier ladder
# ---------------------------------------------------------------------------

@dataclass
class CashOfferLadder:
    t1: float
    t2: float
    t3: float
    mao_ceiling: float
    t1_floor: float  # never offer below this


def compute_cash_ladder(arv: float, repairs: float, assignment_fee_target: float) -> CashOfferLadder:
    """
    T1: ARV x 0.60 - Repairs - Fee   (OPENER - start here)
    T2: ARV x 0.65 - Repairs - Fee
    T3: ARV x 0.70 - Repairs - Fee
    MAO ceiling = Buy Right MAO + $15k breathing room
    Never offer below T1 floor.
    """
    t1 = arv * CASH_TIER_MULTIPLIERS["T1"] - repairs - assignment_fee_target
    t2 = arv * CASH_TIER_MULTIPLIERS["T2"] - repairs - assignment_fee_target
    t3 = arv * CASH_TIER_MULTIPLIERS["T3"] - repairs - assignment_fee_target
    mao_ceiling = t3 + MAO_BREATHING_ROOM
    return CashOfferLadder(t1=t1, t2=t2, t3=t3, mao_ceiling=mao_ceiling, t1_floor=t1)


def compute_assignment_fee(fp_max_price: float, ips_contract_price: float) -> float:
    """Assignment fee = FP's max price - IPSolutions contract price."""
    return fp_max_price - ips_contract_price


def compute_fp_max_price(arv: float, rehab: float, fp_profit_target: float = 17500,
                          closing_cost_pct: float = 0.05) -> float:
    """FP max price: ARV - rehab - FP's profit (~$15-20k) - closing costs (~5%)."""
    return arv - rehab - fp_profit_target - (arv * closing_cost_pct)


def is_double_close_recommended(assignment_fee: float, contract_price: float) -> bool:
    """Auto-flag when assignment fee exceeds 50% of contract price."""
    if contract_price <= 0:
        return False
    return (assignment_fee / contract_price) > 0.50


# ---------------------------------------------------------------------------
# Novation math (CMV-based)
# ---------------------------------------------------------------------------

@dataclass
class NovationResult:
    list_price: float
    ips_profit: float
    meets_minimum: bool


def compute_novation(
    cmv: float,                 # Current Market Value, NOT ARV
    seller_agreed_net: float,
    rehab_cost: float,
    agent_commission_pct: float = NOVATION_DEFAULTS["agent_commission_pct"],
    closing_cost_pct: float = NOVATION_DEFAULTS["closing_cost_pct"],
) -> NovationResult:
    """
    MLS list price = CMV x 0.90
    IPS profit = list_price - seller_net - rehab - commission - closing_costs
    Must be >= $15,000 or the novation path should be rejected.
    """
    list_price = cmv * 0.90
    commission = list_price * agent_commission_pct
    closing_costs = list_price * closing_cost_pct
    ips_profit = list_price - seller_agreed_net - rehab_cost - commission - closing_costs
    return NovationResult(
        list_price=list_price,
        ips_profit=ips_profit,
        meets_minimum=ips_profit >= NOVATION_MIN_IPS_PROFIT,
    )
