"""
Seller Hold-Back + Structured Price Reduction — both from Keith Everett's
transcripts. Kept in one file since they're closely related tools (both
involve renegotiating terms after initial agreement, both require getting
the title company and all parties aligned).
"""

from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Seller Hold-Back
# ---------------------------------------------------------------------------

SELLER_HOLDBACK_DEFINITION = (
    "Closing on the property before the seller has fully moved out, while "
    "holding back a percentage of the sale funds in escrow with the title "
    "company until the seller vacates or completes an agreed condition."
)

SELLER_HOLDBACK_TRIGGERS = [
    "Tenant needs additional time to move out",
    "Seller needs additional time to clean out the property",
    "Seller needs most of the funds up front to close on a new property",
]


def build_seller_holdback_example(total_price: float, holdback_amount: float) -> str:
    release_amount = total_price - holdback_amount
    return (
        f"We can close on ${release_amount:,.0f} now, and hold back "
        f"${holdback_amount:,.0f} in the title company's escrow account "
        f"until [condition met - move-out complete / property cleaned out]. "
        f"That way you get most of your funds now and the rest once "
        f"everything's squared away."
    )


BUYER_HOLDBACK_NOTE = (
    "If the seller won't agree to a hold-back, ask the buyer (financial "
    "partner) if THEY'D be willing to hold back a portion of their "
    "assignment fee instead, to make the early close work for the seller."
)

SELLER_HOLDBACK_REQUIREMENTS = [
    "All parties (seller, buyer/FP, and title company) must agree to the terms",
    "Title company must be notified before closing",
    "A signed addendum is required to officially execute the hold-back",
]


# ---------------------------------------------------------------------------
# Structured Price Reduction
# ---------------------------------------------------------------------------

@dataclass
class PriceReductionTrigger:
    trigger: str
    typical_reduction: str
    note: str = ""


PRICE_REDUCTION_TRIGGERS: list[PriceReductionTrigger] = [
    PriceReductionTrigger(
        trigger="No interested financial partners after the deal has been out 2-3 days",
        typical_reduction="Re-evaluate against comps",
        note="Signal the price is simply too high for the current condition/market.",
    ),
    PriceReductionTrigger(
        trigger="Property condition verified worse than seller originally described",
        typical_reduction="Based on actual added renovation cost",
        note="Property Specialist visit revealed issues the seller didn't disclose.",
    ),
    PriceReductionTrigger(
        trigger="Tenant eviction required",
        typical_reduction="$5,000-$10,000",
        note="Covers eviction time, risk of contractor scheduling loss, and delay.",
    ),
    PriceReductionTrigger(
        trigger="Property needs to be cleaned out (seller left belongings/trash)",
        typical_reduction="$5,000-$10,000",
        note="Covers dumpster/cleanout labor and time.",
    ),
    PriceReductionTrigger(
        trigger="Low offers from financial partners",
        typical_reduction="Negotiate down toward what the FP actually offered",
        note="Strongest leverage when the FP has also given a specific close date - use both as ammo with the seller.",
    ),
]

PRICE_REDUCTION_GOLDEN_RULE = (
    "The person who originally locked up the deal should NEVER be the one "
    "to call about a price reduction. A second party — introduced as a "
    "higher authority (Finance Manager) — makes the call instead. This "
    "resets the seller's expectations and keeps them from associating the "
    "bad news with the person they built rapport with."
)


def build_price_reduction_script(
    finance_manager_name: str,
    property_address: str,
    original_price: float,
    anchor_low_price: float,
    target_price: float,
    proposed_close_date: str,
    reason: str,  # e.g. "the home needs more work than we anticipated"
) -> str:
    """
    Renders the full multi-paragraph Vanessa Carter / finance-manager price
    reduction script, structured exactly as Keith's transcript lays it out:
    greeting -> introduce as finance dept authority -> mention progress
    already made (title/deed work started) -> list cost burden -> ask if
    price is negotiable -> anchor low -> land on target -> close or hold.
    """
    return f"""Hi, this is {finance_manager_name}, I'm one of the buying specialists here in the finance department at Intense Property Solutions. I was calling about the property we're getting ready to purchase at {property_address}. Our property specialist and contractors got a chance to look things over, and after meeting for a while about the renovation costs, they mentioned the home will need a bit more work than we originally anticipated — specifically, {reason}.

The good news is our transactional specialist let me know the title work has already started — the deed preparation and title search are underway. We're just looking to get a closing date set. It's just that with the added renovation costs, it puts us in a bit of an over-leveraged position.

I want to be transparent with you — we have to purchase the property, pay closing costs, carry insurance on the property and our contractors, cover utilities until it sells, pay for the renovation, and then pay closing costs and commissions again when we sell. We're not looking to make a huge profit here, just enough to make it work.

My question is — is that price of ${original_price:,.0f} at all negotiable if I can get a closing date locked in for you this week?

[If seller is open:] I'll be honest with you — after running the numbers, my partners wanted to be around ${anchor_low_price:,.0f} plus closing costs. I told them that wasn't going to work, and that if we could cut costs somewhere on the renovation, we could meet in the middle. Could we land at ${target_price:,.0f} and set the closing date for {proposed_close_date}? We'll still take care of the closing costs — you have my word on that.

[If seller declines the range:] Let me place you on a brief hold for a moment — I want to see if we can cut renovation costs somewhere and get this behind you."""
