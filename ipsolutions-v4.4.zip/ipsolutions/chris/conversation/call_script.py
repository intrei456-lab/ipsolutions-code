"""
Call script — Keith Everett's "Hustle Seller Script." Covers every opener
variant (return call, PPC, live answer, text blast, cold call/deal
machine) and the full script flow from greeting through closing.
"""

from dataclasses import dataclass


GREETING_RULE = (
    "Always start a call friendly and with enthusiasm - the first 10 "
    "seconds determines the seller's mood for the rest of the call. If they "
    "were in a bad mood, you can shift it; if they're in a good mood, they "
    "want to feel that same energy back."
)

GREETING_SCRIPT = "Hi, how are you doing today?"


# ---------------------------------------------------------------------------
# Openers by lead source
# ---------------------------------------------------------------------------

@dataclass
class Opener:
    source: str
    script: str
    note: str = ""


OPENERS: list[Opener] = [
    Opener(
        source="RETURN_CALL",
        script=(
            "Hi, this is [Name] with [Company]. I'm returning the call "
            "about a property that might be for sale — do I have the right "
            "number? [confirm] Great — my name is [Name], who do I have the "
            "pleasure of speaking with today?"
        ),
    ),
    Opener(
        source="PPC_ONLINE_FORM",
        script=(
            "Hi, this is [Name] with [Company]. I see you inquired online "
            "about a property that might be for sale — do I have the right "
            "number? [confirm] Great — my name is [Name], who do I have the "
            "pleasure of speaking with today?"
        ),
    ),
    Opener(
        source="LIVE_ANSWER",
        script="Hi, this is [Name], we buy houses — how may I help you?",
        note=(
            "Requires reading the room: if the seller already gives the "
            "address (e.g. responding to a direct-mail postcard), skip the "
            "address-verification step later in the script and go straight "
            "to lead qualification. Awareness over rigid script-following."
        ),
    ),
    Opener(
        source="TEXT_BLAST",
        script=(
            "Hi, this is [Name] with [Company]. I'm giving you a call in "
            "response to a text message about purchasing a property at "
            "[address] — am I speaking with [Name]?"
        ),
    ),
    Opener(
        source="COLD_CALL",
        script=(
            "My name is [Name] with [Company]. I'm not even sure if I have "
            "the right number, but my partner has a property I believe you "
            "may own at [address], and I was wondering if you'd be "
            "interested in a cash offer on that property."
        ),
        note="Only cold-call source in this framework is Deal Machine-sourced leads.",
    ),
]


def get_opener(source: str) -> Opener | None:
    return next((o for o in OPENERS if o.source == source), None)


# ---------------------------------------------------------------------------
# Hustle Seller Script - full sequence
# ---------------------------------------------------------------------------

HUSTLE_SCRIPT_SEQUENCE = [
    {
        "step": "intro",
        "script": (
            "Thank you. My intention is to give you the best cash offer "
            "that I possibly can. I just need to ask a few questions about "
            "the property — do you have about five minutes?"
        ),
    },
    {
        "step": "verify_address",
        "script": "Great, could you verify the address of the property?",
        "note": "Skip if address was already given (e.g. via live-answer/postcard response).",
    },
    {
        "step": "dm_gate",
        "script": "Before we get started, is there anyone other than yourself involved in the decision-making process?",
        "note": "CRITICAL - must run before any property/price discussion. See dm_gate.py.",
    },
    {
        "step": "occupancy",
        "script": "Is the property vacant, tenant-occupied, or do you currently occupy it yourself?",
    },
    {
        "step": "condition_pt1",
        "script": (
            "Can you tell me a little about the condition of the home — "
            "the age of the roof, the age of the HVAC?"
        ),
        "note": (
            "Ask two questions at once so the seller gives an extended "
            "answer - this buys time to pull comps in the background "
            "(PropStream/similar) while they talk."
        ),
    },
    {
        "step": "condition_pt2",
        "script": "What can you tell me about the foundation, electrical, and plumbing?",
        "note": "Three-part question, same technique - buys more comp-pulling time.",
    },
    {
        "step": "condition_pt3",
        "script": "How about the kitchen and bathrooms — have you done any upgrades in the past 5 years?",
    },
    {
        "step": "reason_for_selling",
        "script": (
            "It sounds like a nice home. My partner actually purchased a "
            "house a few years ago on [nearby street]. If you don't mind me "
            "asking, what's the reason you're looking to possibly sell?"
        ),
        "note": "LOW TONALITY from here forward - this is the first serious question. Feeds into the 7-pain-dig.",
    },
    {
        "step": "timeline",
        "script": (
            "If I was able to get this property off your hands and we "
            "agreed on a price, how soon would you like to get this done?"
        ),
        "note": "LOW TONALITY.",
    },
    {
        "step": "moving_assistance",
        "script": "Do you think you may need any moving assistance?",
        "note": "Opens the door to mention Company Benefits (cash advance, etc).",
    },
    {
        "step": "liens_mortgage",
        "script": "Great — do we need to pay off any liens, mortgages, or anything else on the property?",
        "note": "Determines what the seller actually nets, feeds the offer math.",
    },
    {
        "step": "comps_presentation",
        "script": (
            "I pulled up a few comparable homes in your neighborhood sold "
            "in the last 6-12 months. Have you heard of [nearest comparable "
            "street]? ... I'm seeing similar properties selling anywhere "
            "from ${low:,.0f} to ${high:,.0f} cash. I know we discussed "
            "your home needs a few improvements to be brought up to "
            "current standards."
        ),
        "note": "NEVER give exact comp numbers - always a range. Use the closest possible street for credibility.",
    },
    {
        "step": "drive_price",
        "script": "Did you have a price in mind you'd like to get for the property?",
        "note": "If no answer, fall back to the drive-the-price-out script (negotiation.py DRIVE_PRICE_SCRIPT).",
    },
    {
        "step": "recap_and_ask",
        "script": (
            "[Recap pain + benefits + condition, using seller's own words] "
            "... is that the absolute best price you can do?"
        ),
    },
    {
        "step": "squeeze_and_hold",
        "script": (
            "I'll be honest, that's gonna be a little tight for us. Let me "
            "speak to my buying specialist in the finance department — but "
            "before I do, if I was able to meet that price, would you be "
            "willing to get the process started today? And what's a good "
            "email? I want to send over our Company Commitment while I "
            "check."
        ),
        "note": "Act like the price is tight even if it isn't - never accept instantly. This is the Blue Trap countermeasure applied inside the live script.",
    },
    {
        "step": "hold",
        "script": (
            "I'm going to put you on a brief hold while you look over the "
            "Company Commitment, and I'll go check with the finance "
            "department."
        ),
        "note": "Prefer an actual brief hold over hanging up and calling back - reduces risk of losing the seller or a competing call getting through.",
    },
    {
        "step": "return_from_hold",
        "script": (
            "Thanks for your patience — I did get a chance to speak with my "
            "buying specialist about the property. I'll be honest, it's "
            "tight for us, but it looks like we can make that work. We are "
            "looking at a few other properties, but yours is the priority — "
            "we'd need to get the process started today to lock in those "
            "funds."
        ),
        "note": "Always frame 'other properties' alongside 'yours is the priority' - mentioning competition without reassurance risks offending the seller.",
    },
    {
        "step": "closing_cost_box",
        "script": (
            "I know you wanted ${seller_ask:,.0f} with us covering closing "
            "— here's what we can do: ${higher:,.0f} and you cover closing, "
            "or ${lower:,.0f} and we cover closing. Either way we already "
            "got the funds approved, just let me know which works."
        ),
        "note": "See negotiation.py build_closing_cost_box_script for the generator.",
    },
    {
        "step": "send_agreement",
        "script": (
            "I'm going to send over a one-page written offer — let me know "
            "when you get it so we can go through it together and I can "
            "answer any questions."
        ),
    },
    {
        "step": "walk_agreement",
        "script": "[Go through each numbered section slowly] Does that make sense? Are you still with me?",
        "note": "Ask this after EVERY section before moving to the next. Never rush - speed reduces trust.",
    },
    {
        "step": "get_autograph",
        "script": (
            "All you need to do is put your autograph on it — it'll send "
            "you a copy and send me one back. I'm going to stay on the "
            "phone until it goes through, just to make sure everything "
            "works smoothly."
        ),
        "note": "NEVER hang up before the signature completes.",
    },
    {
        "step": "closing_handoff",
        "script": (
            "Congratulations on the sale of your home. My transactional "
            "specialist, [Name], will reach out within 24 hours to walk "
            "through next steps. Save her number so you recognize the call "
            "— I'm always here too, but she'll be your main point of "
            "contact going forward."
        ),
    },
]
