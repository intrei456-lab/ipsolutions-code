"""
Handling sellers with multiple competing offers — Keith Everett's 8-rule
framework. Mindset note from the transcript: requires an "abundance
mentality" rather than scarcity/panic when other parties are bidding on
the same property.
"""

from dataclasses import dataclass


@dataclass
class MultipleOffersRule:
    rule_number: int
    name: str
    detail: str


MULTIPLE_OFFERS_RULES: list[MultipleOffersRule] = [
    MultipleOffersRule(
        1, "Build the best rapport over the phone",
        "Sellers do business with people they trust. This is the foundation everything else builds on.",
    ),
    MultipleOffersRule(
        2, "Close quickly / move fast",
        (
            "Speed beats slower competitors even if they engaged the seller "
            "first - e.g. a competitor sets an appointment for Wednesday, "
            "you close by phone on Monday."
        ),
    ),
    MultipleOffersRule(
        3, "Offer the best benefits",
        "Moving expenses, movers, property cleanout, fast close (7 days), realtor help finding a new home.",
    ),
    MultipleOffersRule(
        4, "Be the LAST one to view the property",
        (
            "If multiple parties need to see the property in person, "
            "negotiate to be scheduled last - last impression wins. Being "
            "first risks losing the deal; being in the middle makes you "
            "forgettable. Ask directly for a later or earlier slot outside "
            "the normal window if needed (e.g. 'is it possible to view "
            "early Saturday morning, before your other appointments')."
        ),
    ),
    MultipleOffersRule(
        5, "Be confident when presenting the offer",
        (
            "Sellers pay attention to who sounds like the expert. Reference "
            "specific streets/schools/neighboring purchases - tell them "
            "what the property is worth, don't ask them to tell you."
        ),
    ),
    MultipleOffersRule(
        6, "Have proof of funds ready",
        "Required to win against competing offers when a seller is comparing multiple parties directly.",
    ),
    MultipleOffersRule(
        7, "Only bring VIP financial partners to competitive situations",
        (
            "Build real relationships with a small set of proven partners; "
            "bring them to view the property in person alongside you when "
            "competing, so you can make an on-site offer with the partner "
            "already ready to buy."
        ),
    ),
    MultipleOffersRule(
        8, "Close fast using private/hard money if needed",
        (
            "If competing offers need 7-30 days to close and you can close "
            "in 2-4 days via private money, that speed advantage can win "
            "the deal outright."
        ),
    ),
]


LATE_VIEWING_REQUEST_SCRIPT = (
    "I totally understand your last viewing is at [time], but I don't get "
    "back into town until a bit after that. Would it be possible to view "
    "the property early [next available time] instead? I want to make sure "
    "I can give you the best possible price."
)
