"""
Honest novation transition script — presents the cash-vs-novation trade-off
transparently: real price disclosed as part of the offer, real (documented)
risk of other wholesalers failing to perform disclosed as a genuine
warning rather than a fabricated anecdote, no invented "approval" or
scarcity framing. Seller gets the information needed to actually decide.

This exists as the direct, disclosure-first alternative to a
manufactured-urgency version of the same underlying trade-off (higher
price, more time, more complexity - which is a real and fair trade-off to
offer, just not one that should be pitched by withholding the number).
"""


def build_honest_novation_transition_script(
    seller_name: str,
    cash_offer_amount: float,
    novation_offer_low: float,
    novation_offer_high: float,
    novation_timeline_days: int = 60,
) -> str:
    """
    Renders a transparent version of the cash -> novation transition.
    Price is disclosed as part of the offer itself, not withheld until
    after emotional commitment. The seller can ask questions and reach
    their own conclusion before agreeing to anything.
    """
    return f"""Mr./Mrs. {seller_name}, our cash offer on the property is ${cash_offer_amount:,.0f} — that's the number if you need this closed fast, as-is, no repairs, no realtor fees.

There's a second option that could get you more money, but it comes with a real trade-off, so let me lay it out honestly: we also have a program where instead of buying the property ourselves, we list it on the open market and find a retail buyer — someone who's going to live in the home. Because that buyer typically needs mortgage financing, this option realistically takes about {novation_timeline_days} days from start to finish, not the 10 days our cash offer gives you. In exchange, the number is meaningfully higher — based on what similar homes in the area are selling for, we'd expect somewhere between ${novation_offer_low:,.0f} and ${novation_offer_high:,.0f}, after covering the listing and closing costs.

One thing I do want to be upfront about, since it matters for a decision like this: there are wholesalers out there who lock up a deal, promise a certain number or timeline, and then aren't actually able to follow through — sometimes that surfaces late, even close to closing. That's a real risk in this industry, and it's worth asking any company you work with — including us — how we'd handle it if a buyer fell through, and what protections are in the contract for you if that happens.

So the real question is what matters more to you right now: speed and certainty at ${cash_offer_amount:,.0f}, or more money with a longer timeline. There's no wrong answer — it depends on your situation. What would you like to know more about before deciding?"""


HONEST_PITCH_PRINCIPLES = [
    "Disclose the actual price range as part of the pitch itself, not after the seller has already committed emotionally.",
    "Present the trade-off (speed/certainty vs. higher price/longer timeline) as a real choice, not a one-sided sales close.",
    "If warning about wholesaler non-performance risk, frame it as a real, checkable risk with a real question the seller can ask any company (including yours) - not a fabricated specific story about a named individual.",
    "Never invent an 'approval' or scarcity framing for an offer that isn't actually gated by real underwriting or limited availability.",
    "End with a genuine open question, not a scripted close designed to prevent the seller from pausing to think.",
]
