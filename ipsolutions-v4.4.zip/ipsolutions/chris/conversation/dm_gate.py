"""
DM Gate — from Keith Everett's "Closing All Parties" transcript.
Rule: confirm every decision-maker BEFORE asking anything else about the
property (before price, before condition, before timeline). This must run
before pain_dig or offer presentation.
"""

DM_GATE_SCRIPT = (
    "I totally understand I'm on the phone with you right now, but I've got "
    "a quick question — is there anybody other than yourself that's a "
    "decision maker on this property? Because if they are, I want to give "
    "them the proper respect — I don't want to step on any toes."
)

DM_GATE_RULES = """
1. Ask about ALL decision-makers FIRST — before price, before condition,
   before timeline. This is the very first substantive question of the call.
2. If all parties are NOT present/confirmed → give an OFFER RANGE only,
   never a hard number. A hard number given to one party when another
   decision-maker exists will fall apart when they consult each other.
3. Before making any hard offer, gather all parties — on the phone
   together or in person — then present the real number.
"""


def should_give_range_only(all_decision_makers_confirmed: bool) -> bool:
    """
    If not every decision-maker has been identified/gathered, the offer
    presentation step should render a range, not a hard number.
    """
    return not all_decision_makers_confirmed
