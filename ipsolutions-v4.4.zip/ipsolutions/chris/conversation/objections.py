"""
Objection handling — sourced directly from Keith Everett's "Mastering the
Art of Acquisitions 101" Otter transcripts (Objections Part 1 & 2), not the
condensed one-liners in the original agent spec. Where the spec's summary
and the real transcript differ in detail, the transcript wins since it's
the primary source Chris's original instructions were compressed from.

Universal probe (used first on almost every objection, per Keith):
    "How do you feel about that price?"
Keith's own words: "nine times out of ten it's always the price."
"""

from dataclasses import dataclass


@dataclass
class Objection:
    trigger_phrases: list[str]      # phrases in seller's words that indicate this objection
    category: str                   # groups Part 1 / Part 2 for reference
    rebuttal_script: str            # near-verbatim script from the transcript
    tactical_note: str = ""         # extra guidance beyond the script itself


UNIVERSAL_PRICE_PROBE = (
    "I totally understand that you [said/need to X], and trust me, I totally "
    "understand — but let me ask you this, I'm just curious: how do you feel "
    "about that price?"
)

OBJECTIONS: list[Objection] = [
    Objection(
        trigger_phrases=["want to think about it", "need to think it over", "let me think"],
        category="part1",
        rebuttal_script=(
            "I totally understand you need to think about it, and trust me, I "
            "wouldn't want you to do it any other way. But let me ask you this — "
            "how do you feel about the price? [If price is the issue] So I "
            "totally understand you're feeling the price, but you still need "
            "some time — I won't want you to do it any other way. But let me "
            "check with my finance department about securing the funds to the "
            "side for you until we speak again — I just don't want to miss out "
            "on the opportunity to help you out."
        ),
        tactical_note=(
            "If seller agrees to let you 'secure the funds to the side,' they "
            "will very likely sign. If they say 'don't tie up your funds,' the "
            "real objection is the price — treat as unresolved."
        ),
    ),
    Objection(
        trigger_phrases=["talk to my lawyer", "speak to my attorney", "run it by my lawyer", "talk it over with my lawyer", "talk it over with my attorney"],
        category="part1",
        rebuttal_script=(
            "I totally understand you want to speak to your attorney, and I "
            "wouldn't want you to do it any other way. But how do you feel "
            "about the price? [If not price] I totally understand — actually, "
            "if you can get your attorney on the phone right now, I can go "
            "over the agreement with them directly so we're all on the same "
            "page."
        ),
        tactical_note="Usually an analytical (GREEN) seller. Could be a smokescreen — always probe price first.",
    ),
    Objection(
        trigger_phrases=["talk to my spouse", "check with my husband", "check with my wife"],
        category="part1",
        rebuttal_script=(
            "[This should have been caught at the DM gate before any offer talk. "
            "If it comes up anyway:] I totally understand — how do you feel "
            "about the price?"
        ),
        tactical_note="Root cause: DM gate wasn't run properly at the start of the call. Always confirm all decision-makers before any price discussion.",
    ),
    Objection(
        trigger_phrases=["just send me the agreement", "just send over the contract"],
        category="part1",
        rebuttal_script=(
            "I totally understand, but it's company policy that we go over "
            "the agreement together — I want to make sure you understand every "
            "term. I can send you a blank copy to look at, but when it's time "
            "to go over the real agreement, would 5pm work when you're off "
            "work? That way you can pull it up on your email and we go over "
            "every bullet point together."
        ),
        tactical_note="Never send a contract to a seller without walking through it live — this is the #1 cause of contracts going unsigned.",
    ),
    Objection(
        trigger_phrases=["just make me an offer", "give me your best number"],
        category="part1",
        rebuttal_script=(
            "I totally understand you're looking to receive a cash offer, but "
            "I'm planning on giving you a large amount of money in a short "
            "period of time — so if you could tell me a little more about the "
            "property, I can give you the absolute best cash offer I possibly can."
        ),
        tactical_note="Typically a RED (aggressive) seller. Don't match their energy — slow them down.",
    ),
    Objection(
        trigger_phrases=["don't know what i want", "not sure what to ask for"],
        category="part1",
        rebuttal_script=(
            "You've got to have some kind of number — if I offered you a "
            "million dollars you'd probably take it, if I offered $10,000 "
            "you'd probably hang up. It doesn't have to be a hard figure, "
            "even a range works. I just want to make sure we're on the same "
            "page and I'm not wasting your time."
        ),
    ),
    Objection(
        trigger_phrases=["have you seen the property", "have you seen it yet"],
        category="part1",
        rebuttal_script=(
            "I haven't seen the inside, but one of my partners was in the "
            "neighborhood a couple days ago, and I actually drove by myself "
            "yesterday since I was checking on one of my rental properties in "
            "the area — so I know the outside and surrounding area well. I'd "
            "love to see the inside though — is tomorrow at 2pm best, or "
            "would 11am work better?"
        ),
        tactical_note="Always offer two specific times (one morning, one afternoon), never an open-ended 'whenever works.'",
    ),
    Objection(
        trigger_phrases=["don't want to disturb my tenants", "can sell but tenants"],
        category="part1",
        rebuttal_script=(
            "Do you have a lease on the tenants, and do you have something "
            "showing they're paying on time? We typically like to purchase "
            "vacant, but if we can't disturb the tenants, we need to know if "
            "they're current, when the lease ends, and whether we'd need to "
            "evict. If eviction is needed, we may need to bring the price down "
            "$5,000-$10,000 to account for the time and cost of getting them "
            "out — but we're willing to work with you if you can work with us."
        ),
        tactical_note="Read between the lines: 'don't want to disturb tenants' often means they aren't paying. Dig with the lease/P&L questions before assuming.",
    ),
    Objection(
        trigger_phrases=["you called me", "why are you calling me"],
        category="part1",
        rebuttal_script=(
            "You're absolutely right, I did call you — but while I've got you, "
            "have you ever thought about selling? Just wanted to see if I "
            "could add some value to you."
        ),
        tactical_note="Keep it short.",
    ),
    Objection(
        trigger_phrases=["which property", "which property are you interested in"],
        category="part1",
        rebuttal_script=(
            "I'm actually doing a 1031 exchange right now and need to "
            "liquidate funds into more than one property — if you can give me "
            "every address you own, I'd love to look into each one and see "
            "where I can make you a cash offer. [Alt] My marketing department "
            "usually includes that info — they may have missed it this time. "
            "Mind telling me the address so I can look into it properly?"
        ),
    ),
    Objection(
        trigger_phrases=["how did you get my number", "how'd you get my number"],
        category="part2",
        rebuttal_script=(
            "Our marketing department pulls that through public records and "
            "tax records. But while I've got you — are you possibly interested "
            "in selling your property? Just here to see if I can add value."
        ),
        tactical_note="Keep it short and sweet, then pivot immediately.",
    ),
    Objection(
        trigger_phrases=["going to lowball me", "you're gonna lowball"],
        category="part2",
        rebuttal_script=(
            "I'm just looking to give you the best possible cash offer. We "
            "look at two things — what properties like yours are selling for "
            "as-is, and what they'd sell for at full 2020 [current] standards. "
            "Tell me a bit more about the property and I'll give you the best "
            "number I can."
        ),
    ),
    Objection(
        trigger_phrases=["never heard of your company", "who are you guys"],
        category="part2",
        rebuttal_script=(
            "You can check out our website, and I'll give you the title "
            "company's number too — they handle all our files and can vouch "
            "for us. We're also with the Better Business Bureau if you want "
            "to verify us there."
        ),
        tactical_note=(
            "Requires actually having: a website, a real title-company "
            "relationship, BBB verification, and a Company Commitment PDF "
            "ready to send. Build these before this rebuttal is usable live."
        ),
    ),
    Objection(
        trigger_phrases=["need 60 days to move", "need two months to move out"],
        category="part2",
        rebuttal_script=(
            "Have you found your new place yet? If not, I can have our realtor "
            "help you find your next destination so you can move quicker. Do "
            "you think you might need a cash advance for moving expenses? My "
            "goal isn't just to buy the property — I want to make sure you get "
            "to your next place safely."
        ),
        tactical_note=(
            "This objection is the direct trigger for the Seller Hold-Back "
            "tool: e.g. purchase at $100k, close on $90k up front, hold back "
            "$10k released once the seller vacates on the agreed timeline."
        ),
    ),
    Objection(
        trigger_phrases=["i have squatters", "there's squatters in the house"],
        category="part2",
        rebuttal_script=(
            "[Tactical, not a verbal rebuttal] Have the homeowner call 911 to "
            "meet you at the property — this gets you inside legally. Take "
            "photos once inside. Then negotiate directly with the squatter — "
            "sometimes a payment to leave is the fastest resolution."
        ),
        tactical_note="Adjust the offer downward to account for eviction/cleanout cost and time.",
    ),
    Objection(
        trigger_phrases=["want to hold off", "let's hold off for now"],
        category="part2",
        rebuttal_script=UNIVERSAL_PRICE_PROBE,
        tactical_note="Also check: was there an undisclosed decision-maker? Almost always price, per Keith.",
    ),
    Objection(
        trigger_phrases=["my realtor said", "realtor told me it's worth"],
        category="part2",
        rebuttal_script=(
            "I respect their opinion, but does your realtor buy properties "
            "and fix them up, or do they just sell them? And were those comps "
            "as-is condition, or fully renovated to today's standards? I just "
            "want to make sure we're looking at the property through the same "
            "lens — our company doesn't purchase at retail value."
        ),
    ),
    Objection(
        trigger_phrases=["do you have proof of funds", "can i see proof of funds"],
        category="part2",
        rebuttal_script=(
            "Of course — what's a good email? I want to get that right over "
            "to you, especially if it matters to you, because it matters to "
            "us too. We're very serious about purchasing your property."
        ),
        tactical_note="Have an actual POF letter ready (bank statement, LOC letter, or funding-network document) before this rebuttal is usable live.",
    ),
    Objection(
        trigger_phrases=["home next door sold for", "neighbor's house sold for"],
        category="part2",
        rebuttal_script=(
            "Was that property in tip-top, current-standards condition, or "
            "did they sell as-is? We're investors, not retail buyers — we "
            "need enough room to fix the property up, cover closing costs and "
            "realtor fees, and still make a small profit. We're not trying to "
            "hit the lottery here."
        ),
    ),
    Objection(
        trigger_phrases=["home appraised for", "it appraised at"],
        category="part2",
        rebuttal_script=(
            "I totally understand it appraised at that number, but appraisals "
            "are really for the bank — for refinancing or a bank loan. We're "
            "not looking for bank financing, we have cash, and we buy based "
            "on what properties are actually selling for in the neighborhood "
            "as-is."
        ),
    ),
]


def find_matching_objection(seller_text: str) -> Objection | None:
    """
    Naive keyword match against trigger phrases. In production this should
    likely be backed by an LLM call for more robust matching against
    however the seller actually phrases things, but this gives a fast,
    free first pass before falling back to an LLM.
    """
    text_lower = seller_text.lower()
    for objection in OBJECTIONS:
        if any(phrase in text_lower for phrase in objection.trigger_phrases):
            return objection
    return None
