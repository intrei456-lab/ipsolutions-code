"""
Novation mechanics — sourced from Tony's exit-strategy transcript. This is
the real underlying mechanics of why/how a novation works, which enriches
Alex's Novation Path 2 spec with the actual reasoning behind each rule.

Core definition: "novate" means to replace - you have a purchase agreement
with the seller, and instead of assigning it to an investor, you replace
it with a new purchase agreement between the seller and an end (retail)
buyer. This exists specifically because most mortgage lenders (FHA, VA,
conventional) will NOT fund a purchase where the buyer is taking an
assigned contract - they require the buyer to be an original party to a
lender-underwritten agreement.
"""

from dataclasses import dataclass


NOVATION_DEFINITION = (
    "To novate means to replace. Instead of assigning your purchase "
    "agreement to an investor, you replace it with a new purchase "
    "agreement between the seller and a retail (end-user) buyer. You still "
    "make an assignment-fee-equivalent spread between what the seller nets "
    "and what the buyer pays, but the mechanism is different because a "
    "retail buyer's lender won't fund an assigned contract."
)

WHY_NOT_ASSIGNMENT_TO_RETAIL_BUYER = (
    "Most mortgage lenders (FHA, VA, conventional) will not fund a purchase "
    "where the buyer's contract was assigned from a third party - they "
    "require the buyer to be an original contracting party. Novation "
    "solves this by replacing the contract rather than assigning it, "
    "which unlocks every retail buyer with any loan type (FHA, VA, "
    "USDA, conventional, or cash)."
)

WHY_NOT_DOUBLE_CLOSE = (
    "Most lenders won't fund a double-close either, and FHA/VA buyers "
    "specifically cannot be used in a double-close structure at all. Some "
    "conventional lenders will allow a double-close, but for FHA/VA "
    "buyers novation is effectively required."
)


# ---------------------------------------------------------------------------
# When a property is a good novation candidate
# ---------------------------------------------------------------------------

NOVATION_CANDIDATE_CRITERIA = {
    "condition": "Move-in ready or close to it - may need light cleanup but nothing mechanical. Should pass FHA minimum property requirements, since FHA buyers have the strictest lending requirements of any retail loan type.",
    "seller_timeline": "Seller must be able to wait ~60 days minimum. Never pitch novation to a seller facing an imminent deadline (e.g. auction next week) - that pushes them back to a cash/low-tier offer instead.",
    "market_rents_low_relative_to_value": (
        "A strong novation candidate often overlaps with buy-and-hold criteria "
        "(move-in ready), but wins out specifically when local rents are too "
        "low relative to current market value for a buy-and-hold investor to "
        "cash flow. If rents support a healthy buy-and-hold return, that may "
        "be the simpler/faster exit instead."
    ),
}

REQUIRES_EDUCATING_AGENTS_NOTE = (
    "Listing agents and buyer's agents are frequently unfamiliar with "
    "novations and will look confused when the term comes up - they're used "
    "to standard MLS transactions. Explain the process clearly to any "
    "agent involved (listing or buyer's side) so everyone is aligned from "
    "day one. Skipping this education step is one of the two most common "
    "ways a novation deal blows up (the other is using a title company "
    "unfamiliar with novations)."
)


# ---------------------------------------------------------------------------
# CMV-based math (current market value, NOT ARV)
# ---------------------------------------------------------------------------

@dataclass
class NovationOfferRange:
    list_price: float
    net_after_soft_costs: float
    offer_low: float
    offer_high: float


def compute_novation_offer_range(
    current_market_value: float,   # as-is value, NOT after-repair value
    soft_cost_pct: float = 0.10,   # commissions (~5-6%) + closing costs (~1.5-2%) + buffer
    assignment_fee_low: float = 15000,
    assignment_fee_high: float = 25000,
) -> NovationOfferRange:
    """
    Real math from Tony's transcript, using CMV (as-is value) rather than
    ARV - CMV is far easier to comp accurately since there are many more
    as-is comparable sales than recently-flipped comparable sales.

    Example from transcript: CMV $205k, list at CMV (kept cheap to sell
    fast - target ~3 weeks on market), 10% soft costs -> net $185k,
    assignment fee $15-25k -> seller offer range $145k-$160k.
    """
    net_after_soft_costs = current_market_value * (1 - soft_cost_pct)
    return NovationOfferRange(
        list_price=current_market_value,  # priced to be the cheapest comparable, sells fast
        net_after_soft_costs=net_after_soft_costs,
        offer_low=net_after_soft_costs - assignment_fee_high,
        offer_high=net_after_soft_costs - assignment_fee_low,
    )


DAYS_ON_MARKET_TARGET = 21  # ~3 weeks - price aggressively enough to hit this
SOFT_COST_BREAKDOWN_NOTE = (
    "10% soft-cost buffer typically breaks down as: ~5-6% agent commissions, "
    "~1.5-2% closing costs, remainder as buffer for inspection concessions "
    "or repair credits that come up during the retail buyer's financing "
    "process (FHA/VA inspections often surface items requiring a credit)."
)


# ---------------------------------------------------------------------------
# Timeline
# ---------------------------------------------------------------------------

NOVATION_TIMELINE_NOTE = (
    "Realistic full timeline: ~2-3 weeks to get a retail buyer under "
    "contract, plus 4-5 weeks for that buyer's lender to close (FHA loans "
    "in particular can drag to 45-60 days). Total: budget 60 business days "
    "start to finish. Never pitch novation to a seller who needs to be out "
    "sooner than that."
)


# ---------------------------------------------------------------------------
# Occupancy handling
# ---------------------------------------------------------------------------

OCCUPANCY_NOTES = {
    "vacant": "Strongly preferred - allows a lockbox for easy agent showings, no scheduling friction.",
    "owner_occupied": "Workable but slower - showings need scheduling, sometimes limited to weekend open houses, which can extend time-to-contract. Largest documented novation in the source material ($168k) was owner-occupied, so it's fully workable, just slower.",
    "tenant_occupied": "Same scheduling friction as owner-occupied; coordinate carefully with the tenant for access.",
}


# ---------------------------------------------------------------------------
# Legal requirements (paperwork - matches and confirms Alex's spec)
# ---------------------------------------------------------------------------

NOVATION_LEGAL_REQUIREMENTS = [
    "Same base purchase contract used for every deal (wholesale or novation) - "
    "the novation-specific language (MLS listing authorization) should already "
    "be in it, so no separate paperwork negotiation is needed upfront.",
    "Limited Power of Attorney - authorizes signing listing documents, offers, "
    "and addenda on the seller's behalf. This is the ONLY document that "
    "requires notarization.",
    "Some states require a state-specific POA rather than a generic one - "
    "confirm with the title company handling the transaction which is needed.",
    "A wholesale-only contract CANNOT be converted into a novation after the "
    "fact without having the seller re-sign new paperwork - the reverse "
    "(novation paperwork used as a straight wholesale) works fine, so sign "
    "every deal with the more flexible paperwork from the start.",
]

TITLE_COMPANY_WARNING = (
    "Using a title company unfamiliar with novation transactions is, per "
    "the source material, close to a guaranteed way to have the deal fall "
    "apart. This is one of the two most common failure points (the other "
    "is not educating the agents involved) - confirm the title company's "
    "novation experience before relying on this exit strategy. Critically, "
    "the title company handling a novation should be one YOUR side "
    "selects and has an existing relationship with - using a title "
    "company introduced by the retail buyer's side removes your ally in "
    "the transaction and is described in source material as an "
    "effectively guaranteed way to lose the deal."
)


# ---------------------------------------------------------------------------
# Fee mechanism - how the spread actually gets paid and disclosed
# ---------------------------------------------------------------------------

FEE_DISCLOSURE_MECHANISM = (
    "The spread is NOT paid as a separate 'assignment fee' (which wouldn't "
    "clear FHA/VA/conventional underwriting). Instead: once the retail "
    "buyer's offer is accepted, submit an invoice to the title company for "
    "the difference between the buyer's price and the seller's promised "
    "net, minus realtor commissions/closing costs/other promised expenses. "
    "This nets out to your profit and is paid as a legitimate line item on "
    "the settlement statement - commonly labeled something like 'marketing "
    "fee' or 'marketing / repair credit' rather than 'assignment fee'. This "
    "is the real, disclosed mechanism - it appears on the HUD/CD, "
    "consistent with Taylor's spread-invisibility rule only holding until "
    "final HUD/CD disclosure, at which point transparency is required."
)

LEGAL_INSTRUMENT_CORRECTION_NOTE = (
    "Some practitioners historically used an 'attorney-in-fact' "
    "designation for novation deals; per more recent source material, "
    "many title companies no longer accept this and require a proper "
    "notarized Limited Power of Attorney instead (covering signing "
    "listing documents and buyer offers specifically). Confirm current "
    "requirements with your specific title company rather than assuming "
    "attorney-in-fact is still sufficient."
)


# ---------------------------------------------------------------------------
# Condition spectrum - novation candidates are broader than "pristine only"
# ---------------------------------------------------------------------------

CONDITION_SPECTRUM_NOTE = (
    "While FHA-ready move-in-ready properties are the cleanest novation "
    "candidates, real case studies show a wider workable spectrum: "
    "'clean but dated' and 'dated but livable' properties routinely "
    "novate successfully as-is, sold to retail buyers using conventional "
    "loans (which have more flexible condition requirements than FHA/VA). "
    "Even rougher properties can work as a novation with a small amount of "
    "targeted light rehab (e.g. new flooring, paint, a cleanout) - "
    "particularly effective when paired with a JV partner who handles "
    "that light rehab work directly. The deciding factor is less "
    "'is this pristine' and more 'is there a realistic retail buyer "
    "pool and lending path at the price this needs to sell for.'"
)
