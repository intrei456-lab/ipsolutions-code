"""
Negotiation module — Keith Everett's 10-point negotiation framework, plus
the "Seller Within Price Range" 4-step strategy (Blue Trap prevention in
practice) and the "drive the price out" script.
"""

from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Comps presentation - NEVER hard numbers to a seller
# ---------------------------------------------------------------------------

def build_comps_range_script(low: float, high: float) -> str:
    """
    Keith's rule: never give exact comp numbers ('sold for $94,000'). Always
    a range ('selling anywhere from $90-100k'). Giving a hard number boxes
    you in and removes your room to negotiate.
    """
    return (
        f"I see properties in your area selling anywhere from "
        f"${low:,.0f} to ${high:,.0f} cash."
    )


# ---------------------------------------------------------------------------
# Reset seller's expectations
# ---------------------------------------------------------------------------

def build_reset_expectations_script(low_anchor: float, high_anchor: float, seller_asking: float) -> str:
    """
    Anchor a range BELOW the seller's ask before naming your real offer, so
    your actual number lands as a compromise rather than a lowball.
    Example from transcript: seller wants $90k, market comps suggest $100k,
    but you anchor at $60-70k to land your real offer of $80k in the middle.
    """
    return (
        f"I'm gonna be honest with you — looking at the as-is comps similar "
        f"to your property, I'm seeing properties sell anywhere from "
        f"${low_anchor:,.0f} to ${high_anchor:,.0f} cash. [Seller may react "
        f"negatively - that's expected, it resets their expectation] I'm not "
        f"saying I have to buy at that price, I just wanted to let you know "
        f"what's going on in the area."
    )


# ---------------------------------------------------------------------------
# Drive the price out of the seller
# ---------------------------------------------------------------------------

DRIVE_PRICE_SCRIPT = (
    "If I was to give you a million dollars cash, I'm sure you'd take it. "
    "But if I mentioned $10,000, we both know you'd hang up on me right "
    "now. You've got some number in the middle — it doesn't have to be a "
    "hard number, even a range works. I just want to see if I can make it "
    "work for you, and I don't want to waste your time."
)


# ---------------------------------------------------------------------------
# Closing cost boxing strategy
# ---------------------------------------------------------------------------

def build_closing_cost_box_script(higher_price: float, lower_price: float) -> str:
    """
    Give the seller two mathematically-equivalent-to-you choices so they
    feel in control while landing at your target number either way.
    Example: "I can do $85k but you pay closing costs, OR $82k and I cover
    closing." You already know from the pain-dig that they can't afford
    closing costs, so they'll pick the lower number every time.
    """
    return (
        f"Here's what we came up with: I can do ${higher_price:,.0f}, but "
        f"you'd need to cover the closing costs — or I can come down to "
        f"${lower_price:,.0f} and I'll take care of the closing costs. "
        f"Either way works on my end, just let me know what you'd prefer."
    )


# ---------------------------------------------------------------------------
# Create urgency via the finance department / partner
# ---------------------------------------------------------------------------

URGENCY_HOLD_SCRIPT = (
    "Before we go over the agreement, let me place you on a brief hold — I "
    "want to run this by my finance department and make sure I can secure "
    "the funds for you. In the meantime, what's a good email? I want to "
    "send over our Company Commitment so you know a bit more about us "
    "while I check."
)

URGENCY_CLOSE_SCRIPT = (
    "Great news — I was able to secure the funds for you. We're looking at "
    "a few other properties, but yours is the priority. We'd need to get "
    "the process started today to lock that in — did you get a chance to "
    "look over the Company Commitment I sent? If you can pull that email "
    "back up, I'll send the agreement and we'll go through it together."
)


# ---------------------------------------------------------------------------
# "Seller Within Your Price Range" - 4-step strategy
# (Blue Trap in concrete negotiation form: seller's ask is BELOW your MAO)
# ---------------------------------------------------------------------------

@dataclass
class PriceRangeStrategyStep:
    step_number: int
    name: str
    script: str
    note: str = ""


PRICE_RANGE_STRATEGY: list[PriceRangeStrategyStep] = [
    PriceRangeStrategyStep(
        step_number=1,
        name="Don't show excitement",
        script="[No verbal script - this is a discipline, not a line. Do NOT say 'yes I can do that' immediately.]",
        note="Never react with visible relief or enthusiasm when the seller's number is under your MAO, even on a home-run deal.",
    ),
    PriceRangeStrategyStep(
        step_number=2,
        name="Squeeze all the juice",
        script=(
            "That's gonna be a little tight for us, honestly. But remember, "
            "we're buying as-is, paying cash, covering closing costs, and we "
            "can close in 10 business days — considering all of that, what's "
            "the absolute best you could do?"
        ),
        note="Act like the number stings even if it's well under your ceiling.",
    ),
    PriceRangeStrategyStep(
        step_number=3,
        name="Create urgency via partner",
        script=(
            "I feel like we've got a deal here, we just need to find it. Let "
            "me speak to my partner in the finance department — I'm not "
            "promising he'll agree to that number, but if I can get him on "
            "the same page and secure the funds, are we ready to get started "
            "today? [Before hanging up:] What's a good email? I want to send "
            "over our Company Commitment while I check."
        ),
        note="This is a real hold, not just theater — but it also buys you room without committing.",
    ),
    PriceRangeStrategyStep(
        step_number=4,
        name="Close",
        script=(
            "Good news — it looks like we can do that number, and I secured "
            "the funds for you. Since we're looking at a few other "
            "properties, we'd need to get the process started today. Did you "
            "get a chance to look at the Company Commitment? Let's pull that "
            "email back up and go through the agreement together."
        ),
    ),
]
