"""
Four-personality adaptive framework — sourced from Keith Everett's
"Mastering the Art of Acquisitions 101" intro transcript. This is the
real source material the condensed agent spec was summarizing.

GREEN = analytical, RED = aggressive, BLUE = easy-going (the trap),
YELLOW = emotional.
"""

from dataclasses import dataclass
from enum import Enum


class Personality(str, Enum):
    GREEN = "GREEN"
    RED = "RED"
    BLUE = "BLUE"
    YELLOW = "YELLOW"


@dataclass
class PersonalityProfile:
    description: str
    coaching_note: str
    sample_script: str


PERSONALITY_PROFILES: dict[Personality, PersonalityProfile] = {
    Personality.GREEN: PersonalityProfile(
        description="Analytical. Wants to involve a lawyer or spouse, wants to read every detail of the paperwork.",
        coaching_note=(
            "Don't let requests to loop in a lawyer/spouse throw off your game "
            "— stay on top of it, keep following up, provide data and "
            "paperwork readiness rather than pressure."
        ),
        sample_script=(
            "I totally understand you want to go over this with [attorney/spouse], "
            "and I wouldn't want you to do it any other way. Let's make sure "
            "you have everything you need to feel confident."
        ),
    ),
    Personality.RED: PersonalityProfile(
        description="Aggressive. Comes in combative, tries to rush you to a number ('just make me an offer').",
        coaching_note="Do not match their energy. Stay calm, slow tonality, slow them down rather than reacting.",
        sample_script=(
            "I totally understand you're looking to receive a cash offer, but "
            "I plan to give you a large amount of money in a short period of "
            "time — tell me a bit more about the property so I can give you "
            "the absolute best offer."
        ),
    ),
    Personality.BLUE: PersonalityProfile(
        description="Easy-going. Seems like the simplest seller to close — this is the trap.",
        coaching_note=(
            "THE BLUE TRAP: if a Blue seller names a number and you agree to "
            "it too quickly ('yeah, I can do that'), it telegraphs that there "
            "was more room in the offer than they thought — and the seller "
            "will often re-anchor higher on the spot, assuming they left money "
            "on the table. Never accept an easy number instantly. Create "
            "urgency and squeeze before agreeing, even on a deal that's "
            "already great for you — e.g. 'that's gonna be tight... what's the "
            "absolute best you could do?' This is the single easiest tier to "
            "leave money on if you get lazy."
        ),
        sample_script=(
            "That's gonna be tight on our end... let me see what I can do. "
            "What's the absolute best you could do on this?"
        ),
    ),
    Personality.YELLOW: PersonalityProfile(
        description="Emotional. Needs more time and empathy, but yields the most pain points.",
        coaching_note=(
            "Spend more time here than with other types — this seller gives "
            "you the most pain to work with. When you present the offer, "
            "reference the property condition and company benefits, and use "
            "their own emotional language back to them. These sellers respond "
            "to feeling, not just logic."
        ),
        sample_script=(
            "I hear you — [reference their specific pain in their words]. "
            "Here's exactly how we can take that off your plate..."
        ),
    ),
}


def get_profile(personality: Personality) -> PersonalityProfile:
    return PERSONALITY_PROFILES[personality]
