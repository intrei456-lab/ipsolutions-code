"""
7-Pain-Dig sequence — verbatim from Keith Everett's "pain point questions"
transcript. Each question builds on the previous answer; goal is 4+ pains
uncovered before any price talk. All questions delivered in LOW tonality.
"""

from dataclasses import dataclass


@dataclass
class PainDigQuestion:
    order: int
    question: str
    purpose: str


PAIN_DIG_SEQUENCE: list[PainDigQuestion] = [
    PainDigQuestion(
        order=1,
        question="How can I help?",
        purpose="Open-ended — forces the seller to elaborate on their reason for selling rather than giving a one-line answer.",
    ),
    PainDigQuestion(
        order=2,
        question="How long has this been going on?",
        purpose="Establishes timeline of the pain. The longer it's been going on, the more motivated the seller typically is.",
    ),
    PainDigQuestion(
        order=3,
        question="Do you see the situation getting any better, or do you see it getting any worse?",
        purpose="Forces the seller to face reality out loud. Per Keith: sellers almost always say 'worse.'",
    ),
    PainDigQuestion(
        order=4,
        question=(
            "If you didn't have to rent it out anymore, fix anything up, and I could "
            "help you move on to bigger and better things — how would that make you feel?"
        ),
        purpose="Paints the after-picture and gets an emotional response. Keith calls this question 'golden.'",
    ),
    PainDigQuestion(
        order=5,
        question="Has this situation been keeping you up at night?",
        purpose="Deep emotional anchor — makes the seller feel seen and understood.",
    ),
    PainDigQuestion(
        order=6,
        question="Have you thought about fixing the property up or renting it back out?",
        purpose=(
            "You already know the answer is no — the point is to make the seller "
            "say it themselves, eliminating their own stated alternatives before "
            "you get to the offer."
        ),
    ),
    PainDigQuestion(
        order=7,
        question="How has this affected you and your family?",
        purpose="Pulls other people's pain into the conversation. Family is the highest emotional lever, per Keith.",
    ),
]

MINIMUM_PAINS_BEFORE_OFFER = 4


def get_question(order: int) -> PainDigQuestion:
    return PAIN_DIG_SEQUENCE[order - 1]


def all_questions_in_order() -> list[str]:
    return [q.question for q in PAIN_DIG_SEQUENCE]
