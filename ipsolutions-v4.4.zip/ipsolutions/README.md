# IPSolutions Agents — Chris, Alex, Taylor

Full rebuild of the Twin.so system: real databases, real conversation
logic sourced from Keith Everett's and Matt Beard's actual training
material, a real 36-node closing engine, and one always-on FastAPI +
scheduler process running all three agents. You own this outright —
cost is server hosting (~$5/mo) + Claude API usage + Gmail (free), not
a $200+/mo subscription.

## Current priority (per Thomas): get Chris live for direct-seller + Mat Beard agent outreach

Scraping (the automated lead-sourcing side) is intentionally
deprioritized for now. The conversation engine, offer math, follow-up
logic, and agent outreach — the parts that actually run a real
conversation once a lead exists — are done and tested. What's missing
to go fully live is: (1) the hosting step below, (2) Gmail credentials
so agents can actually send, (3) a way to get leads INTO the system
(manual entry works today; scraping is a later add-on).

## What's actually working right now

**Chris (Acquisitions):**
- Full DB schema, ZIP-gated intake (tested against the real `HIGH` vs
  `HIGH_MOTIVATED` bug from the Twin build log)
- Complete conversation engine: DM gate, 7-pain-dig, personality/Blue
  Trap, 20 objections, negotiation, price-range strategy, no-deal-lost,
  seller hold-back, structured price reduction, novation mechanics
  (+ an honest alternative to the manufactured-scarcity pitch)
- Full 22-step Hustle Seller call script, real follow-up cadence
- Mat Beard agent outreach: 3-tier system, 3-6hr Tier-1 SLA, off-market
  filter math, 16 real outreach templates with anti-spam rotation
- Real templates verified against actual sent output: 12-section
  pre-call brief, daily KPI email
- LLM wiring (`brief_generator.py`) to draft the narrative sections
  live, grounded in all of the above rather than a generic prompt
- One scout module scaffolded (`tax_delinquent_md.py`) — pipeline is
  real, the actual scrape is stubbed (see Scraping section below)

**Alex (Dispositions):**
- Full DB schema, A/B/C dispo tiering (exact thresholds), 5-Day Dispo
  engine with real TTB mechanics, FP verification + wholesaler
  red-flag detection, proactive FP hunting (Mode 1), JV comp-verification
  gate, Novation Path 2 (profitability + legal-clearance gates)
- Real seed data: 45 ZIPs, real title company directory, 27 real
  financial partners (Rachael Cohen's actual relationship history
  preserved, not just a status flag)
- CEO alerts (with 24h dedup), KPI rollup, Mode 3 post-close deepening
- LLM outreach drafting (`outreach_generator.py`), verified that
  contract_price/assignment_fee never enter the LLM's context at all

**Taylor (Transaction Coordinator):**
- Full DB schema (14 tables), complete 36-node closing engine — every
  node has real logic, tested including edge cases (LLC-requires-EIN,
  HOA-conditional, mail-away-FL/NC-only notary, 5-day deed breach)
- Pending Follow-Ups sweep, Closing Day sweep, stall detection, KPI
  rollup, Node 36 archive + post-close signal back to Alex

**System-wide:**
- `main.py` runs all three agents' databases and scheduled jobs in one
  process — tested end-to-end, not just per-agent
- `shared/email.py` — real Gmail sending (see setup below)
- `shared/llm_client.py` — every LLM call runs through automatic
  terminology + spread-invisibility checks before returning

## What's NOT done yet

- **Scraping** (deprioritized per current priority) — 11 of 12+ scout
  modules, and Alex's proactive FP hunt sources (PropWire/Craigslist/
  BiggerPockets/Investor-Base-style tools), are stubbed pipeline-only.
  See "Scraping options" below when this becomes the priority again.
- Webhook handlers (FB Lead Ads, Gmail inbound) — not built yet, so
  leads need manual entry via the API for now
- SMS sending — no Twilio/REsimpli-SMS integration yet (A2P 10DLC
  compliance caps are already encoded in `shared/config.py`, just no
  send function wired up)
- DealRun.ai integration — Thomas's chosen tool for buyer presentation/
  5-day dispo; no API integration exists since I don't have DealRun's
  API docs yet

## Local setup

```bash
cd ipsolutions
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# fill in .env: ANTHROPIC_API_KEY, GMAIL_SENDER_ADDRESS, GMAIL_APP_PASSWORD

uvicorn main:app --reload --port 8000
```

On startup this initializes all 3 agents' databases and seeds real data
(45 ZIPs, title companies, 27 financial partners, the 36-node template).

## Gmail setup (free, ~5 minutes, required for any agent to actually send anything)

1. On the sending Gmail account (e.g. `ipsolutionsmd@gmail.com`), turn on
   2-Step Verification if it isn't already (Google Account -> Security)
2. Google Account -> Security -> 2-Step Verification -> App Passwords ->
   generate one for "Mail"
3. Put the 16-character app password in `.env` as `GMAIL_APP_PASSWORD`
   (this is NOT your real Gmail password — it's a separate, revocable
   credential scoped just to this)
4. Put the sending address in `.env` as `GMAIL_SENDER_ADDRESS`

Gmail's own sending limits apply (~500/day on a regular account). Fine
for KPI reports, briefs, alerts, and outreach at current scale — a
dedicated provider (Postmark/SendGrid) would only become necessary at
much higher volume.

## Test it's alive

```bash
curl http://localhost:8000/health

# Chris
curl -X POST http://localhost:8000/chris/scouts/tax_delinquent_md/run
curl http://localhost:8000/chris/leads

# Alex
curl -X POST http://localhost:8000/alex/kpi/run
curl http://localhost:8000/alex/deals
curl http://localhost:8000/alex/financial_partners

# Taylor
curl -X POST http://localhost:8000/taylor/sweeps/pending_followups/run
curl http://localhost:8000/taylor/closings
```

## Deploying to a VPS — this is the piece that replaces Twin's 24/7 execution

This is the actual "always-on" part — the code needs to live somewhere
that runs continuously, since I (Claude) only exist within a chat
conversation and can't run anything myself in the background.

**Recommended: Hetzner** (~€4-5/mo, cheaper than DigitalOcean for
similar specs):

1. Create a Hetzner account, spin up a small VPS (CX22 or similar,
   Ubuntu 22.04+)
2. SSH in, install Python 3.11+ and git:
   ```bash
   sudo apt update && sudo apt install -y python3.11 python3.11-venv git
   ```
3. Copy this project to the server (e.g. `/opt/ipsolutions`) — `scp` the
   folder, or push to a private git repo and clone it there
4. Repeat the local setup steps above (venv, pip install, `.env` with
   real credentials)
5. Create a systemd service so it runs forever and restarts on crash or
   reboot automatically:

```ini
# /etc/systemd/system/ipsolutions.service
[Unit]
Description=IPSolutions Agents
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/ipsolutions
Environment="PATH=/opt/ipsolutions/venv/bin"
ExecStart=/opt/ipsolutions/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable ipsolutions
sudo systemctl start ipsolutions
sudo systemctl status ipsolutions   # confirm it's running
```

Once this is live, the scheduler inside `main.py` fires Chris's 7am
scout pass, Alex's 8pm KPI rollup, and Taylor's 3pm/5pm sweeps
automatically, every day, with nobody needing to be in a chat with me to
keep it running. That's the actual replacement for what Twin was doing
24/7.

(Optional, do later) put nginx + a real domain + TLS in front of it once
you want an external webhook (FB Lead Ads) to reach it.

## Scraping options (when this becomes the priority again)

Per Thomas: this is intentionally NOT the current focus. Notes for
later:

- **FSBO (Zillow/Redfin)**: almost certainly needs **Apify** — has
  ready-made scrapers for this, pay-per-run. This is what the original
  Twin build log said it was actually using.
- **Government portals** (tax delinquent, code violations): can be
  built as direct scrapes, no paid service — but MD/FL/NC portals all
  differ, and FL's are JS-heavy/anti-bot (the real system fell back to
  aggregators like RealtyTrac there).
- **Alex's buyer/checkbook hunting**: per Thomas, **Investor Base** is
  the broad-audience checkbook-pulling tool (radius search around a
  property/ZIP, bulk export) — separate from **DealRun**, which Thomas
  is using for presenting deals to buyers and running the 5-Day Dispo
  process specifically, not for sourcing new buyer leads.

## Next steps (in order, per current priority)

1. Get Gmail credentials set up, deploy to Hetzner — Chris's
   conversation engine + Mat Beard outreach becomes genuinely live
2. Manually seed a handful of real leads via the API to test the full
   conversation/brief flow end-to-end with real data
3. Wire SMS sending (REsimpli API once available, or Twilio direct)
4. Come back to scraping once the conversation/outreach side is proven
   live and working
