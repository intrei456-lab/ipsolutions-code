"""
A/B/C Dispo Tiering — from Alex's spec, with exact thresholds confirmed
against the real Twin build log (not just the abstract spec description):

  A-tier (Verified Closer): Rep >= 75 + 3+ deals closed, OR REPEAT relationship
  B-tier (Vetted + POF):    Rep >= 50 + 1+ deal, OR WARM relationship, OR VIP status
  C-tier (Unvetted):        everyone else

Critical rule: A-tier offer beats a higher C-tier offer. If an A-tier FP
offers $95k and a C-tier FP offers $100k, take the A-tier - the spread
difference is insurance against a blown deal. Exception: if C-tier is
15%+ higher than best A-tier AND can provide same-day POF, escalate to
Thomas for a decision rather than auto-deciding.
"""

from dataclasses import dataclass


@dataclass
class FinancialPartner:
    """Minimal shape needed for tiering - real usage pulls these fields
    from the financial_partners table."""
    reputation_score: int
    total_deals_closed: int
    relationship_stage: str      # COLD/WARM/ACTIVE/REPEAT
    vip_tier: str                # VIP/WARM/COLD (buy-box completeness, separate axis from dispo tier)
    verification_status: str = "UNVERIFIED"
    pof_type: str | None = None


def compute_dispo_tier(fp: FinancialPartner) -> str:
    """Returns 'A', 'B', or 'C'."""
    is_a_tier = (
        (fp.reputation_score >= 75 and fp.total_deals_closed >= 3)
        or fp.relationship_stage == "REPEAT"
    )
    if is_a_tier:
        return "A"

    is_b_tier = (
        (fp.reputation_score >= 50 and fp.total_deals_closed >= 1)
        or fp.relationship_stage == "WARM"
        or fp.vip_tier == "VIP"
    )
    if is_b_tier:
        return "B"

    return "C"


# ---------------------------------------------------------------------------
# Offer ranking - A beats higher C, escalation exception
# ---------------------------------------------------------------------------

@dataclass
class TieredOffer:
    fp_id: int
    tier: str          # A/B/C
    offer_amount: float
    same_day_pof: bool = False


def rank_offers(offers: list[TieredOffer]) -> tuple[TieredOffer, bool]:
    """
    Returns (recommended_offer, needs_thomas_escalation).

    Rules:
      - A beats B and C at ANY price (insurance against blown deals from
        unverified/unproven buyers).
      - B beats C at any price.
      - Within the same tier, higher offer wins.
      - EXCEPTION: if the best C-tier offer is 15%+ higher than the best
        A-tier offer AND that C-tier FP can provide same-day proof of
        funds, escalate to Thomas rather than auto-selecting either.
    """
    if not offers:
        raise ValueError("No offers to rank")

    by_tier = {"A": [], "B": [], "C": []}
    for o in offers:
        by_tier[o.tier].append(o)

    best_a = max(by_tier["A"], key=lambda o: o.offer_amount, default=None)
    best_b = max(by_tier["B"], key=lambda o: o.offer_amount, default=None)
    best_c = max(by_tier["C"], key=lambda o: o.offer_amount, default=None)

    if best_a:
        if best_c and best_c.offer_amount >= best_a.offer_amount * 1.15 and best_c.same_day_pof:
            return best_a, True  # flag for Thomas, but still recommend A-tier by default
        return best_a, False

    if best_b:
        return best_b, False

    return best_c, False
