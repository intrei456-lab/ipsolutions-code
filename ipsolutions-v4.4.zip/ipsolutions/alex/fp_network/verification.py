"""
FP verification — mandatory before VIP/WARM promotion or any deal-specific
pitch. Also covers wholesaler red-flag auto-detection, which runs
continuously across all FP interactions (not just during formal
verification).
"""

from dataclasses import dataclass, field
from enum import Enum


class VerificationStatus(str, Enum):
    UNVERIFIED = "UNVERIFIED"
    VERIFICATION_PENDING = "VERIFICATION_PENDING"
    VERIFIED_BUYER = "VERIFIED_BUYER"
    SUSPECTED_WHOLESALER = "SUSPECTED_WHOLESALER"
    CONFIRMED_WHOLESALER = "CONFIRMED_WHOLESALER"


class POFType(str, Enum):
    BANK_STATEMENT = "BANK_STATEMENT"
    LOC_LETTER = "LOC_LETTER"
    HUD_STATEMENT = "HUD_STATEMENT"
    HM_PREAPPROVAL = "HM_PREAPPROVAL"


# ---------------------------------------------------------------------------
# Wholesaler red flags (auto-detect during ANY FP interaction)
# ---------------------------------------------------------------------------

RED_FLAG_CODES = {
    "ASK_ASSIGNABLE": "Asks 'can I assign this?' on first contact - real end-buyers don't ask this",
    "ASK_SPREAD": "Asks about the assignment fee/spread - real buyers care about property price, not your margin",
    "LAYER_JV": "Wants to bring a partner/JV before even seeing the deal - layering another assignment",
    "NO_POF": "Cannot provide proof of funds when requested - no actual purchasing capacity",
    "WBH_NO_TRACK": "Has a 'we buy houses' brand but no verifiable closed transactions in our markets",
    "LONG_INSPECTION": "Requests 30+ day inspection period - likely buying time to find their own buyer",
    "GENERIC_LLC": "Entity name is a generic wholesaling LLC with no track record",
    "FLAGGED_DAISY": "Flagged by other wholesalers/FPs in the network as a daisy-chainer",
    "OWN_TITLE": "Insists on their own title company instead of ours - possible double-close concealment",
    "ADDRESS_SHOPPING": "Asks for the property address before committing any EMD or showing POF",
}

RED_FLAG_TRIGGER_PHRASES = {
    "ASK_ASSIGNABLE": ["can i assign this", "is this assignable", "can i wholesale this"],
    "ASK_SPREAD": ["what's your fee", "what's your spread", "what's your margin", "how much are you making", "what is your spread", "what is your fee"],
    "LAYER_JV": ["bring a partner", "want to jv this", "before i even see it"],
    "LONG_INSPECTION": ["30 day inspection", "need 30 days to inspect", "45 day inspection"],
    "OWN_TITLE": ["use my own title", "my title company", "we use our own closing attorney"],
    "ADDRESS_SHOPPING": ["what's the address", "send me the address first"],
}


@dataclass
class RedFlagCheckResult:
    flags_detected: list[str] = field(default_factory=list)
    should_flip_to_suspected: bool = False


def check_for_red_flags(message_text: str, current_status: str = "UNVERIFIED") -> RedFlagCheckResult:
    """
    Scan an FP's message for red-flag trigger phrases. Codes without a
    reliable text signal (NO_POF, WBH_NO_TRACK, GENERIC_LLC, FLAGGED_DAISY)
    are determined by separate verification steps, not text matching -
    they're documented in RED_FLAG_CODES for completeness but not checked
    here.
    """
    detected = []
    text_lower = message_text.lower()
    for code, phrases in RED_FLAG_TRIGGER_PHRASES.items():
        if any(p in text_lower for p in phrases):
            detected.append(code)

    should_flip = bool(detected) and current_status in ("UNVERIFIED", "VERIFICATION_PENDING")
    return RedFlagCheckResult(flags_detected=detected, should_flip_to_suspected=should_flip)


# ---------------------------------------------------------------------------
# Verification steps
# ---------------------------------------------------------------------------

VERIFICATION_STEPS = """
1. Proof of funds check - one of:
   - Bank statement showing liquid funds >= stated buy_box_price_max -> BANK_STATEMENT
   - Line of credit letter from bank/hard money lender -> LOC_LETTER
   - Prior HUD/settlement statement showing a cash deal closed in last 6mo -> HUD_STATEMENT
   - Hard money pre-approval letter with lender name -> HM_PREAPPROVAL
   - Can't provide ANY -> flag NO_POF, stays COLD

2. Track record check - "What's the last deal you closed in [ZIPs]?"
   - Specific address + closing date -> good signal
   - Vague ("I do a lot of deals") -> suspect signal
   - Cross-reference via PropWire if available: did their entity appear
     as grantee on a recent deed recording?

3. Entity check - if FP provides an LLC name:
   - Cross-reference OpenCorporates/Sunbiz(FL)/MD SDAT/NC SOS - is it
     active? Formation date < 6 months ago = suspect.
   - PropWire: does the LLC show up as grantee on recent deed recordings?

4. Direct ask - "Are you the end buyer, or are you wholesaling this to
   someone else?"
   - End buyer + passes POF + track record -> VERIFIED_BUYER
   - Admits to wholesaling -> CONFIRMED_WHOLESALER, redirect to JV intake
     (they can bring deals TO us, but don't get our deals)
   - Claims end buyer but FAILS POF -> SUSPECTED_WHOLESALER, flag NO_POF
"""


def determine_verification_outcome(
    is_end_buyer_claim: bool,
    has_valid_pof: bool,
    has_specific_track_record: bool,
) -> str:
    """Applies step 4's decision logic given the results of steps 1-3."""
    if not is_end_buyer_claim:
        return VerificationStatus.CONFIRMED_WHOLESALER
    if has_valid_pof and has_specific_track_record:
        return VerificationStatus.VERIFIED_BUYER
    if not has_valid_pof:
        return VerificationStatus.SUSPECTED_WHOLESALER
    return VerificationStatus.VERIFICATION_PENDING
