"""
Alex's KPI rollup — computed at the end of every run, written to
dispo_kpi. Pure SQL aggregation, no LLM needed.
"""

from datetime import date

from alex.db.db import get_connection


def compute_daily_kpi(kpi_date: str | None = None) -> dict:
    kpi_date = kpi_date or date.today().isoformat()
    conn = get_connection()
    try:
        active_own = conn.execute(
            "SELECT COUNT(*) as c FROM deals WHERE source_track='OWN' AND dispo_status NOT IN ('CLOSED','DEAD')"
        ).fetchone()["c"]
        active_jv = conn.execute(
            "SELECT COUNT(*) as c FROM deals WHERE source_track='JV' AND dispo_status NOT IN ('CLOSED','DEAD')"
        ).fetchone()["c"]

        avg_dom_row = conn.execute(
            """
            SELECT AVG(julianday('now') - julianday(dispo_clock_started_at)) as avg_dom
            FROM deals WHERE dispo_status NOT IN ('CLOSED','DEAD') AND dispo_clock_started_at IS NOT NULL
            """
        ).fetchone()
        avg_dom = avg_dom_row["avg_dom"] or 0

        fp_touches_today = conn.execute(
            "SELECT COUNT(*) as c FROM fp_outreach WHERE date(sent_at) = ?", (kpi_date,)
        ).fetchone()["c"]

        deals_touched_today = conn.execute(
            "SELECT COUNT(DISTINCT deal_id) as c FROM fp_outreach WHERE date(sent_at) = ?", (kpi_date,)
        ).fetchone()["c"]

        assignments_sent_today = conn.execute(
            "SELECT COUNT(*) as c FROM deals WHERE date(assignment_sent_at) = ?", (kpi_date,)
        ).fetchone()["c"]

        assignments_signed_today = conn.execute(
            "SELECT COUNT(*) as c FROM assignments_signed WHERE date(signed_at) = ?", (kpi_date,)
        ).fetchone()["c"]

        fee_row = conn.execute(
            "SELECT AVG(assignment_fee) as avg_fee, SUM(assignment_fee) as total_fee FROM assignments_signed"
        ).fetchone()

        ttb_row = conn.execute(
            "SELECT AVG(ttb_hours) as avg_ttb, SUM(CASE WHEN ttb_target_met=0 AND ttb_hours IS NOT NULL THEN 1 ELSE 0 END) as breaches FROM deals WHERE ttb_hours IS NOT NULL"
        ).fetchone()

        tier_counts = conn.execute(
            "SELECT dispo_tier, COUNT(*) as c FROM financial_partners WHERE is_test_data=0 GROUP BY dispo_tier"
        ).fetchall()
        tier_map = {row["dispo_tier"]: row["c"] for row in tier_counts}

        alerts_today = conn.execute(
            "SELECT COUNT(*) as c FROM ceo_alerts WHERE date(fired_at) = ?", (kpi_date,)
        ).fetchone()["c"]

        kpi = {
            "kpi_date": kpi_date,
            "active_deals_own": active_own,
            "active_deals_jv": active_jv,
            "avg_days_on_market": round(avg_dom, 1),
            "fp_touches_today": fp_touches_today,
            "deals_touched_today": deals_touched_today,
            "assignments_sent_today": assignments_sent_today,
            "assignments_signed_today": assignments_signed_today,
            "avg_assignment_fee": fee_row["avg_fee"] or 0,
            "total_assignment_fee": fee_row["total_fee"] or 0,
            "avg_ttb_hours": ttb_row["avg_ttb"] or 0,
            "ttb_breaches": ttb_row["breaches"] or 0,
            "tier_a_count": tier_map.get("A", 0),
            "tier_b_count": tier_map.get("B", 0),
            "tier_c_count": tier_map.get("C", 0),
            "alerts_fired_today": alerts_today,
        }

        conn.execute(
            """
            INSERT OR REPLACE INTO dispo_kpi (
                kpi_date, active_deals_own, active_deals_jv, avg_days_on_market,
                fp_touches_today, deals_touched_today, assignments_sent_today,
                assignments_signed_today, avg_assignment_fee, total_assignment_fee,
                avg_ttb_hours, ttb_breaches, tier_a_count, tier_b_count, tier_c_count,
                alerts_fired_today
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            tuple(kpi.values()),
        )
        conn.commit()
        return kpi
    finally:
        conn.close()
