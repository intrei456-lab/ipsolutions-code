"""
5-Day Dispo engine — mandatory for every WHOLESALE_ASSIGNMENT/SUBTO deal.
Combines Alex's original spec with the real mechanics confirmed in Matt
Beard's "checkbooks" transcripts (same underlying model - TTB, A/B/C
blast order, walkthrough, magic question, FOMO texts).

TTB (Time to Blast) is THE headline metric: per source material, deals
with TTB under 12 hours sell at a dramatically higher rate (Matt Beard's
own numbers: two community members went from ~30% of contracted deals
selling to ~70% just by tracking and prioritizing this one metric).
"""

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

TTB_TARGET_HOURS = 12
TTB_CRITICAL_HOURS = 24

# Real stat from source material - useful as a headline KPI/motivation
# reference, not something to compute from, just to display/cite.
TTB_IMPACT_NOTE = (
    "Sub-12-hour Time to Blast correlates with dramatically higher sell-"
    "through rates - two tracked community members went from ~30% of "
    "contracted deals selling to ~70% purely by making TTB a tracked, "
    "prioritized metric for one month."
)

PHOTOS_SLA_HOURS = 24


def compute_ttb_hours(dispo_clock_started_at: datetime, first_blast_at: datetime) -> float:
    return (first_blast_at - dispo_clock_started_at).total_seconds() / 3600


def ttb_status(ttb_hours: float | None) -> str:
    if ttb_hours is None:
        return "PENDING"
    if ttb_hours <= TTB_TARGET_HOURS:
        return "TARGET_MET"
    if ttb_hours <= TTB_CRITICAL_HOURS:
        return "WARN"
    return "CRITICAL"


# ---------------------------------------------------------------------------
# Day 0-5 state machine
# ---------------------------------------------------------------------------

@dataclass
class DispoDayAction:
    day: int
    name: str
    required_actions: list[str]
    blocking_condition: str | None = None


DISPO_DAY_PLAN: list[DispoDayAction] = [
    DispoDayAction(
        day=0,
        name="Package the deal",
        required_actions=[
            "Photos requested within 24h of Chris handoff (mandatory, no exceptions)",
            "Compute fp_facing_price = contract_price + assignment_fee_target (spread never shown)",
            "Rank FPs by dispo tier (A/B/C) for this deal's ZIP/price/condition",
            "Draft all blast messages, personalized per FP, ready to fire the instant photos arrive",
            "If fewer than 3 A-tier FPs match, trigger a deal-specific FP hunt in parallel",
        ],
        blocking_condition="Day 1 blast is BLOCKED until photos are delivered AND drafts are ready.",
    ),
    DispoDayAction(
        day=1,
        name="The blast (TTB clock stops here)",
        required_actions=[
            "A-tier FPs get the deal FIRST, the moment photos arrive - personal 1:1 emails, 'bringing this to you first'",
            "4 hours after A-tier blast: B-tier FPs - 'got a deal that fits your buy box'",
            "8 hours after A-tier blast (or end of day): C-tier FPs - broader outreach",
            "Any A-tier FP with no response within 2 hours of email -> queue a call for Thomas",
        ],
        blocking_condition="Do not blast to C-tier before A-tier has had its window.",
    ),
    DispoDayAction(
        day=2,
        name="Deal-specific prospecting",
        required_actions=[
            "Hunt beyond the existing FP network for THIS specific deal (cash-purchaser search in a tight radius, last 6 months)",
            "Scrape/identify nearby active flip projects - their investors are active buyers in this ZIP right now",
            "Follow up on Day 1 non-responders: A-tier -> Thomas calls (mandatory); B-tier -> follow-up email; C-tier -> no follow-up yet",
        ],
    ),
    DispoDayAction(
        day=3,
        name="Reminders + confirmations",
        required_actions=[
            "Remind interested-but-uncommitted FPs, with urgency ('getting some interest, want to make sure you get a shot')",
            "Send additional info immediately to anyone who requested it",
            "Schedule Day 4 walkthrough for anyone who wants to view - ONE time window only",
            "If no offers by end of Day 3, prepare a price-adjustment recommendation",
        ],
    ),
    DispoDayAction(
        day=4,
        name="Walkthrough (ONE time window)",
        required_actions=[
            "All interested FPs come during the SAME 2-hour window - never individual private showings",
            "Escort every FP - never let an FP talk to the seller unsupervised",
            "Competition among simultaneous viewers drives better offers (creates real FOMO, not simulated)",
            "Collect offers at the walkthrough or within 24 hours",
        ],
        blocking_condition="If no walkthrough interest, consider price adjustment or C-tier expansion before extending timeline.",
    ),
    DispoDayAction(
        day=5,
        name="Decision day",
        required_actions=[
            "Collect final offers by end of day - no extensions without Thomas's approval",
            "Ask the magic question on EVERY offer: 'Is that really the best you can do?' (Historically bumps offers $2-5k, costs nothing)",
            "Rank offers using A/B/C priority (see fp_network/tiering.py)",
            "Accept best offer, route to Assignment signing",
            "Send FOMO text to all other interested FPs immediately after acceptance - keeps them engaged, collects updated buy-box data",
        ],
        blocking_condition="If no acceptable offers, options are: extend with price reduction, renegotiate with seller via Chris, or kill the deal - Thomas decides.",
    ),
]

MAGIC_QUESTION = "Is that really the best you can do?"

FOMO_TEXT_TEMPLATE = (
    "Hey {fp_name}, {address} is under contract. I'll keep you top of "
    "mind for the next one — anything specific you're looking for right "
    "now?"
)


def get_day_plan(day: int) -> DispoDayAction:
    return next(d for d in DISPO_DAY_PLAN if d.day == day)


def blast_time_for_tier(tier: str, first_blast_at: datetime) -> datetime:
    """
    A-tier fires immediately at first_blast_at. B-tier fires 4 hours
    later. C-tier fires 8 hours later (or end of Day 1).
    """
    offsets = {"A": 0, "B": 4, "C": 8}
    return first_blast_at + timedelta(hours=offsets.get(tier, 8))
