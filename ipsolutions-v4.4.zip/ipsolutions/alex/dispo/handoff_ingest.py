"""
Step 1: Pull new handoffs from Chris. Uses the shared cross-agent read
helper to query Chris's database directly (same-box SQLite file access,
no network hop needed).
"""

from dataclasses import dataclass

from alex.db.db import get_connection as get_alex_connection
from shared.config import TITLE_COMPANY_DIRECTORY, emd_tier_for_close_window


@dataclass
class HandoffIngestResult:
    deal_id: int | None
    accepted: bool
    reason: str | None = None


def compute_fp_type_recommended(fp_facing_price: float, days_to_close: int) -> str:
    """COLD_CASH if fp_facing_price < $100k and closing in <=14 days, else PRIVATE_HARD_MONEY."""
    if fp_facing_price < 100000 and days_to_close <= 14:
        return "COLD_CASH"
    return "PRIVATE_HARD_MONEY"


def get_title_company(state: str) -> str | None:
    """Looks up the primary title company for a state. Returns None for NC
    (TBD) - caller should fire a title-company-missing alert in that case."""
    return TITLE_COMPANY_DIRECTORY.get(state, {}).get("primary")


def ingest_handoff(
    lead_id: int,
    address: str,
    city: str,
    state: str,
    zip_code: str,
    contract_price: float,
    assignment_fee_target: float,
    exit_strategy: str = "WHOLESALE_ASSIGNMENT",
    risk_tier: str = "STANDARD",
    days_to_close: int = 14,
    double_close_recommended: bool = False,
) -> HandoffIngestResult:
    """
    Inserts a new deals row from a Chris handoff. Computes fp_facing_price,
    fp_type_recommended, and title_company; sets closing_method based on
    the double-close flag Chris may have already computed.
    """
    fp_facing_price = contract_price + assignment_fee_target
    fp_type_recommended = compute_fp_type_recommended(fp_facing_price, days_to_close)
    title_company = get_title_company(state)
    closing_method = "DOUBLE_CLOSE" if double_close_recommended else "STANDARD_ASSIGNMENT"

    conn = get_alex_connection()
    try:
        cur = conn.execute(
            """
            INSERT INTO deals (
                lead_id, source_track, dispo_status, exit_strategy, risk_tier,
                closing_method, contract_price, assignment_fee_target,
                fp_facing_price, fp_type_recommended, title_company,
                dispo_clock_started_at
            ) VALUES (?, 'OWN', 'NEW', ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
            """,
            (
                lead_id, exit_strategy, risk_tier, closing_method,
                contract_price, assignment_fee_target, fp_facing_price,
                fp_type_recommended, title_company,
            ),
        )
        deal_id = cur.lastrowid

        conn.execute(
            "INSERT INTO handoffs (deal_id, direction, to_team_member, status) "
            "VALUES (?, 'INBOUND_FROM_CHRIS', 'ALEX', 'ACKNOWLEDGED')",
            (deal_id,),
        )

        if title_company is None and state == "NC":
            conn.execute(
                """
                INSERT INTO ceo_alerts (alert_type, severity, deal_id, message)
                VALUES ('NC_TITLE_COMPANY_MISSING', 'HIGH', ?,
                        'NC deal arrived with no title company designated - Thomas must assign one before proceeding.')
                """,
                (deal_id,),
            )

        conn.commit()
        return HandoffIngestResult(deal_id=deal_id, accepted=True)
    finally:
        conn.close()


def exit_strategy_router(exit_strategy: str) -> str:
    """
    Routes the deal to the correct disposal path. HARD rule: never send a
    NOVATION deal to the FP network, never send WHOLESALE_ASSIGNMENT to MLS.
    """
    routing = {
        "WHOLESALE_ASSIGNMENT": "FP_NETWORK",
        "SUBTO": "FP_NETWORK",  # same network, FP must accept sub-to terms
        "NOVATION": "MLS_LISTING",
        "JUNIOR_BROKERAGE": "MLS_LISTING",
    }
    return routing.get(exit_strategy, "FP_NETWORK")
