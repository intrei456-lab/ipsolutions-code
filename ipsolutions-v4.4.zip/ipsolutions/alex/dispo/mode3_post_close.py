"""
Mode 3: Post-Deal Relationship Deepen — triggered when Taylor signals a
deal has closed (deed recorded). Updates the FP's lifecycle stage,
collects fresh buy-box data, and asks for a referral.
"""

from alex.db.db import get_connection


POST_CLOSE_TEMPLATE = (
    "Hey {fp_name}, wanted to say thanks again for closing on {address} - "
    "always a pleasure working with you. Quick question while I've got "
    "you: any updates to your buy box lately (ZIPs, price range, "
    "condition preference)? And who else in your network does deals in "
    "[area]? Always looking to connect with more good people."
)


def handle_post_close_signal(fp_id: int, deal_address: str) -> dict:
    """
    Called when taylor_handoffs writes a POST_CLOSE_SIGNAL row. Updates
    the FP's total_deals_closed, last_deal_closed_at, and promotes
    relationship_stage to REPEAT (2+ deals) or ACTIVE (1st deal).
    """
    conn = get_connection()
    try:
        fp = conn.execute(
            "SELECT total_deals_closed, relationship_stage FROM financial_partners WHERE fp_id = ?",
            (fp_id,),
        ).fetchone()
        if fp is None:
            return {"success": False, "reason": "fp_not_found"}

        new_total = fp["total_deals_closed"] + 1
        new_stage = "REPEAT" if new_total >= 2 else "ACTIVE"

        conn.execute(
            """
            UPDATE financial_partners
            SET total_deals_closed = ?, last_deal_closed_at = datetime('now'),
                relationship_stage = ?
            WHERE fp_id = ?
            """,
            (new_total, new_stage, fp_id),
        )

        conn.execute(
            """
            INSERT INTO fp_outreach (fp_id, outreach_type, channel, message)
            VALUES (?, 'POST_CLOSE_DEEPEN', 'EMAIL', ?)
            """,
            (fp_id, POST_CLOSE_TEMPLATE.format(fp_name="", address=deal_address)),
        )

        conn.commit()
        return {"success": True, "new_total_deals_closed": new_total, "new_relationship_stage": new_stage}
    finally:
        conn.close()


def handle_referral(referring_fp_id: int, referred_entity_name: str) -> int:
    """When an FP provides a referral name, insert a new COLD financial
    partner row tagged with the referral source."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """
            INSERT INTO financial_partners (entity_name, source, referral_source_fp_id, relationship_stage, vip_tier)
            VALUES (?, 'REFERRAL', ?, 'COLD', 'COLD')
            """,
            (referred_entity_name, referring_fp_id),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()
