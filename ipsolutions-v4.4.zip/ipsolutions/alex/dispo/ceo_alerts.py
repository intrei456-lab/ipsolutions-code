"""
Alex's CEO alerts — fires and logs escalations to Thomas. Includes the
dedup rule (don't re-fire the same alert_type for the same deal within 24h
if still unresolved).
"""

from alex.db.db import get_connection

ALERT_THRESHOLDS = {
    "DEAL_14_DAYS": {"severity": "WARN", "dom_trigger": 14},
    "DEAL_21_DAYS_FIRESALE": {"severity": "CRITICAL", "dom_trigger": 21},
    "JV_PARTNER_DOWNGRADE_2X": {"severity": "WARN"},
    "FP_NETWORK_THIN": {"severity": "INFO"},
    "FP_NETWORK_THIN_FOR_ZIP": {"severity": "INFO"},
    "TTB_BREACH": {"severity": "WARN", "hours_trigger": 12},
    "TTB_CRITICAL": {"severity": "CRITICAL", "hours_trigger": 24},
    "NOVATION_PROFIT_BELOW_MIN": {"severity": "WARN"},
    "NOVATION_LEGAL_INCOMPLETE": {"severity": "CRITICAL"},
    "PROTECT_SPREAD_ACTIVATED": {"severity": "WARN"},
    "SYSTEM": {"severity": "CRITICAL"},
}


def already_fired_recently(deal_id: int, alert_type: str) -> bool:
    """Don't duplicate-send the same (deal_id, alert_type) if it fired in
    the last 24h and is still unresolved (no resolution tracking field
    currently, so this checks fired_at recency only)."""
    conn = get_connection()
    try:
        row = conn.execute(
            """
            SELECT alert_id FROM ceo_alerts
            WHERE deal_id = ? AND alert_type = ?
              AND fired_at > datetime('now', '-24 hours')
            LIMIT 1
            """,
            (deal_id, alert_type),
        ).fetchone()
        return row is not None
    finally:
        conn.close()


def fire_alert(deal_id: int | None, alert_type: str, message: str, severity: str | None = None) -> dict:
    """
    Inserts a ceo_alerts row unless the same (deal_id, alert_type)
    already fired in the last 24h. Returns whether it actually fired.
    """
    if deal_id is not None and already_fired_recently(deal_id, alert_type):
        return {"fired": False, "reason": "duplicate_within_24h"}

    resolved_severity = severity or ALERT_THRESHOLDS.get(alert_type, {}).get("severity", "WARN")

    conn = get_connection()
    try:
        conn.execute(
            """
            INSERT INTO ceo_alerts (deal_id, alert_type, severity, message)
            VALUES (?, ?, ?, ?)
            """,
            (deal_id, alert_type, resolved_severity, message),
        )
        conn.commit()
        return {"fired": True, "severity": resolved_severity}
    finally:
        conn.close()


def check_days_on_market_alerts(deal_id: int, days_on_market: int) -> list[dict]:
    """Fires DEAL_14_DAYS at 14+ DOM, DEAL_21_DAYS_FIRESALE at 21+ DOM."""
    results = []
    if days_on_market >= 21:
        results.append(fire_alert(deal_id, "DEAL_21_DAYS_FIRESALE",
                                    f"Deal at {days_on_market} days on market - escalate to fire-sale mode."))
    elif days_on_market >= 14:
        results.append(fire_alert(deal_id, "DEAL_14_DAYS",
                                    f"Deal at {days_on_market} days on market with no FP signed."))
    return [r for r in results if r]
