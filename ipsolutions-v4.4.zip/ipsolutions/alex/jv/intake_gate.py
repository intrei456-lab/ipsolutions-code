"""
JV intake gate — mandatory comp-verification for every external
wholesaler submission. Two failures -> reject + reputation downgrade.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta


GATE_ARV_INFLATION_THRESHOLD = 0.05    # partner ARV >5% above verified consensus = fail
GATE_REPAIRS_UNDERESTIMATE_THRESHOLD = 0.15  # partner repairs >15% below verified = fail
GRACE_WINDOW_BUSINESS_DAYS = 5


@dataclass
class GateResult:
    outcome: str          # PASS / FAIL_ARV / FAIL_REPAIRS / FAIL_BOTH
    arv_inflation_pct: float
    repairs_underestimate_pct: float


def run_comp_gate(
    partner_quoted_arv: float,
    partner_quoted_repairs: float,
    verified_arv: float,
    verified_repairs: float,
) -> GateResult:
    arv_inflation = (partner_quoted_arv - verified_arv) / verified_arv if verified_arv else 0
    repairs_underestimate = (
        (verified_repairs - partner_quoted_repairs) / verified_repairs if verified_repairs else 0
    )

    fail_arv = arv_inflation > GATE_ARV_INFLATION_THRESHOLD
    fail_repairs = repairs_underestimate > GATE_REPAIRS_UNDERESTIMATE_THRESHOLD

    if fail_arv and fail_repairs:
        outcome = "FAIL_BOTH"
    elif fail_arv:
        outcome = "FAIL_ARV"
    elif fail_repairs:
        outcome = "FAIL_REPAIRS"
    else:
        outcome = "PASS"

    return GateResult(
        outcome=outcome,
        arv_inflation_pct=arv_inflation,
        repairs_underestimate_pct=repairs_underestimate,
    )


def should_trigger_propwire_pull(
    arv_inflation_pct: float,
    deal_value: float,
) -> bool:
    """
    PropWire on-demand trigger conditions for the JV gate specifically:
      - ARV >5% inflated (already a gate failure trigger, extra confidence via PropWire)
      - deal value > $200k (extra comp confidence justifies the credit spend)
    """
    return arv_inflation_pct > GATE_ARV_INFLATION_THRESHOLD or deal_value > 200000


def next_action(outcome: str, prior_gate_run_count: int, is_second_failure: bool) -> dict:
    """
    PASS -> proceed to Track A (matching + outreach like an owned deal)
    FAIL_* first time -> GRACE window (5 business days), resend with verified numbers
    FAIL_* second time (after grace) -> REJECTED, partner downgrade
    """
    if outcome == "PASS":
        return {"status": "RUN_TRACK_A"}

    if is_second_failure:
        return {
            "status": "REJECTED",
            "downgrade_partner": True,
        }

    grace_start = datetime.now()
    # naive business-day approximation - production version should skip weekends properly
    grace_expires = grace_start + timedelta(days=GRACE_WINDOW_BUSINESS_DAYS + 2)
    return {
        "status": "GRACE",
        "grace_window_started_at": grace_start,
        "grace_window_expires_at": grace_expires,
        "gate_run_count": prior_gate_run_count + 1,
    }


def compute_reputation_downgrade(current_tier: str, downgrade_count: int) -> tuple[str, bool]:
    """
    A -> B at 1 downgrade, B -> C at 1 downgrade (i.e. any single
    downgrade drops a tier), C stays C but fires a CEO alert at 2+
    downgrades (JV_PARTNER_DOWNGRADE_2X).
    """
    new_downgrade_count = downgrade_count + 1
    tier_order = ["A", "B", "C"]
    idx = tier_order.index(current_tier) if current_tier in tier_order else 2
    new_tier = tier_order[min(idx + 1, len(tier_order) - 1)]

    fire_alert = new_downgrade_count >= 2
    return new_tier, fire_alert
