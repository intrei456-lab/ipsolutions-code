"""
Real financial partner seed data, pulled directly from Twin's live
database export (31 total: 12 verified/active buyers + 15 proactive-hunt
cold leads + 4 placeholder/seed rows to be cleaned out).

Run this after alex.db schema is initialized to load real starting data
instead of building the FP network from zero.

NOTE: the 4 placeholder rows (fp_id 30-33 in the live system) are
intentionally NOT seeded here - they were flagged by Thomas/Twin as
seed/test data that should be cleaned out, matching the is_test_data
discipline used throughout this codebase.

NOTE: 12 additional FPs (Ben Caplan, Randy, Oscar, Sylvia, Nasir, Chad,
Sallie, NorthEast Market Buyer, Julio, an unknown 202-area-code buyer,
Kareem, Latif) were mentioned as "waiting for credits refresh" - not yet
loaded in the live system either, so not included here. Add these once
Thomas has their full contact/buy-box details.
"""

from alex.db.db import get_connection

RACHAEL_COHEN_NOTE = (
    "Thomas's #1 VIP buyer historically. Has bought SHELLS and BLOCKS OF "
    "HOMES that typical buyers would ignore - made Thomas significant "
    "money, closes at great speed. Went inactive likely because Thomas "
    "sent her unprofessional/unpolished deals in the past - relationship "
    "needs to be re-earned. DO NOT send her anything unless it's a "
    "polished, fully-packaged, branded deal. The branded deal package "
    "system exists partly to win her back. First re-engagement must be "
    "PERFECT - lead with the best available deal, full package, no "
    "shortcuts. RE_ENGAGEMENT_PRIORITY = TRUE."
)

# (name, phone, state, buy_box_notes, relationship_stage, vip_tier)
VERIFIED_ACTIVE_BUYERS = [
    ("Rachael Cohen / GNR Group", "215-840-2420", "MD", "Shells, blocks, distressed. ZIPs 21215/21231", "INACTIVE", "VIP"),  # Thomas flagged this as a re-engage priority - don't silently mark active
    ("Frank Weaver", "410-207-6433", "MD", None, "ACTIVE", "VIP"),
    ("Zeem", "202-210-6055", "MD", "Buys whatever makes sense, new construction + lots", "ACTIVE", "VIP"),
    ("Victor London / Buy Baltimore", "443-597-8557", "MD", "Distressed/as-is, ZIPs 21213/21214/21216", "ACTIVE", "VIP"),
    ("Filipe Dias / Phil Enterprise", "301-674-5122", "MD", "Buys a lot, likes seller financing", "ACTIVE", "WARM"),
    ("Sophie Gamy / Doumeyzotole", "267-446-7869", "MD", "Multifamily", "ACTIVE", "VIP"),
    ("Rosario", "267-648-2017", "MD", None, "ACTIVE", "VIP"),
    ("Ali Raza", "443-831-2003", "MD", None, "ACTIVE", "VIP"),
    ("Maximus Global Capital", None, "FL", None, "ACTIVE", "VIP"),
    ("Richard Vidot / Oasis Property", None, "FL", None, "ACTIVE", "VIP"),
    ("Bohadana Two LLC", None, "FL", None, "ACTIVE", "VIP"),
    ("Nori Investment Group", None, "MD", None, "ACTIVE", "VIP"),
]

# (name, state, relationship_stage) - cold proactive-hunt finds
PROACTIVE_HUNT_COLD = [
    ("Charm City Builders", "MD", "COLD"),
    ("CR of Maryland", "MD", "COLD"),
    ("Sell My House Cash Baltimore", "MD", "COLD"),
    ("Homes For Cash Guys", "MD", "COLD"),
    ("Express Homebuyers MD", "MD", "COLD"),
    ("FL Cash Home Buyers", "FL", "COLD"),
    ("Freedom Cash Home Buyers", "FL", "COLD"),
    ("The Building Buyer", "FL", "COLD"),
    ("South FL Cash Home Buyers", "FL", "COLD"),
    ("We Buy Broward", "FL", "COLD"),
    ("B.J./Jennifer Ward (Easy Sale)", "NC", "WARM"),  # gave buy box already
    ("NC HomeBuyers", "NC", "COLD"),
    ("Sell Raleigh Home Fast", "NC", "COLD"),
    ("Green Street Home Buyers", "NC", "COLD"),
    ("Bright Home Offer", "NC", "COLD"),
]

# FPs mentioned as pending but not yet loaded - kept here as a visible
# TODO list rather than silently dropped, so nobody has to re-derive this
# from old chat history later.
PENDING_NOT_YET_LOADED = [
    "Ben Caplan", "Randy", "Oscar", "Sylvia", "Nasir", "Chad", "Sallie",
    "NorthEast Market Buyer", "Julio", "unknown buyer (202 area code)",
    "Kareem", "Latif",
]


def seed_financial_partners() -> dict:
    conn = get_connection()
    inserted_active = 0
    inserted_cold = 0

    try:
        for name, phone, state, buy_box_notes, stage, vip_tier in VERIFIED_ACTIVE_BUYERS:
            notes = RACHAEL_COHEN_NOTE if "Rachael Cohen" in name else None
            conn.execute(
                """
                INSERT INTO financial_partners (
                    entity_name, phone, preferred_states, buy_box_condition_preference,
                    relationship_stage, vip_tier, source, verification_notes, is_test_data
                ) VALUES (?, ?, ?, ?, ?, ?, 'MANUAL', ?, 0)
                """,
                (name, phone, f'["{state}"]', buy_box_notes, stage, vip_tier, notes),
            )
            inserted_active += 1

        for name, state, stage in PROACTIVE_HUNT_COLD:
            conn.execute(
                """
                INSERT INTO financial_partners (
                    entity_name, preferred_states, relationship_stage, vip_tier,
                    source, is_test_data
                ) VALUES (?, ?, ?, 'COLD', 'PROACTIVE_HUNT', 0)
                """,
                (name, f'["{state}"]', stage),
            )
            inserted_cold += 1

        conn.commit()
    finally:
        conn.close()

    return {
        "active_buyers_inserted": inserted_active,
        "cold_leads_inserted": inserted_cold,
        "total": inserted_active + inserted_cold,
        "pending_not_loaded": len(PENDING_NOT_YET_LOADED),
    }


if __name__ == "__main__":
    from alex.db.db import init_db
    init_db()
    result = seed_financial_partners()
    print(result)
