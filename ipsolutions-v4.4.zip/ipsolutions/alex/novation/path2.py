"""
Novation Path 2 (Alex's side) — runs ONLY when exit_strategy='NOVATION'.
The buyer is a retail end-user off MLS, NOT a financial partner. This is
Alex's go/no-go and legal-clearance gate; the actual seller-facing
conversation logic lives in Chris's chris/conversation/novation_*.py.
"""

from dataclasses import dataclass

from shared.config import NOVATION_MIN_IPS_PROFIT, NOVATION_DEFAULTS


@dataclass
class NovationGateResult:
    ips_profit_estimate: float
    meets_minimum: bool
    recommended_fallback: str | None = None


def run_novation_profitability_gate(
    listing_price: float,
    seller_net: float,
    rehab_cost: float,
    agent_commission_pct: float = NOVATION_DEFAULTS["agent_commission_pct"],
    closing_cost_pct: float = NOVATION_DEFAULTS["closing_cost_pct"],
) -> NovationGateResult:
    """
    IPS_profit = listing_price - seller_net - rehab_cost
                 - (listing_price * commission) - (listing_price * closing_cost)

    If profit < $15,000 -> kill novation, recommend Sub-To or Junior
    Brokerage as fallback, fire NOVATION_PROFIT_BELOW_MIN alert.
    """
    commission = listing_price * agent_commission_pct
    closing_costs = listing_price * closing_cost_pct
    profit = listing_price - seller_net - rehab_cost - commission - closing_costs

    meets_min = profit >= NOVATION_MIN_IPS_PROFIT
    fallback = None if meets_min else "SUBTO_OR_JUNIOR_BROKERAGE"

    return NovationGateResult(
        ips_profit_estimate=profit,
        meets_minimum=meets_min,
        recommended_fallback=fallback,
    )


# ---------------------------------------------------------------------------
# Legal prerequisites gate (HARD - do not list without all three)
# ---------------------------------------------------------------------------

@dataclass
class LegalClearanceStatus:
    contract_listing_clause: bool
    poa_signed: bool
    poa_notarized: bool

    @property
    def cleared(self) -> bool:
        return self.contract_listing_clause and self.poa_signed and self.poa_notarized

    @property
    def missing_items(self) -> list[str]:
        missing = []
        if not self.contract_listing_clause:
            missing.append("contract MLS-listing authorization clause")
        if not self.poa_signed:
            missing.append("signed Power of Attorney")
        if not self.poa_notarized:
            missing.append("notarized Power of Attorney")
        return missing


def check_legal_clearance(status: LegalClearanceStatus) -> dict:
    """
    HARD gate - if any of the three legal prerequisites are missing, listing
    is blocked and a CRITICAL CEO alert (NOVATION_LEGAL_INCOMPLETE) fires.
    """
    if status.cleared:
        return {"cleared": True, "action": "PROCEED_TO_LISTING"}

    return {
        "cleared": False,
        "action": "BLOCK_LISTING",
        "alert_type": "NOVATION_LEGAL_INCOMPLETE",
        "severity": "CRITICAL",
        "message": f"Cannot list - missing: {', '.join(status.missing_items)}. Listing blocked until resolved.",
    }


# ---------------------------------------------------------------------------
# Listing coordination gates (photo + legal, both must clear)
# ---------------------------------------------------------------------------

def ready_to_request_listing(
    photos_status: str,
    rehab_status: str,
    legal_status: LegalClearanceStatus,
) -> bool:
    """
    Photo gate: photos_status must be DELIVERED.
    Rehab gate: if light rehab was planned, it must be COMPLETE.
    Legal gate: all three legal prerequisites must be cleared.
    """
    return (
        photos_status == "DELIVERED"
        and rehab_status in ("COMPLETE", "NOT_NEEDED")
        and legal_status.cleared
    )


NOVATION_DEALS_STATUS_FLOW = [
    "NEW", "REHAB_PENDING", "REHAB_COMPLETE", "LISTING_REQUESTED",
    "LISTED_MLS", "OFFER_RECEIVED", "UNDER_CONTRACT", "CLOSED", "DEAD",
]
