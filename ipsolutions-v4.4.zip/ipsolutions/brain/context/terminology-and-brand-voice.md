# Context: Terminology & Brand Voice

Source: real business practice, encoded in `shared/terminology.py` and
enforced automatically on all outbound LLM-drafted content.

## Banned terms → required replacements

| Never say | Say instead |
|---|---|
| cash buyers | financial partners |
| investor list | funding network |
| wholesale / reselling | (avoid direct naming — use "financial partner" framing) |
| innovation *(when meant as novation — common typo)* | novation |

## Why "financial partners," not "cash buyers"

This isn't just polish — it solves a real historical problem. "Cash
buyer" or "investor" language, especially in person, primes sellers and
others to picture someone who doesn't look or act like a licensed
contractor or legitimate business — it can trigger skepticism or worse.
"Financial partners" / "Equity Protection Program participants" frames
the same relationship the way a car dealership frames its finance
department: a normal, trustworthy part of doing business, not something
to hide.

## Spread invisibility (hard rule, not a style preference)

Financial partners must never see `contract_price` or `assignment_fee`
individually — only `fp_facing_price` (the combined number they're
actually asked to pay). This is enforced at the code level
(`shared/rendering.py`'s `assert_outbound_safe_or_raise`), not just a
drafting guideline. Any LLM-drafted content for a financial partner
should never even receive these fields as input, so there's no chance
of them leaking through, even accidentally.

## Brand

Charcoal (#1A1A1A) + gold (#C9A961 / #D4A017). Tagline: "Real Service.
Real Solutions." Tone: peer-to-peer with financial partners (never
CRM-sounding or transactional), warm and pain-focused with sellers
(never scripted-sounding).
