# Context: Markets & Title Companies

Source: real live data from Twin export. Implemented in
`shared/config.py`, used by all three agents.

## Market ZIPs (45 total)

**MD Primary (7)**: 21206, 21212, 21213, 21214, 21216, 21218, 21239
(Baltimore)

**FL Secondary (18)**: Brevard (32901, 32955), Broward (33060, 33064,
33068), Miami-Dade (33169), Palm Beach (33405, 33407, 33415, 33435,
33487), Martin/Treasure Coast (33455), Polk (33853, 33881), Lake
(34748), St. Lucie (34946, 34947, 34950)

**NC Tertiary (20, multifamily-strong)**: 27262, 27265, 27284, 27526,
27608, 28117, 28301-28314

Any lead outside these 45 ZIPs is out of market and gets rejected at
intake — this is enforced automatically, not a judgment call per lead.

## Title Companies

- **MD Primary**: Maryland First Title — contact Kim Wade,
  kfw@hsclaw.com, 410-863-1552 x319
- **FL Primary**: Donna Hearne-Gousse PA
- **FL Backup**: Liberty Title
- **NC**: TBD — fires a CEO alert automatically on the first NC deal,
  since no title company is confirmed there yet

**Alex's reference network** (not primary, used situationally): Dulaney
Title & Escrow (MD, Towson), Cooperative Title Agency (FL,
double-close-experienced), TitleClearing.net (48 states, novation-
experienced), Abode Settlements (MD)

## EMD Tiers

- $3,000 / 14-day inspection period
- $5,000 / 30-day inspection period
- $7,500–$10,000 / 60-day inspection period
- All tiers carry a **$2,000 non-refundable carve-out**
