# Memory

This is the self-improving loop: real, specific lessons from actual
deals, objections, and decisions get recorded here so the brain
actually gets smarter over time instead of staying static. This is what
Remy Gaskell's framework calls "a memory md file" — the agent learns
preferences and makes fewer errors across sessions because this file
persists and gets loaded into context every time.

Good entries are specific:

> 2026-07-09: A financial partner claiming a "we buy houses" brand with
> zero closed deals in our Baltimore ZIPs turned out to be
> daisy-chaining — verify local track record specifically, not just
> that they've closed deals somewhere.

Bad entries (too generic to be useful):

> Always verify financial partners carefully.

Entries get added either directly by Thomas, or through Workspace Chat
via the `/workspace/memory/add` endpoint when Thomas tells it something
worth remembering.

Newest entries at the bottom.

---
