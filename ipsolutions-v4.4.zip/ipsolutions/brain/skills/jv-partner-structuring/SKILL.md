---
name: jv-partner-structuring
description: Use when deciding how a deal should be structured/sold - specifically whether to run it solo or route it to a joint-venture partner. Covers the "180 Wholesale" model, the one-market-focus rule, and why checkbook access (not lead volume) is the real constraint.
---

# Skill: JV Partner Structuring (the "180 Wholesale" model)

Source: Matt Beard, real estate business-building training.

## The core problem this solves

Running lead generation nationwide (cheap online ads, cold-calling
homeowners anywhere) produces leads in places with **no buyer
relationships ("checkbooks")** to actually sell to. Without a buyer
network in a market, a lead is worthless regardless of how cheap it
was to generate - the operator has to go find a JV partner from
scratch for every single new market a lead happens to land in. This is
a structurally bad model, not just an inefficient one.

## The fix: pick ONE market, get a JV partner there

**Focus all real outreach volume into a single metro market.**
Reasoning:
- A JV partner with real buyer relationships in that one market can
  price and move deals fast, because they already know what sells and
  to whom
- Depth in one market beats breadth across many - "are you doing at
  least one deal a month in each of 8-10 markets, or is it kind of
  half-assed across all of them?" Shallow presence across many markets
  underperforms real depth in one.
- Only add a second market once the first is genuinely strong (the
  benchmark used: roughly half a million dollars a year from the first
  market before adding a second)

This is explicitly **not** a full reverse-wholesaling model (where
someone else does all sourcing and structuring) - it's described as
"half reverse" - a joint venture partnership, not full delegation.

## Who to JV with, and when

JV a deal (rather than run it solo) when any of these is true:
- No deals closed yet in this business at all
- Deal flow has been inconsistent
- Entering a brand-new market with no track record there

As experience and revenue grow (explicit benchmark: roughly half a
million dollars a year), it becomes worth transitioning to direct
assignments without a JV partner, to keep the full assignment fee
rather than splitting it.

## The real economics of who to target for the market

**Prioritize agents with currently-active listings, not the full
licensed-agent universe.** Reasoning: roughly 70% of everyone holding
a real estate license did not sell a single property in the prior
year. An agent with an active listing right now is, by definition, not
in that inactive 70% - they're a real, currently-transacting
professional. This is why outreach lists should be built starting from
active/pending listings in the target market, not a blanket list of
every licensed agent (that broader list is a valid second-tier
expansion once the active-agent list is exhausted, not the starting
point).

## The real relationship-volume math

- Roughly **1 in 3 agents** an operator has closed a deal with will
  bring a **second** deal within the same calendar year
- To hit 3 closed deals a month (a rough half-a-million-a-year pace),
  the real number of agent relationships needed is closer to **24**
  agents who've already done a deal with the business - not hundreds
  of fresh contacts every month
- This is the real argument for nurturing Tier 1/Tier 2 relationships
  long-term rather than treating outreach as a purely one-shot,
  transactional activity - see [[agent-outreach]] for the tier
  system itself
