---
name: objection-handling
description: Use when a seller raises a concern or pushback during an acquisitions call - a real index of the 20 objections encountered, so the right rebuttal approach gets applied rather than improvised.
---

# Skill: Objection Handling

Source: Keith Everett acquisitions training (Parts 1 & 2). Full
near-verbatim rebuttal scripts live in `chris/conversation/objections.py`
— this index is for recognizing which objection is in play and the
general approach; pull the full script from code when actually running
the call.

## Part 1 objections

1. "I want to think about it / need to think it over" — don't let a
   soft stall end the call; dig into what specifically needs thinking
2. "I need to talk to my lawyer/attorney" — respect it, but clarify
   what specifically they want reviewed rather than treating it as a
   full stop
3. "I need to talk to my spouse" — this should have been caught at the
   DM gate; re-confirm who else needs to be on the next call
4. "Just send me the agreement" — resist skipping the actual
   conversation; the agreement without alignment leads to fall-through
5. "Just make me an offer / give me your best number" — don't skip
   pain discovery to jump straight to a number
6. "I don't know what I want / not sure what to ask for" — this is an
   opening to guide, not a dead end
7. "Have you seen the property?" — answer honestly about what's been
   seen (photos, comps) vs. an in-person visit
8. "I have tenants, don't want to disturb them" — landlord-specific
   concern, addresses timeline and process, not price
9. "You called me / why are you calling me?" — clarify the lead source
   honestly
10. "Which property?" — the seller may own multiple properties; confirm
    which one is actually being discussed

## Part 2 objections

11. "How did you get my number?" — same honesty principle as #9
12. "You're going to lowball me" — reframe around the comps-as-ranges
    approach, not a defensive reaction
13. "Never heard of your company" — credibility-building, not
    dismissal
14. "I need 60 days to move" — timeline negotiation, factor into
    closing structure, not a deal-breaker
15. "I have squatters" — a real complication; changes the offer
    structure and timeline meaningfully
16. "Let's hold off for now" — soft no; feeds into the follow-up
    cadence system, not abandonment
17. "My realtor said it's worth [X]" — comps-as-ranges reframe; realtor
    numbers are often retail-assumption, not as-is
18. "Do you have proof of funds?" — a fair, expected question;
    financial partner POF should be ready to reference
19. "The house next door sold for [X]" — comp-specific rebuttal,
    address why that comp may not apply directly
20. "It appraised for [X]" — appraisals often reflect retail/financed
    value, not as-is cash value; reframe accordingly

**Matching logic**: `find_matching_objection()` in code does simple
phrase matching against the seller's actual words — the trigger phrases
above are what the system watches for.
