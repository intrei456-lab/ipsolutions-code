---
name: offer-ladder-math
description: Use when computing a cash offer ladder (T1/T2/T3/MAO) or novation target from a property's ARV and repair estimate, or deciding between wholesale assignment and novation exit strategy.
---

# Skill: Cash Offer Ladder

Source: Keith Everett acquisitions training + Rich/Tony novation
transcripts. Implemented in `chris/conversation/offer_engine.py`.

## The three-tier cash ladder

Given ARV (after-repair value) and repair estimate:

- **T1 (opener)**: ARV × 0.60 − Repairs − Assignment Fee
- **T2**: ARV × 0.65 − Repairs − Assignment Fee
- **T3**: ARV × 0.70 − Repairs − Assignment Fee
- **MAO ceiling**: T3 + $15,000 breathing room

**Never offer below the T1 floor.** T1 is the opening number, not the
floor — there's room to move up to T3/MAO ceiling as negotiation
progresses, but T1 minus repairs minus fee is the hard bottom.

## Novation target

CMV (current market value, NOT ARV) × 0.90 — this is a fundamentally
different formula from the cash ladder, because novation isn't a
discount-for-speed transaction the way a cash offer is. Mixing up CMV
and ARV here is a real, historically-occurring bug (the live Twin
system had this exact error) — always double check which one is being
used.

## Double-close auto-flag

If the assignment fee would exceed 50% of the contract price, auto-flag
for a double-close instead of a straight assignment — a fee that large
relative to the contract price draws more scrutiny at the title company
and is cleaner structured as a double-close.

## Exit strategy decision

- Heavy rehab (above a repair-cost threshold) or seller explicitly wants
  retail exposure → lean toward novation
- Otherwise → wholesale assignment is the default path
