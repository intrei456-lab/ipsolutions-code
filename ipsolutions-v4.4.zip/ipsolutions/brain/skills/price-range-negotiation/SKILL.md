---
name: price-range-negotiation
description: Use when a seller's stated number falls within our MAO range - the 4-step sequence for squeezing room without pressure tactics reading as pushy.
---

# Skill: Price-Range Negotiation (4-Step Strategy)

Source: Keith Everett acquisitions training. Implemented in
`chris/conversation/negotiation.py`.

## Step 1: Don't show excitement

No verbal script — this is a discipline, not a line. Never react with
visible relief or enthusiasm when the seller's number lands under MAO,
even on a genuine home-run deal. Reacting excited tells the seller they
underpriced it.

## Step 2: Squeeze all the juice

> "That's gonna be a little tight for us, honestly. But remember, we're
> buying as-is, paying cash, covering closing costs, and we can close in
> 10 business days — considering all of that, what's the absolute best
> you could do?"

Act like the number stings even if it's well under the ceiling. This
isn't dishonesty — it's giving the seller room to reconsider before
locking in, which often surfaces a better number without any real
pressure.

## Step 3: Create urgency via partner

> "I feel like we've got a deal here, we just need to find it. Let me
> speak to my partner in the finance department — I'm not promising
> he'll agree to that number, but if I can get him on the same page and
> secure the funds, are we ready to get started today? [Before hanging
> up:] What's a good email? I want to send over our Company Commitment
> while I check."

This is a real hold, not just theater — but it also buys room without
committing to a number yet.

## Step 4: Close

> "Good news — it looks like we can do that number, and I secured the
> funds for you. Since we're looking at a few other properties, we'd
> need to get the process started today. Did you get a chance to look
> at the Company Commitment? Let's pull that email back up and go
> through the agreement together."

**When to use this sequence**: only once the seller's number is
confirmed to be within the MAO ceiling. If it's above MAO, this isn't
the right sequence — that's a different conversation about whether the
deal works at all.
