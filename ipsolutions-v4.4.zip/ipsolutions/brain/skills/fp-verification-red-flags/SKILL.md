---
name: fp-verification-red-flags
description: Use when evaluating a new or unfamiliar financial partner before trusting them with a deal - a checklist of behaviors that indicate daisy-chaining or lack of real purchasing intent.
---

# Skill: Financial Partner Verification (Red Flags)

Source: real dispositions experience. Implemented in
`alex/fp_network/verification.py`.

Before trusting a new financial partner with a deal, watch for these
red flags. Real end-buyers behave differently from wholesalers layering
another assignment on top of yours (daisy-chaining) — these signals
tell them apart.

| Flag | What it means |
|---|---|
| **Asks "can I assign this?"** | Real end-buyers don't ask this on first contact — they're buying to hold or flip, not to re-wholesale |
| **Asks about the assignment fee/spread** | Real buyers care about the property price, not your margin — asking about the spread signals they're a wholesaler sizing up a re-assignment |
| **Wants to bring a partner/JV before seeing the deal** | Layering another assignment before even evaluating the property |
| **Cannot provide proof of funds when requested** | No actual purchasing capacity |
| **"We buy houses" brand, no verifiable closed transactions in our markets** | No real track record backing the marketing |
| **Requests 30+ day inspection period** | Likely buying time to find their own buyer rather than actually closing |
| **Generic wholesaling LLC, no track record** | Same daisy-chain risk as above |
| **Flagged by other wholesalers/FPs as a daisy-chainer** | Network-level red flag from prior experience |
| **Insists on their own title company** | Possible double-close concealment |
| **Asks for the property address before committing EMD or showing proof of funds** | Address-shopping — collecting deal flow without real intent to close |

**Rule**: one flag alone isn't necessarily disqualifying, but flags
compound — a financial partner triggering two or more of these should
be treated as unverified until they clear it up directly, not given the
benefit of the doubt by default.
