---
name: agent-offer-presentation
description: Use when it's time to actually present a real number to an agent, after the setup call and property analysis have already happened (see setup-call-script for the diagnostic call itself). Covers why the offer is never sent in writing first, the two presentation scripts (can-pay vs can't-pay), and the hard rule against ever giving a full-price offer.
---

# Skill: Agent Offer Presentation

Source: Matt Beard, real estate agent outreach training. This is
Chris's phase after the setup call has already happened and the
property has already been analyzed/comped (see [[setup-call-script]]
for the earlier diagnostic call, [[offer-ladder-math]] for the
underlying numbers). This skill governs how the actual number gets
delivered to the agent.

## The hard rule: never send a number in writing first

**Every real offer starts as a live conversation (phone), never a
text or email with a number in it up front.** Sending numbers cold in
writing loses the ability to gauge reaction, present context, and
control how the number lands. Writing only comes after the verbal
conversation has already happened and the agent has already gone to
their seller.

## Scenario A: we CAN pay their asking price

**Do not simply confirm you'll pay it.** Even if the numbers work at
full price, agreeing outright creates two problems: it removes any
room to negotiate further, and — more importantly — it risks seller
remorse ("if they said yes that easily, we probably priced it too
low") which can lead the seller to push for more before signing.

Instead, frame it as being talked into it, and attach urgency:

> "I think I might be able to make [asking price] work — I'd honestly
> be more comfortable closer to [lower number], but if that's really
> what it takes to get this done, I might be able to come up. If I can
> make that happen, is your client ready to move forward today? I
> don't want to miss the window, and I don't want to end up in a
> bidding war."

This does two things at once: it holds a small amount of negotiating
room even at "yes," and it creates a same-day close window rather than
leaving the door open for the agent to shop the now-confirmed number
to other buyers.

## Scenario B: we CANNOT pay their asking price

Use a good news / bad news / good news structure — appreciate them,
be honest about the gap, then invite them back into the conversation:

> "Appreciate you sending this one over. Running the numbers, I don't
> think I can hit [asking price] and still make our 15% margin work —
> I'm a decent amount under that, probably [wide range, e.g. 'mid one-
> hundreds']. Is there any room to work with me here? I know it's
> important your client gets as much as they can — I get it, I'm sure
> you've got other people in a similar spot. It's just where the
> numbers land for us."

**Never give a specific number in this scenario either — give a wide,
vague range** ("mid one-hundreds," not "$142,500"). This preserves
real room once the agent goes back to their seller and returns with
an actual counter.

## The absolute hard rule: never make a full-price offer, even when you can afford it

**A listing can always sell for more than its list price.** If an
agent gets a full-price offer from you, the natural (and completely
rational, from their side) move is to use that confirmed number as
leverage to shop for something even higher from another buyer. Giving
a full-price number, even when the deal genuinely supports it, removes
your own leverage and invites exactly the bidding war this whole model
is built to avoid (see [[setup-call-script]] — "no bidding wars" is
already a hard rule there for the same underlying reason).

## Who actually drafts the contract, and in what order

1. **The agent talks to their seller first** — before anything is put
   in writing, the agent goes back to their client with the number/
   range discussed on the call
2. **Only after the agent confirms real interest** does anything get
   sent in writing — and even then, send a **price range** (e.g.
   "$165k-$175k"), not a single confirmed number. Treat roughly $10k
   below the top of that stated range as the real ceiling.
3. **The agent draws up the actual contract** with the price and terms
   their client wants filled in, not the buyer. This isn't just a
   division of labor - it's part of what the agent is actually being
   compensated for, and it keeps the buyer from being the one
   committing anything in writing before the seller has genuinely said
   yes.

## Standard terms baseline (starting point, not fixed)

- Close: roughly 3 to 3.5 weeks / business days
- Inspection period: 7 days standard, 5 days if a faster close is
  needed
- These are a starting point to offer, not a rule - adjust to what a
  specific deal's numbers and timeline actually require

## Tone and delivery (applies throughout, not just this phase)

- **Keep it light, not heavy or lecture-toned.** Talk to an agent the
  way you'd talk to a friend having a normal conversation, not the way
  you'd issue instructions. A heavy, corrective tone invites pushback
  the same way it would with a friend or family member.
- **Self-deprecating humor is a real tool, not filler** - it signals
  there's no pressure and takes the edge off what could otherwise feel
  like a high-stakes negotiation.
- **Address the obvious elephant in the room directly**: most agents
  get flooded with lowball offers from people with no real proof of
  funds. Acknowledging this openly ("I know you probably get a ton of
  these") and being straightforwardly honest about who you are builds
  more trust than pretending the dynamic doesn't exist.

## Practical clarifications worth knowing

- **If an agent asks for an NDA before sending you properties**, this
  is a real, reasonable ask — but it only restricts disclosure of
  properties they specifically sent you, before you have them under
  contract. Once a specific property is actually under contract, doing
  what you want with that specific deal (assigning it, marketing it,
  etc.) doesn't violate that NDA - the NDA is about not shopping their
  leads around before there's a deal, not about the deal itself once
  it exists. This is also the underlying reason agents are protective
  about sending you properties directly instead of just letting you
  browse MLS - it's their way of guarding against being cut out of a
  deal they sourced.
- **Avoid the term "JV partner" with agents who may not know what that
  means.** Reframe as "I've got a partner who's going to help with
  [specific part of the process]" - concrete and understandable beats
  jargon, even accurate jargon.
- **A real, low-cost proof-of-funds verification option exists** in
  the roughly $70 range that provides phone-verifiable proof of funds
  across multiple states - worth having ready before an agent asks,
  since being able to actually produce this on request (and have it
  hold up if the agent calls to confirm) builds real credibility
  quickly.
