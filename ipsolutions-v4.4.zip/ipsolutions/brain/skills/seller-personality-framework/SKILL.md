---
name: seller-personality-framework
description: Use when reading a seller's personality type in the first minutes of a call (Green/Red/Blue/Yellow) to calibrate tone and pacing during acquisitions conversations.
---

# Skill: Seller Personality Framework

Source: Keith Everett / Hustle Implementers acquisitions training.
Implemented in `chris/conversation/personality.py`.

Four personality types, read from how the seller talks in the first few
minutes of the call. Adjust tone and pacing accordingly — don't change
the numbers, change the delivery.

## GREEN — Analytical
Wants data, comps, logic. Skeptical of anything that sounds like a
sales pitch. Lead with numbers and reasoning, not urgency or emotion.

## RED — Aggressive
Direct, impatient, wants to get to the bottom line fast. Don't over-
explain. Give the number, hold the frame, let silence do the work.

## BLUE — Easy-going (THE TRAP)
Agreeable, friendly, seems like the easiest call of the day. **This is
the trap**: if a Blue seller names a number and you agree too quickly,
it telegraphs that there's more room, and the seller re-anchors higher.
Slow down on Blue sellers specifically — agreeing fast reads as weak,
not friendly.

## YELLOW — Emotional
Motivated by story and connection more than numbers alone. Needs to
feel heard before they'll engage with the offer. Don't skip the pain
discovery step with a Yellow seller — rushing to the number reads as
cold and loses trust.

---

**Rule**: identify the type from the first 2-3 minutes of conversation,
before any numbers are discussed. Getting this read right changes how
the rest of the call should go, not what the actual offer numbers are.
