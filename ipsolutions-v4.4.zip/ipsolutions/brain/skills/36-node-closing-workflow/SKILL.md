---
name: 36-node-closing-workflow
description: Use when tracking or discussing where a deal stands in the closing process, from signed assignment through deed recorded - the real 36 nodes in order.
---

# Skill: 36-Node Closing Workflow

Source: real titles confirmed directly against the live Twin build,
grouped into 4 phases exactly as Twin organized them. Implemented in
`taylor/nodes/node_template.py` and `taylor/nodes/engine.py`.

## PRE_CLOSING (nodes 1-12)

1. Receive Alex handoff record
2. Validate signed assignment doc URL is accessible
3. Confirm FP contact info complete (name, email, phone, entity, EIN)
4. Confirm EMD received and matches close timeline tier
5. Confirm seller signed purchase contract on file
6. Confirm Affidavit & MOA filed at county ($25 anti-double-sell)
7. Open file with assigned title company (state-routed)
8. Order title search
9. Order title insurance commitment
10. Verify property tax status (current vs delinquent)
11. Verify HOA status if applicable
12. Verify utility status (water/sewer liens, code violations)

## CONTRACT_DOCS (nodes 13-22)

13. Draft FP closing package (settlement preview, ALTA, wire)
14. Confirm FP funding source (cold cash 1-2 days vs private/hard money
    7-14 days)
15. Send FP funding instructions
16. Coordinate FP wire to title company escrow
17. Verify wire received in escrow
18. Coordinate seller closing package
19. Confirm seller execution method (mail-away / in-person / mobile
    notary)
20. Order mobile notary if mail-away (FL/NC)
21. Confirm IPSolutions Assignment recorded with title company
22. Confirm Termination/Extension/Auth-Release-Escrow if needed

## CLOSING (nodes 23-29)

23. Schedule closing table date with all parties
24. Send 48-hour reminder to FP, seller, title company
25. Confirm photos package delivered to FP
26. Day-of: monitor wire receipt, document execution, recording
27. Day-of: receive HUD/CD final from title company
28. Verify IPSolutions assignment fee disbursed correctly
29. Verify EMD released or applied per contract

## POST_CLOSING (nodes 30-36)

30. Confirm deed recorded with county
31. Send closing confirmation to Thomas (with HUD attached)
32. Send closing confirmation to FP (post-close client care)
33. Send closing confirmation to seller (transaction complete)
34. Update REsimpli with closed-won status
35. Trigger Alex post-close follow-up cadence with FP
36. Archive complete deal file

## Key rules that don't show up in the node titles alone

- Node 6 (Affidavit/MOA): STANDARD risk tier auto-completes; PROTECT_SPREAD
  risk tier blocks until Thomas explicitly confirms the county filing
- Node 25 (photos): Taylor only verifies — never re-coordinates
  TaskRabbit directly; escalate to Alex if photos are missing
- Node 28 (fee): blocks if the HUD disbursement doesn't match the
  signed assignment fee exactly
- Node 4 (EMD): blocks with a HIGH alert if not received within 24h of
  assignment signature
- **Stall detection**: any in-progress node sitting 72+ hours with no
  movement fires a MEDIUM alert automatically
