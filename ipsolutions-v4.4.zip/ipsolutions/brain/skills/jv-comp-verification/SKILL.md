---
name: jv-comp-verification
description: Use when a joint-venture partner brings a deal with their own ARV and repair estimates - the mandatory verification gate before trusting their numbers.
---

# Skill: JV Comp Verification Gate

Source: real dispositions practice. Implemented in
`alex/jv/intake_gate.py`.

Every external JV partner's numbers get verified against consensus
before being trusted — this isn't optional or case-by-case.

## Gate thresholds

- **ARV inflated more than 5%** above verified consensus → gate failure
- **Repairs underestimated by more than 15%** below verified estimate →
  gate failure
- Outcomes: `PASS`, `FAIL_ARV`, `FAIL_REPAIRS`, or `FAIL_BOTH`

## What happens on failure

**First failure** → GRACE window of 5 business days — the partner gets
a chance to resend with corrected, verified numbers. This isn't an
automatic rejection; people make honest estimation errors.

**Second failure** (after the grace window) → **REJECTED**, and the
partner's reputation tier gets downgraded. Repeated inflated numbers
after already being given a chance to correct is a real pattern, not a
one-off mistake.

## When extra comp confidence is worth the spend

Pull additional confirmation (e.g. via PropWire) specifically when:
- ARV is already flagged as inflated (a gate-failure trigger — extra
  confidence justifies the credit spend to confirm or dispute it)
- Deal value exceeds $200k (the size of the deal justifies extra
  diligence cost)

Below these thresholds, the standard verification process is
sufficient without extra spend.
