---
name: novation-mechanics
description: Use when discussing or structuring a novation exit strategy with a seller - the real mechanics, math, and terminology that differ from a standard cash wholesale deal.
---

# Skill: Novation Mechanics

Source: Tony/Rich "Rainmaker method" novation transcripts. Implemented
in `chris/conversation/novation_mechanics.py` and
`chris/conversation/offer_engine.py`.

## The core formula difference

Novation pricing uses **CMV (current market value / as-is value)**, NOT
ARV. This is a fundamentally different number from the cash-offer
ladder, and mixing them up is a real, previously-occurring bug (the
live Twin system had exactly this error at one point) — always confirm
which valuation is actually being used.

**Novation target = CMV × 0.90**

CMV is easier to comp accurately than ARV since there are far more
as-is comparable sales than after-repair comparable sales.

## Real mechanics that differ from a standard wholesale deal

- **POA (Power of Attorney)**, not "attorney-in-fact" — some states
  require a state-specific POA rather than a generic one; some
  practitioners have historically used "attorney-in-fact" language, but
  a properly executed POA is what's actually needed
- The **fee shows as a "marketing fee" invoice** on the HUD/CD, not as
  an assignment fee line item — this is the real, standard way novation
  fees are documented at closing
- **Title company matters more than usual** — use IPS's title company,
  not the buyer's, since novation closings have more moving parts than
  a standard assignment
- **60-day typical timeline** — longer than a standard cash close,
  since novation involves replacing (not assigning) the buyer for
  financed purchases, particularly FHA/VA

## Condition spectrum — novation isn't just for distressed properties

The real transcripts confirm novation works across a broad condition
range: move-in-ready, "clean but dated," and rough properties alike —
it's not exclusively a rehab-property strategy.

## The honest alternative

`novation_honest_transition.py` holds a transparent pitch alternative:
disclosing the real price and acknowledging the genuine
wholesaler-flake risk directly to the seller, rather than leaning on
manufactured scarcity. Use this framing when a seller seems sharp
enough to see through pressure tactics — honesty reads as more credible
to this type of seller than urgency does.
