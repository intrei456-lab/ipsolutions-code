---
name: 5-day-dispo-process
description: Use when running dispositions on a newly locked deal - the day-by-day process from photos through decision day, including the TTB (Time to Blast) metric.
---

# Skill: 5-Day Dispo Process

Source: Matt Beard "checkbooks" model. Implemented in
`alex/dispo/five_day_engine.py`.

## TTB — the single most important metric

Time to Blast (TTB) = hours from Chris's handoff to Alex actually
blasting the deal to financial partners. This is THE headline metric.

- **Target: under 12 hours**
- **Critical: over 24 hours** (fires an alert)

Per Matt Beard's source material, deals with TTB under 12 hours close
at a dramatically higher rate — the real reference point is contracted
deals selling to roughly 70% purely by making TTB a tracked, enforced
metric instead of an afterthought. Speed to market matters more than
almost anything else in dispositions.

## Day-by-day

**Day 0**: Photos requested within 24h of Chris's handoff — mandatory,
no exceptions. Rank financial partners. Draft all outreach, ready to
fire the moment photos land. The Day 1 blast is BLOCKED until both
photos are delivered AND drafts are ready.

**Day 1**: The blast — TTB clock stops here. A-tier financial partners
first, B-tier +4 hours later, C-tier +8 hours later (or end of Day 1).

**Day 2**: Deal-specific financial partner hunt beyond the existing
network if the pipeline needs more depth (Mode 2).

**Day 3**: Follow up on Day 1 non-responders — A-tier gets a mandatory
Thomas phone call, B-tier gets a follow-up email, C-tier gets no
follow-up yet. If no offers by end of Day 3, prepare a price-adjustment
recommendation.

**Day 4**: ONE 2-hour showing window, all interested financial partners
in the same slot — never individual showings. Escort every financial
partner; never let one talk to the seller unsupervised.

**Day 5**: Decision day. Ask "is that really the best you can do?" on
every offer. Send FOMO texts to other interested parties once one offer
is accepted.
