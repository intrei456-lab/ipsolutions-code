#!/bin/bash
# deploy.sh - the standard, correct redeploy process for IPSolutions.
#
# Encodes every real bug found and fixed the hard way on 2026-07-17:
#   - rm -rf ipsolutions-old BEFORE mv, so folders never nest inside
#     each other across multiple deploys (this alone caused several
#     hours of ".env keeps reverting to an old value" confusion)
#   - copies .env forward (was already happening)
#   - copies all three agent databases forward (was NEVER happening -
#     every prior deploy silently created fresh, empty databases)
#
# Usage: ./deploy.sh <version>
#   e.g. ./deploy.sh v2.7
#
# Requires: run from ~ (the user's home directory), with the new
# version's zip already uploaded to the GitHub repo.

set -e  # stop immediately on any real error, rather than continuing
        # into a broken half-deployed state

VERSION="$1"
if [ -z "$VERSION" ]; then
    echo "Usage: ./deploy.sh <version>   (e.g. ./deploy.sh v2.7)"
    exit 1
fi

echo "=== Deploying $VERSION ==="

echo "--- Stopping service ---"
systemctl stop ipsolutions

echo "--- Removing old backup folder (prevents nesting bug) ---"
rm -rf ipsolutions-old

echo "--- Backing up current version ---"
mv ipsolutions ipsolutions-old

echo "--- Downloading $VERSION ---"
wget "https://raw.githubusercontent.com/intrei456-lab/ipsolutions-code/main/ipsolutions-${VERSION}.zip" -O "ipsolutions-${VERSION}.zip"
unzip -o "ipsolutions-${VERSION}.zip"

echo "--- Carrying forward .env ---"
cp ipsolutions-old/.env ipsolutions/.env

echo "--- Carrying forward real databases (the part that was always being skipped) ---"
cp ipsolutions-old/chris/db/chris.db ipsolutions/chris/db/ 2>/dev/null && echo "  chris.db carried forward" || echo "  no existing chris.db (fine on first deploy)"
cp ipsolutions-old/alex/db/alex.db ipsolutions/alex/db/ 2>/dev/null && echo "  alex.db carried forward" || echo "  no existing alex.db (fine on first deploy)"
cp ipsolutions-old/taylor/db/taylor.db ipsolutions/taylor/db/ 2>/dev/null && echo "  taylor.db carried forward" || echo "  no existing taylor.db (fine on first deploy)"

echo "--- Installing dependencies ---"
cd ipsolutions
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt --quiet

echo "--- Starting service ---"
systemctl start ipsolutions

sleep 2
echo "--- Status ---"
systemctl status ipsolutions --no-pager

echo ""
echo "=== Deploy of $VERSION complete ==="
echo "Verify with: journalctl -u ipsolutions -n 20 --no-pager"
