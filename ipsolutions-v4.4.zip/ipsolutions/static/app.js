// IPSolutions Pipeline Command - vanilla JS, no build step, calls the
// real FastAPI endpoints defined in main.py.

const SUB_TABS = {
  workspace: [],
  builder: [],
  chris: [
    { id: 'chat', label: 'Chat' },
    { id: 'map', label: 'Map' },
    { id: 'leads', label: 'Leads' },
    { id: 'agents', label: 'Agents' },
    { id: 'kpi', label: 'Daily KPI' },
    { id: 'conversion', label: 'Conversion' },
    { id: 'outreach', label: 'Outreach' },
    { id: 'd2s', label: 'D2S' },
    { id: 'structuring', label: 'Structuring' },
    { id: 'scouts', label: 'Scout Runs' },
  ],
  alex: [
    { id: 'chat', label: 'Chat' },
    { id: 'deals', label: 'Pipeline' },
    { id: 'five_day_board', label: '5-Day Board' },
    { id: 'fp_network', label: 'FP Network' },
    { id: 'kpi', label: 'KPI' },
    { id: 'alerts', label: 'CEO Alerts' },
  ],
  taylor: [
    { id: 'chat', label: 'Chat' },
    { id: 'closings', label: 'Closings' },
    { id: 'emd', label: 'EMD' },
    { id: 'alerts', label: 'CEO Alerts' },
  ],
};

let currentAgent = 'workspace';
let currentSubTab = null;
let workspaceHistory = [];
let builderHistory = [];

function switchAgent(agent) {
  currentAgent = agent;
  currentSubTab = SUB_TABS[agent].length ? SUB_TABS[agent][0].id : null;
  document.querySelectorAll('.agent-tab').forEach(el => {
    el.classList.toggle('active', el.dataset.agent === agent);
  });
  renderSubTabs();
  loadView();
}

function renderSubTabs() {
  const nav = document.getElementById('subTabs');
  nav.innerHTML = '';
  SUB_TABS[currentAgent].forEach(tab => {
    const el = document.createElement('div');
    el.className = 'sub-tab' + (tab.id === currentSubTab ? ' active' : '');
    el.textContent = tab.label;
    el.onclick = () => { currentSubTab = tab.id; renderSubTabs(); loadView(); };
    nav.appendChild(el);
  });
}

function refreshCurrent() { loadView(); }

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url} returned ${res.status}`);
  return res.json();
}

function emptyState(message) {
  return `<div class="empty-state"><div class="glyph">&mdash;</div>${message}</div>`;
}

function badge(text, kind, live) {
  const pulseClass = live ? ' pulse' : '';
  return `<span class="badge badge-${kind}${pulseClass}">${text}</span>`;
}

function statusBadgeKind(status) {
  const s = (status || '').toUpperCase();
  if (['DONE', 'CLOSED', 'VERIFIED_BUYER', 'ACTIVE', 'REPEAT'].includes(s)) return 'green';
  if (['BLOCKED', 'DEAD', 'CRITICAL', 'SUSPECTED_WHOLESALER'].includes(s)) return 'red';
  if (['IN_PROGRESS', 'WARN', 'PENDING'].includes(s)) return 'amber';
  return 'neutral';
}

function isLiveStatus(status) {
  return (status || '').toUpperCase() === 'IN_PROGRESS';
}

async function loadView() {
  const main = document.getElementById('mainContent');
  if (currentAgent === 'workspace') { renderWorkspaceChat(main); return; }
  if (currentAgent === 'builder') { renderBuilderView(main); return; }
  main.innerHTML = '<div class="loading">Loading...</div>';
  try {
    if (currentAgent === 'chris') await loadChrisView(main);
    else if (currentAgent === 'alex') await loadAlexView(main);
    else if (currentAgent === 'taylor') await loadTaylorView(main);
  } catch (err) {
    main.innerHTML = emptyState(`Could not load data — ${err.message}. Is the server running?`);
  }
}

// ---------------------------------------------------------------------------
// Workspace Chat - the Chief of Staff layer, embedded in the dashboard
// ---------------------------------------------------------------------------

function renderWorkspaceChat(main) {
  main.innerHTML = `
    <div style="max-width:700px;margin:0 auto">
      <div id="overviewStats" style="margin-bottom:20px"></div>
      <div id="dealJourney" style="margin-bottom:20px"></div>
      <div id="reflectionsBanner"></div>
      <div id="workspaceMessages" style="display:flex;flex-direction:column;gap:12px;margin-bottom:16px;min-height:200px"></div>
      <div style="display:flex;gap:8px">
        <input id="workspaceInput" placeholder="Ask about deals, strategy, or what's happening across the business..."
          style="flex:1;padding:12px;background:var(--charcoal-light);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:8px"
          onkeydown="if(event.key==='Enter') sendWorkspaceMessage()">
        <button onclick="sendWorkspaceMessage()" style="padding:12px 20px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:8px;font-weight:600;cursor:pointer">Send</button>
      </div>
      <div style="display:flex;gap:8px;margin-top:10px;align-items:center">
        <input id="lessonInput" placeholder="Save a lesson to the brain (e.g. what you learned from a deal)..."
          style="flex:1;padding:8px;background:var(--charcoal-light);border:1px solid var(--border-subtle);color:var(--text-secondary);border-radius:6px;font-size:12px">
        <button onclick="saveLessonToBrain()" style="padding:8px 14px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;font-size:12px;cursor:pointer">Save to Brain</button>
      </div>
      <div id="lessonStatus" style="font-size:11px;margin-top:6px"></div>
    </div>`;
  renderWorkspaceMessages();
  loadPendingReflections();
  loadOverviewStats();
  loadDealJourney();
}

async function loadDealJourney() {
  const container = document.getElementById('dealJourney');
  try {
    const { journey } = await fetchJSON('/workspace/handoffs_overview');
    if (!journey.length) { container.innerHTML = ''; return; }

    container.innerHTML = `<div class="node-phase">
      <h3>Deal Journey</h3>
      <table class="data-table">
        <tr><th>Address</th><th>Chris</th><th>Alex</th><th>Taylor</th></tr>
        ${journey.map(j => `<tr>
          <td>${j.address}</td>
          <td>${badge(j.chris_status, statusBadgeKind(j.chris_status))}</td>
          <td>${j.alex_status ? badge(j.alex_status, statusBadgeKind(j.alex_status)) + (j.alex_fp_assigned ? ' <span style="color:var(--status-green);font-size:11px">FP assigned</span>' : '') : '<span style="color:var(--text-secondary)">—</span>'}</td>
          <td>${j.taylor_node ? `Node ${j.taylor_node}/36 ${badge(j.taylor_status, statusBadgeKind(j.taylor_status), isLiveStatus(j.taylor_status))}` : '<span style="color:var(--text-secondary)">—</span>'}</td>
        </tr>`).join('')}
      </table>
    </div>`;
  } catch (err) {
    container.innerHTML = '';
  }
}

async function loadOverviewStats() {
  const container = document.getElementById('overviewStats');
  try {
    const [leadsRes, dealsRes, closingsRes, fpRes] = await Promise.all([
      fetchJSON('/chris/leads'), fetchJSON('/alex/deals'),
      fetchJSON('/taylor/closings'), fetchJSON('/alex/financial_partners'),
    ]);
    const activeDeals = dealsRes.deals.filter(d => d.dispo_status !== 'TAYLOR_HANDOFF' && d.dispo_status !== 'DEAD').length;
    const activeClosings = closingsRes.closings.filter(c => c.status === 'in_progress').length;

    container.innerHTML = kpiRow([
      ['Leads', leadsRes.leads.length],
      ['Active Deals', activeDeals],
      ['Closings In Progress', activeClosings],
      ['Financial Partners', fpRes.financial_partners.length],
    ]);
  } catch (err) {
    container.innerHTML = '';
  }
}

async function loadPendingReflections() {
  const banner = document.getElementById('reflectionsBanner');
  try {
    const res = await fetch('/workspace/pending_reflections');
    const data = await res.json();
    if (!data.pending || !data.pending.length) { banner.innerHTML = ''; return; }

    banner.innerHTML = `<div class="node-phase" style="margin-bottom:16px;border-color:var(--gold-light)">
      <h3>Closed deals worth reflecting on</h3>
      ${data.pending.map(p => `<div class="node-row">
        <span>${p.address}</span>
        <button onclick="promptLesson('${p.address.replace(/'/g, "\\'")}')" style="padding:4px 10px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;font-size:11px;cursor:pointer">What did you learn?</button>
      </div>`).join('')}
    </div>`;
  } catch (err) {
    banner.innerHTML = '';
  }
}

function promptLesson(address) {
  const input = document.getElementById('lessonInput');
  input.value = `Lesson from ${address}: `;
  input.focus();
}

async function saveLessonToBrain() {
  const input = document.getElementById('lessonInput');
  const statusEl = document.getElementById('lessonStatus');
  const lesson = input.value.trim();
  if (!lesson) return;

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Saving...</span>';
  try {
    const res = await fetch('/workspace/memory/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lesson }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = '<span style="color:var(--status-green)">Saved to brain/memory/lessons.md</span>';
      input.value = '';
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error || 'unknown'}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

function renderWorkspaceMessages() {
  const container = document.getElementById('workspaceMessages');
  if (!workspaceHistory.length) {
    container.innerHTML = `<div class="empty-state"><div class="glyph">&mdash;</div>
      Ask me anything about your business — I can see live counts across Chris, Alex, and Taylor.
      <br><span style="font-size:11px">Note: this chat resets when you reload the page — it's not saved yet.</span></div>`;
    return;
  }
  container.innerHTML = workspaceHistory.map(m => {
    const isUser = m.role === 'user';
    // User messages render as plain escaped text. Assistant messages render through
    // marked.js (already loaded for briefs elsewhere) so headers, bullet lists, and
    // GFM tables show up the way Twin's own chat renders them, instead of raw text.
    const body = isUser
      ? escapeHtml(m.content).replace(/\n/g, '<br>')
      : (window.marked ? marked.parse(m.content) : `<pre style="white-space:pre-wrap;margin:0;font-family:inherit">${escapeHtml(m.content)}</pre>`);
    return `
    <div style="align-self:${isUser ? 'flex-end' : 'flex-start'};max-width:${isUser ? '80%' : '92%'}">
      <div style="font-size:10px;text-transform:uppercase;color:var(--text-secondary);margin-bottom:4px;text-align:${isUser ? 'right' : 'left'}">${isUser ? 'You' : 'Workspace'}</div>
      <div class="${isUser ? '' : 'workspace-markdown'}" style="background:${isUser ? 'var(--gold-light)' : 'var(--charcoal-light)'};color:${isUser ? 'var(--charcoal)' : 'var(--text-primary)'};padding:12px 16px;border-radius:12px;font-size:14px;line-height:1.5">${body}</div>
    </div>`;
  }).join('');
  container.scrollTop = container.scrollHeight;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function sendWorkspaceMessage() {
  const input = document.getElementById('workspaceInput');
  const text = input.value.trim();
  if (!text) return;

  workspaceHistory.push({ role: 'user', content: text });
  input.value = '';
  renderWorkspaceMessages();

  workspaceHistory.push({ role: 'assistant', content: '...' });
  renderWorkspaceMessages();

  try {
    const res = await fetch('/workspace/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: workspaceHistory.slice(0, -1) }),
    });
    const data = await res.json();
    workspaceHistory.pop(); // remove the '...' placeholder

    if (data.success) {
      workspaceHistory.push({ role: 'assistant', content: data.reply });
    } else {
      workspaceHistory.push({ role: 'assistant', content: `Error: ${data.error}` });
    }
  } catch (err) {
    workspaceHistory.pop();
    workspaceHistory.push({ role: 'assistant', content: `Error: ${err.message}` });
  }
  renderWorkspaceMessages();
}

// ---------------------------------------------------------------------------
// Builder - the live site builder. Chat on the left actually writes to
// brain/site_settings.json via /workspace/builder/chat; the right side is
// a real iframe of the actual live site (not a mockup), refreshed after
// every successful change so Thomas watches the real site update.
// ---------------------------------------------------------------------------

function renderBuilderView(main) {
  main.innerHTML = `
    <div class="builder-split" style="display:flex;gap:16px;height:640px;max-width:1400px">
      <div class="builder-chat-pane" style="width:420px;flex-shrink:0;display:flex;flex-direction:column;border:1px solid var(--border-subtle);border-radius:10px;overflow:hidden">
        <div style="padding:14px 16px;border-bottom:1px solid var(--border-subtle);font-size:13px;font-weight:600;color:var(--gold-light)">Live Site Builder</div>
        <div id="builderMessages" style="flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:14px"></div>
        <div style="padding:12px;border-top:1px solid var(--border-subtle);display:flex;gap:8px">
          <input id="builderInput" placeholder="Describe a change — tagline, banner, accent color..."
            style="flex:1;padding:10px 12px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:8px;font-size:13px"
            onkeydown="if(event.key==='Enter') sendBuilderMessage()">
          <button onclick="sendBuilderMessage()" style="padding:10px 16px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:8px;font-weight:600;cursor:pointer;font-size:13px">Send</button>
        </div>
      </div>
      <div id="builderPreviewPane" style="flex:1;display:flex;flex-direction:column">
        <div style="font-size:11px;color:var(--text-secondary);margin-bottom:8px;text-transform:uppercase;letter-spacing:0.05em">Live preview — this is the real site, not a mockup</div>
        <iframe id="builderPreviewFrame" src="/" style="flex:1;border:1px solid var(--border-subtle);border-radius:10px;background:var(--charcoal)"></iframe>
      </div>
    </div>`;
  renderBuilderMessages();
}

function renderBuilderMessages() {
  const container = document.getElementById('builderMessages');
  if (!builderHistory.length) {
    container.innerHTML = `<div class="empty-state" style="padding:20px 0"><div class="glyph">&mdash;</div>
      Tell me what to change — tagline, banner note, or accent color — and I'll update the real site.
      <br><span style="font-size:11px">The preview on the right is the actual live app, reloaded after each change.</span></div>`;
    return;
  }
  container.innerHTML = builderHistory.map(m => {
    const isUser = m.role === 'user';
    const body = isUser
      ? escapeHtml(m.content).replace(/\n/g, '<br>')
      : (window.marked ? marked.parse(m.content) : `<pre style="white-space:pre-wrap;margin:0;font-family:inherit">${escapeHtml(m.content)}</pre>`);
    return `
    <div style="align-self:${isUser ? 'flex-end' : 'flex-start'};max-width:${isUser ? '85%' : '100%'}">
      <div style="font-size:10px;text-transform:uppercase;color:var(--text-secondary);margin-bottom:4px;text-align:${isUser ? 'right' : 'left'}">${isUser ? 'You' : 'Builder'}</div>
      <div class="${isUser ? '' : 'workspace-markdown'}" style="background:${isUser ? 'var(--gold-light)' : 'var(--charcoal-light)'};color:${isUser ? 'var(--charcoal)' : 'var(--text-primary)'};padding:10px 14px;border-radius:12px;font-size:13px">${body}</div>
    </div>`;
  }).join('');
  container.scrollTop = container.scrollHeight;
}

async function sendBuilderMessage() {
  const input = document.getElementById('builderInput');
  const text = input.value.trim();
  if (!text) return;

  builderHistory.push({ role: 'user', content: text });
  input.value = '';
  renderBuilderMessages();
  builderHistory.push({ role: 'assistant', content: '...' });
  renderBuilderMessages();

  try {
    const res = await fetch('/workspace/builder/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: builderHistory.slice(0, -1) }),
    });
    const data = await res.json();
    builderHistory.pop();

    if (data.success) {
      builderHistory.push({ role: 'assistant', content: data.reply });
      // Real change actually landed - refresh the live preview iframe AND
      // this page's own header, since the change is genuinely site-wide.
      const frame = document.getElementById('builderPreviewFrame');
      if (frame) frame.src = '/?_=' + Date.now();
      applySiteSettings();
    } else {
      builderHistory.push({ role: 'assistant', content: `Error: ${data.error}` });
    }
  } catch (err) {
    builderHistory.pop();
    builderHistory.push({ role: 'assistant', content: `Error: ${err.message}` });
  }
  renderBuilderMessages();
}

// Reads the real, persisted site settings and applies them to THIS page's
// header/banner/accent color - called on every load, and again right after
// the Builder writes a change, so the change is visibly live immediately,
// not just in the preview iframe.
async function applySiteSettings() {
  try {
    const settings = await fetchJSON('/workspace/settings');
    const taglineEl = document.getElementById('siteTagline');
    if (taglineEl) taglineEl.textContent = settings.tagline;

    document.documentElement.style.setProperty('--gold-light', settings.accent_color);

    const bannerEl = document.getElementById('siteBanner');
    if (bannerEl) {
      bannerEl.innerHTML = settings.banner_note
        ? `<div style="padding:10px 28px;background:rgba(201,169,97,0.08);border-bottom:1px solid var(--border-subtle);color:var(--gold-light);font-size:13px">${escapeHtml(settings.banner_note)}</div>`
        : '';
    }
  } catch (err) {
    // Settings are cosmetic only - a fetch failure here should never block the app.
  }
}

// ---------------------------------------------------------------------------
// Per-agent direct chat - talk to Chris, Alex, or Taylor individually,
// same pattern as messaging one real team member directly instead of
// broadcasting to the whole Workspace Chat channel.
// ---------------------------------------------------------------------------

const AGENT_LABELS = { chris: 'Chris', alex: 'Alex', taylor: 'Taylor' };
let agentChatHistory = { chris: [], alex: [], taylor: [] };

function renderAgentChatTab(main, agentKey) {
  const label = AGENT_LABELS[agentKey];
  main.innerHTML = `
    <div style="max-width:700px">
      <div id="agentChatMessages" style="display:flex;flex-direction:column;gap:12px;margin-bottom:16px;min-height:200px"></div>
      <div style="display:flex;gap:8px">
        <input id="agentChatInput" placeholder="Message ${label} directly..."
          style="flex:1;padding:12px;background:var(--charcoal-light);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:8px"
          onkeydown="if(event.key==='Enter') sendAgentChatMessage('${agentKey}')">
        <button onclick="sendAgentChatMessage('${agentKey}')" style="padding:12px 20px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:8px;font-weight:600;cursor:pointer">Send</button>
      </div>
      <div style="display:flex;gap:8px;margin-top:10px;align-items:center">
        <input id="agentLessonInput" placeholder="Save a correction or lesson to the brain..."
          style="flex:1;padding:8px;background:var(--charcoal-light);border:1px solid var(--border-subtle);color:var(--text-secondary);border-radius:6px;font-size:12px">
        <button onclick="saveAgentLesson('${agentKey}')" style="padding:8px 14px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;font-size:12px;cursor:pointer">Save to Brain</button>
      </div>
      <div id="agentLessonStatus" style="font-size:11px;margin-top:6px"></div>
    </div>`;
  renderAgentChatMessages(agentKey);
}

function renderAgentChatMessages(agentKey) {
  const container = document.getElementById('agentChatMessages');
  const history = agentChatHistory[agentKey];
  const label = AGENT_LABELS[agentKey];
  if (!history.length) {
    container.innerHTML = `<div class="empty-state"><div class="glyph">&mdash;</div>
      Talk to ${label} directly — ask about a specific deal, give feedback, or correct something.
      <br><span style="font-size:11px">This chat resets on reload — use "Save to Brain" below for anything that should stick permanently.</span></div>`;
    return;
  }
  container.innerHTML = history.map(m => {
    const isUser = m.role === 'user';
    const body = isUser
      ? escapeHtml(m.content).replace(/\n/g, '<br>')
      : (window.marked ? marked.parse(m.content) : `<pre style="white-space:pre-wrap;margin:0;font-family:inherit">${escapeHtml(m.content)}</pre>`);
    return `
    <div style="align-self:${isUser ? 'flex-end' : 'flex-start'};max-width:${isUser ? '80%' : '92%'}">
      <div style="font-size:10px;text-transform:uppercase;color:var(--text-secondary);margin-bottom:4px;text-align:${isUser ? 'right' : 'left'}">${isUser ? 'You' : label}</div>
      <div class="${isUser ? '' : 'workspace-markdown'}" style="background:${isUser ? 'var(--gold-light)' : 'var(--charcoal-light)'};color:${isUser ? 'var(--charcoal)' : 'var(--text-primary)'};padding:12px 16px;border-radius:12px;font-size:14px">${body}</div>
    </div>`;
  }).join('');
  container.scrollTop = container.scrollHeight;
}

async function sendAgentChatMessage(agentKey) {
  const input = document.getElementById('agentChatInput');
  const text = input.value.trim();
  if (!text) return;

  agentChatHistory[agentKey].push({ role: 'user', content: text });
  input.value = '';
  renderAgentChatMessages(agentKey);
  agentChatHistory[agentKey].push({ role: 'assistant', content: '...' });
  renderAgentChatMessages(agentKey);

  try {
    const res = await fetch(`/agents/${agentKey}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: agentChatHistory[agentKey].slice(0, -1) }),
    });
    const data = await res.json();
    agentChatHistory[agentKey].pop();
    agentChatHistory[agentKey].push({ role: 'assistant', content: data.success ? data.reply : `Error: ${data.error}` });
  } catch (err) {
    agentChatHistory[agentKey].pop();
    agentChatHistory[agentKey].push({ role: 'assistant', content: `Error: ${err.message}` });
  }
  renderAgentChatMessages(agentKey);
}

async function saveAgentLesson(agentKey) {
  const input = document.getElementById('agentLessonInput');
  const statusEl = document.getElementById('agentLessonStatus');
  const lesson = input.value.trim();
  if (!lesson) return;

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Saving...</span>';
  try {
    const res = await fetch('/workspace/memory/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lesson: `[${AGENT_LABELS[agentKey].toUpperCase()}] ${lesson}` }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = '<span style="color:var(--status-green)">Saved to brain/memory/memory.md</span>';
      input.value = '';
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error || 'unknown'}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

// ---------------------------------------------------------------------------
// Chris views
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Chris — Hot Leads map. Real Leaflet map, real lat/lng from geocoding on
// intake (shared/geocode.py), pins colored by real status: locked (deal
// signed via /lock_deal), brief generated, or plain active lead. Leads that
// haven't been geocoded yet (older rows, or a geocode miss) are listed
// separately below the map rather than silently dropped.
// ---------------------------------------------------------------------------

async function runBackfillGeocode() {
  const statusEl = document.getElementById('backfillStatus');
  if (statusEl) statusEl.innerHTML = '<span style="color:var(--text-secondary)">Geocoding...</span>';
  try {
    const res = await fetch('/chris/leads/backfill_geocode', { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      if (statusEl) statusEl.innerHTML = `<span style="color:var(--status-green)">Updated ${data.updated} of ${data.checked} lead(s)${data.skipped.length ? ` — ${data.skipped.length} couldn't be matched` : ''}.</span>`;
      setTimeout(() => loadView(), 900);
    } else {
      if (statusEl) statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error || 'unknown'}</span>`;
    }
  } catch (err) {
    if (statusEl) statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

let _chrisLeafletMap = null;

function pinColor(lead) {
  if (lead.locked) return 'var(--status-green)';
  if (lead.brief_generated) return 'var(--gold-light)';
  if ((lead.status || '').toUpperCase() === 'DEAD') return 'var(--text-secondary)';
  return 'var(--status-amber)';
}

function renderChrisMap(main, leads) {
  const withCoords = leads.filter(l => l.lat != null && l.lng != null);
  const withoutCoords = leads.filter(l => l.lat == null || l.lng == null);

  main.innerHTML = `
    <div style="display:flex;gap:16px;margin-bottom:14px;flex-wrap:wrap">
      <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-secondary)"><span style="width:10px;height:10px;border-radius:50%;background:var(--status-green);display:inline-block"></span> Locked deal</div>
      <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-secondary)"><span style="width:10px;height:10px;border-radius:50%;background:var(--gold-light);display:inline-block"></span> Brief generated</div>
      <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-secondary)"><span style="width:10px;height:10px;border-radius:50%;background:var(--status-amber);display:inline-block"></span> Active lead</div>
      <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-secondary)"><span style="width:10px;height:10px;border-radius:50%;background:var(--text-secondary);display:inline-block"></span> Dead</div>
    </div>
    <div id="chrisMap" style="height:480px;border-radius:10px;border:1px solid var(--border-subtle);overflow:hidden"></div>
    ${withoutCoords.length ? `<div class="callout" style="margin-top:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
      <span>${withoutCoords.length} lead(s) not on the map yet — no coordinates on file (added before geocoding was wired up, or the address couldn't be matched). They're still fully visible on the Leads tab.</span>
      <button onclick="runBackfillGeocode()" style="padding:8px 14px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;font-size:12px;cursor:pointer;white-space:nowrap">Geocode Missing Leads</button>
    </div>
    <div id="backfillStatus" style="margin-top:8px;font-size:12px"></div>` : ''}
  `;

  if (!withCoords.length) {
    document.getElementById('chrisMap').outerHTML = emptyState('No geocoded leads yet — new leads are geocoded automatically on intake.');
    return;
  }

  if (_chrisLeafletMap) { _chrisLeafletMap.remove(); _chrisLeafletMap = null; }

  const map = L.map('chrisMap', { scrollWheelZoom: true });
  _chrisLeafletMap = map;

  // CartoDB's dark basemap - free, no API key, matches the charcoal/gold theme
  // far better than the default OSM light tiles would.
  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
    maxZoom: 19,
  }).addTo(map);

  const bounds = [];
  withCoords.forEach(lead => {
    const color = pinColor(lead);
    const marker = L.circleMarker([lead.lat, lead.lng], {
      radius: 8,
      color: '#1A1A1A',
      weight: 2,
      fillColor: color,
      fillOpacity: 0.9,
    }).addTo(map);

    const statusLine = lead.locked
      ? '<span style="color:var(--status-green)">Deal locked</span>'
      : lead.brief_generated
        ? '<span style="color:var(--gold-light)">Brief generated</span>'
        : `<span style="color:var(--text-secondary)">${lead.status || 'NEW'}</span>`;

    marker.bindPopup(`
      <div style="font-family:inherit;min-width:180px">
        <div style="font-weight:700;color:var(--gold-light);margin-bottom:2px">${lead.address}</div>
        <div style="font-size:12px;color:var(--text-secondary);margin-bottom:6px">${lead.city || ''}, ${lead.state || ''} ${lead.zip || ''}</div>
        <div style="font-size:12px;margin-bottom:2px">${statusLine}</div>
        ${lead.arv ? `<div style="font-size:12px">ARV: <b>$${Number(lead.arv).toLocaleString()}</b></div>` : ''}
        ${lead.deal_score != null ? `<div style="font-size:12px">Score: <b>${lead.deal_score}</b></div>` : ''}
      </div>
    `);
    bounds.push([lead.lat, lead.lng]);
  });

  map.fitBounds(bounds, { padding: [30, 30], maxZoom: 12 });
}

async function loadChrisView(main) {
  if (currentSubTab === 'chat') { renderAgentChatTab(main, 'chris'); return; }
  if (currentSubTab === 'map') {
    const { leads } = await fetchJSON('/chris/leads?limit=200');
    renderChrisMap(main, leads);
  } else if (currentSubTab === 'leads') {
    const { leads } = await fetchJSON('/chris/leads');
    const formHtml = `<div class="node-phase" style="margin-bottom:20px;max-width:500px">
      <h3>Add a Lead</h3>
      <div style="display:flex;flex-direction:column;gap:8px">
        <input id="newLeadAddress" placeholder="Address" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newLeadCity" placeholder="City" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newLeadZip" placeholder="ZIP" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newLeadOwnerName" placeholder="Owner name (optional)" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newLeadOwnerPhone" placeholder="Owner phone (optional)" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newLeadArv" placeholder="ARV (optional)" type="number" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <button onclick="submitNewLead()" style="padding:10px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;font-weight:600;cursor:pointer">Add Lead</button>
        <div id="newLeadStatus"></div>
      </div>
    </div>`;

    if (!leads.length) {
      main.innerHTML = formHtml + emptyState('No leads yet. Add one above, or wait for a scout run.');
      return;
    }
    main.innerHTML = formHtml + `<div id="leadsTableWrapper">${renderLeadsTable(leads)}</div>
    <div id="pullCompsStatus" style="margin-top:10px;font-size:12px"></div>
    <div id="setupCallStatus" style="margin-top:10px;font-size:12px"></div>
    <div id="briefContainer" style="margin-top:20px"></div>
    <div id="lockDealFormContainer" style="margin-top:16px"></div>`;
  } else if (currentSubTab === 'agents') {
    const { agents } = await fetchJSON('/chris/agents');
    const formHtml = `<div class="node-phase" style="margin-bottom:20px;max-width:500px">
      <h3>Add an Agent</h3>
      <div style="display:flex;flex-direction:column;gap:8px">
        <input id="newAgentName" placeholder="Name" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newAgentPhone" placeholder="Phone" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newAgentEmail" placeholder="Email (optional)" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newAgentBrokerage" placeholder="Brokerage (optional)" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <button onclick="submitNewAgent()" style="padding:10px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;font-weight:600;cursor:pointer">Add Agent</button>
        <div id="newAgentStatus"></div>
      </div>
    </div>`;

    if (!agents.length) {
      main.innerHTML = formHtml + emptyState('No agents yet. Add one above to start building your gatekeeper network.');
      return;
    }
    main.innerHTML = formHtml + `<table class="data-table">
      <tr><th>Name</th><th>Phone</th><th>Brokerage</th><th>Tier</th><th>Last Contact</th><th>Last Outcome</th><th></th><th></th></tr>
      ${agents.map(a => `<tr>
        <td>${a.name}</td>
        <td>${a.phone || '—'}</td>
        <td>${a.brokerage || '—'}</td>
        <td>${badge(a.tier, a.tier === 'TIER_1' ? 'green' : a.tier === 'TIER_2' ? 'amber' : a.tier === 'DEAD' ? 'red' : 'neutral')}</td>
        <td>${a.last_contact_at || 'Never'}</td>
        <td>${a.last_call_outcome || '—'}</td>
        <td>${a.phone ? `<button onclick="callAgent(${a.agent_id})" style="padding:6px 12px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;cursor:pointer;font-size:12px">Call via Brielle</button>` : '<span style="color:var(--text-secondary);font-size:11px">No phone</span>'}</td>
        <td>
          <select id="tierSelect${a.agent_id}" style="padding:4px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px;font-size:11px">
            <option value="TIER_1" ${a.tier === 'TIER_1' ? 'selected' : ''}>Tier 1</option>
            <option value="TIER_2" ${a.tier === 'TIER_2' ? 'selected' : ''}>Tier 2</option>
            <option value="TIER_3" ${a.tier === 'TIER_3' ? 'selected' : ''}>Tier 3</option>
            <option value="DEAD" ${a.tier === 'DEAD' ? 'selected' : ''}>Dead</option>
          </select>
          <button onclick="doTransitionTier(${a.agent_id})" style="padding:4px 10px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;cursor:pointer;font-size:11px">Update</button>
        </td>
      </tr>`).join('')}
    </table>
    <div id="agentCallStatus" style="margin-top:12px;font-size:12px"></div>
    <div id="tierTransitionStatus" style="margin-top:6px;font-size:12px"></div>`;
  } else if (currentSubTab === 'kpi') {
    const { kpi } = await fetchJSON('/chris/kpi');
    if (!kpi) { main.innerHTML = emptyState('No KPI data for today yet.'); return; }
    main.innerHTML = kpiRow([
      ['Leads Today', kpi.leads_today], ['Conversations', kpi.conversations_today],
      ['Offers', kpi.offers_today], ['Contracts', kpi.contracts_today],
      ['FB Ad Leads', kpi.fb_ad_leads], ['FSBO Leads', kpi.fsbo_leads],
      ['Scout Leads', kpi.scout_leads], ['Mat Beard Touches', kpi.mat_beard_touches],
    ]) + `
    <div class="node-phase" style="margin-top:16px">
      <h3>Pipeline Pressure</h3>
      <div style="display:flex;justify-content:space-around;flex-wrap:wrap;gap:16px;padding-top:8px">
        ${gaugeSVG(kpi.leads_today, 20, 'LEADS TODAY', kpi.leads_today > 0 ? 'Nominal' : 'Quiet', kpi.leads_today > 0 ? 'var(--status-green)' : 'var(--text-secondary)')}
        ${gaugeSVG(kpi.speed_to_lead_breaches, 5, 'SPEED-TO-LEAD BREACHES', !kpi.speed_to_lead_breaches ? 'Clear' : 'Attention', !kpi.speed_to_lead_breaches ? 'var(--status-green)' : 'var(--status-red)')}
        ${gaugeSVG(kpi.ceo_alerts_fired, 5, 'CEO ALERTS FIRED', !kpi.ceo_alerts_fired ? 'Clear' : 'Review', !kpi.ceo_alerts_fired ? 'var(--status-green)' : 'var(--status-amber)')}
      </div>
    </div>`;
  } else if (currentSubTab === 'conversion') {
    const stats = await fetchJSON('/chris/conversion');
    main.innerHTML = kpiRow([
      ['Total Leads', stats.total_leads], ['Active', stats.active],
      ['High Motivation', stats.high_motivation], ['Contracts', stats.contracts],
    ]) + `
    <div class="node-phase" style="margin-top:16px">
      <h3>Conversion by Source</h3>
      <table class="data-table">
        <tr><th>Source</th><th>Total</th><th>Active</th><th>Contracts</th><th>Conv %</th></tr>
        ${stats.by_source.map(s => `<tr>
          <td>${s.source}</td><td>${s.total}</td><td>${s.active}</td><td>${s.contracts}</td>
          <td>${s.total ? ((s.contracts / s.total) * 100).toFixed(1) : '0.0'}%</td>
        </tr>`).join('')}
      </table>
    </div>`;
  } else if (currentSubTab === 'outreach') {
    const stats = await fetchJSON('/chris/outreach_summary');
    main.innerHTML = kpiRow([
      ['Total Agents', stats.total_agents], ['Touches Sent', stats.touches_sent],
      ['Replies', stats.replies], ['Dead', stats.dead],
    ]) + `
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:16px" class="fp-network-grid">
      <div class="kpi-card"><div class="kpi-label">Tier 1 — Hot</div><div class="kpi-value" style="color:var(--status-green)">${stats.tier_1}</div></div>
      <div class="kpi-card"><div class="kpi-label">Tier 2 — Warm</div><div class="kpi-value" style="color:var(--status-amber)">${stats.tier_2}</div></div>
      <div class="kpi-card"><div class="kpi-label">Tier 3 — Nurture</div><div class="kpi-value" style="color:var(--text-secondary)">${stats.tier_3}</div></div>
    </div>`;
  } else if (currentSubTab === 'd2s') {
    const { leads } = await fetchJSON('/chris/d2s');
    if (!leads.length) { main.innerHTML = emptyState('No direct-to-seller leads yet.'); return; }
    main.innerHTML = `<table class="data-table">
      <tr><th>Property</th><th>Owner</th><th>Source</th><th>Status</th><th>ARV</th><th>Motivation</th><th>F/U Step</th></tr>
      ${leads.map(l => `<tr>
        <td>${l.address}<div style="font-size:11px;color:var(--text-secondary)">${l.city || ''}, ${l.state || ''}</div></td>
        <td>${l.owner_name || '—'}</td>
        <td>${l.source}</td>
        <td>${badge(l.status, statusBadgeKind(l.status))}</td>
        <td>${l.arv ? '$' + Number(l.arv).toLocaleString() : '—'}</td>
        <td style="font-size:12px;${l.motivation === 'HIGH' ? 'color:var(--status-green)' : 'color:var(--text-secondary)'}">${l.motivation_reason || l.motivation || '—'}</td>
        <td>${l.follow_up_step || '—'}</td>
      </tr>`).join('')}
    </table>`;
  } else if (currentSubTab === 'structuring') {
    const { leads } = await fetchJSON('/chris/structuring');
    if (!leads.length) { main.innerHTML = emptyState('No leads with an ARV on file yet — Structuring needs a valuation to compute the offer ladder.'); return; }
    main.innerHTML = leads.map(l => `
      <div class="node-phase" style="border-left:4px solid var(--status-green);margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
          <span style="font-weight:700;color:var(--gold-light);font-size:12px;letter-spacing:0.04em">${l.exit_strategy.replace(/_/g, ' ')}</span>
          <div style="text-align:right"><div class="numeral" style="font-size:20px;color:var(--status-green)">$${Number(l.t1).toLocaleString()}</div><div style="font-size:10px;color:var(--text-secondary);text-transform:uppercase">T1 Offer</div></div>
        </div>
        <div style="font-weight:700;margin-top:8px">${l.address}</div>
        <div style="font-size:12px;color:var(--text-secondary)">${l.city || ''}, ${l.state || ''} · ${l.owner_name || '—'}</div>
        <div style="display:flex;gap:16px;margin-top:10px;font-size:12px;flex-wrap:wrap">
          <span>T1: <b style="color:var(--text-primary)">$${Number(l.t1).toLocaleString()}</b></span>
          <span>T2: <b style="color:var(--text-primary)">$${Number(l.t2).toLocaleString()}</b></span>
          <span>T3: <b style="color:var(--text-primary)">$${Number(l.t3).toLocaleString()}</b></span>
          <span>MAO ceiling: <b style="color:var(--gold-light)">$${Number(l.mao_ceiling).toLocaleString()}</b></span>
        </div>
        <div style="font-size:12px;color:var(--text-secondary);margin-top:6px">ARV: $${Number(l.arv).toLocaleString()} · Repairs est: $${Number(l.repairs_estimate).toLocaleString()}</div>
      </div>
    `).join('');
  } else if (currentSubTab === 'scouts') {
    const { scout_runs } = await fetchJSON('/chris/scout_runs');
    if (!scout_runs.length) { main.innerHTML = emptyState('No scout runs logged yet.'); return; }
    main.innerHTML = `<table class="data-table">
      <tr><th>Module</th><th>Ran At</th><th>Raw</th><th>In-Market</th><th>New Leads</th><th>Status</th></tr>
      ${scout_runs.map(r => `<tr>
        <td>${r.module}</td><td>${r.run_at}</td><td>${r.raw_results}</td>
        <td>${r.in_market_results}</td><td>${r.new_leads}</td>
        <td>${badge(r.portal_status, r.portal_status === 'OK' ? 'green' : 'red')}</td>
      </tr>`).join('')}
    </table>`;
  }
}

// ---------------------------------------------------------------------------
// Alex views
// ---------------------------------------------------------------------------

async function loadAlexView(main) {
  if (currentSubTab === 'chat') { renderAgentChatTab(main, 'alex'); return; }
  if (currentSubTab === 'deals') {
    const { deals } = await fetchJSON('/alex/deals');
    if (!deals.length) { main.innerHTML = emptyState('No deals in the pipeline yet — waiting on a handoff from Chris.'); return; }
    window._alexDeals = deals;

    let fpOptions = '';
    try {
      const { financial_partners } = await fetchJSON('/alex/financial_partners');
      window._fpDataForAssign = financial_partners;
      fpOptions = financial_partners.map((fp, i) => `<option value="${i}">${fp.entity_name}</option>`).join('');
    } catch (err) { /* fp list optional here */ }

    const EXIT_STRATEGIES = ['WHOLESALE_ASSIGNMENT', 'SUBTO', 'NOVATION', 'JUNIOR_BROKERAGE'];
    const EXIT_LABELS = { WHOLESALE_ASSIGNMENT: 'WHOLESALE', SUBTO: 'SUB-TO', NOVATION: 'NOVATION', JUNIOR_BROKERAGE: 'LAND' };
    const borderColor = (d) => d.dispo_status === 'CLOSED' ? 'var(--status-green)' : d.risk_tier === 'PROTECT_SPREAD' ? 'var(--status-red)' : 'var(--gold-light)';

    main.innerHTML = deals.map((d, i) => `
      <div class="node-phase" style="border-left:4px solid ${borderColor(d)};margin-bottom:14px">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
          <div style="display:flex;gap:8px;align-items:center">
            ${badge(d.dispo_status, statusBadgeKind(d.dispo_status))}
            ${d.risk_tier === 'PROTECT_SPREAD' ? badge('PROTECT SPREAD', 'red') : ''}
          </div>
          ${d.fp_facing_price ? `<div style="text-align:right"><div class="numeral" style="font-size:20px;color:var(--gold-light)">$${Number(d.fp_facing_price).toLocaleString()}</div><div style="font-size:10px;color:var(--text-secondary);text-transform:uppercase">FP Offer</div></div>` : ''}
        </div>

        <div style="font-weight:700;margin-top:10px">${d.address}</div>
        <div style="font-size:12px;color:var(--text-secondary)">Dispo Day ${d.dispo_day ?? 0} / 5${d.fp_assigned_id ? ' · <span style="color:var(--status-green)">FP assigned</span>' : ' · <span style="color:var(--text-secondary)">Unassigned</span>'}</div>

        <div class="exit-strategy-grid" style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:12px">
          ${EXIT_STRATEGIES.map(s => `
            <div style="background:var(--charcoal-lighter);border-radius:6px;padding:8px 10px;${d.exit_strategy === s ? `border:1px solid var(--gold-light)` : ''}">
              <div style="font-size:10px;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.04em">${EXIT_LABELS[s]}</div>
              <div style="font-size:13px;margin-top:2px;color:${d.exit_strategy === s ? 'var(--gold-light)' : 'var(--text-secondary)'}">${d.exit_strategy === s ? (d.contract_price ? '$' + Number(d.contract_price).toLocaleString() : 'Selected') : 'N/A'}</div>
            </div>
          `).join('')}
        </div>

        ${d.contract_price || d.assignment_fee_target ? `<div style="font-size:12px;color:var(--text-secondary);margin-top:10px">
          ${d.contract_price ? `Contract: <b style="color:var(--text-primary)">$${Number(d.contract_price).toLocaleString()}</b>` : ''}
          ${d.assignment_fee_target ? ` · Target fee: <b style="color:var(--text-primary)">$${Number(d.assignment_fee_target).toLocaleString()}</b>` : ''}
        </div>` : ''}

        <div style="margin-top:12px">
          ${!d.fp_assigned_id ? `
            <select id="fpSelect${d.deal_id}" style="padding:6px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px;font-size:12px">
              <option value="">Pick FP...</option>${fpOptions}
            </select>
            <button onclick="doAssignFP(${d.deal_id}, ${i})" style="padding:6px 12px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;cursor:pointer;font-size:12px;margin-left:6px">Assign</button>
          ` : `
            <button onclick="showTaylorHandoffForm(${d.deal_id})" style="padding:6px 12px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600">Hand off to Taylor</button>
          `}
        </div>
      </div>
    `).join('') + `
    <div id="alexActionStatus" style="margin-top:12px;font-size:12px"></div>
    <div id="taylorHandoffFormContainer" style="margin-top:16px"></div>`;
  } else if (currentSubTab === 'five_day_board') {
    const { deals } = await fetchJSON('/alex/five_day_board');
    if (!deals.length) { main.innerHTML = emptyState('No deals actively in the 5-Day Dispo process right now.'); return; }

    main.innerHTML = deals.map(d => `
      <div class="node-phase" style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:10px">
          <h3 style="margin:0">${d.address}</h3>
          <span class="numeral" style="color:var(--gold-light)">${d.fp_facing_price ? '$' + Number(d.fp_facing_price).toLocaleString() : ''}</span>
        </div>
        <div class="pipeline-nodes" style="margin-bottom:10px">
          ${[0,1,2,3,4,5].map(day => `
            <div class="pipeline-node-wrap">
              <div class="pipeline-node ${day < d.dispo_day ? 'done' : day === d.dispo_day ? 'in_progress' : 'pending'}">
                ${day < d.dispo_day ? '✓' : day}
                <div class="pipeline-node-tooltip">Day ${day}</div>
              </div>
              ${day < 5 ? `<div class="pipeline-connector ${day < d.dispo_day ? 'done' : ''}"></div>` : ''}
            </div>
          `).join('')}
        </div>
        <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:12px;color:var(--text-secondary)">
          <span>TTB: <span style="color:${d.ttb_target_met ? 'var(--status-green)' : 'var(--status-amber)'}">${d.ttb_hours ? d.ttb_hours.toFixed(1) + 'h' : 'not blasted yet'}</span></span>
          <span>Walkthrough interest: ${d.walkthrough_interested_count || 0}</span>
          <span>Magic question asked: ${d.magic_question_asked ? 'Yes' : 'Not yet'}</span>
          <span>FOMO texts sent: ${d.fomo_texts_sent_count || 0}</span>
        </div>
      </div>
    `).join('');
  } else if (currentSubTab === 'fp_network') {
    const { financial_partners } = await fetchJSON('/alex/financial_partners');
    if (!financial_partners.length) { main.innerHTML = emptyState('No financial partners loaded yet.'); return; }
    window._fpData = financial_partners;

    // Group by real market state (MD/FL/NC) using preferred_states (a JSON
    // array on each FP row). A partner covering multiple states appears in
    // each column they actually cover; partners with no state data on file
    // fall into an "Unassigned" column rather than being silently dropped.
    const STATE_LABELS = { MD: 'Maryland', FL: 'Florida', NC: 'North Carolina' };
    const groups = { MD: [], FL: [], NC: [], OTHER: [] };
    financial_partners.forEach((fp, i) => {
      let states = [];
      try { states = fp.preferred_states ? JSON.parse(fp.preferred_states) : []; } catch (e) { states = []; }
      const matched = states.filter(s => groups[s] !== undefined);
      (matched.length ? matched : ['OTHER']).forEach(s => groups[s].push(i));
    });

    const fpCard = (fp, i) => `
      <div onclick="showFPDetail(${i})" class="node-phase" style="cursor:pointer;margin-bottom:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
          <span style="font-weight:700;font-size:13px">${fp.entity_name}</span>
          <div style="display:flex;gap:4px;flex-shrink:0">
            ${badge(fp.relationship_stage, statusBadgeKind(fp.relationship_stage))}
            <span class="tier-${(fp.dispo_tier || 'c').toLowerCase()}" style="font-size:11px;padding:2px 7px;border-radius:5px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle)">${fp.dispo_tier || 'C'}</span>
          </div>
        </div>
        <div style="font-size:12px;color:var(--text-secondary);margin-top:2px">${fp.contact_name || '—'}</div>
        <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-secondary);margin-top:8px">
          <span>Rep: <b style="color:var(--text-primary)">${fp.reputation_score ?? 50}</b></span>
          <span>Deals: <b style="color:var(--text-primary)">${fp.total_deals_closed ?? 0}</b></span>
          <span>${fp.capacity_max ? '$' + Number(fp.capacity_max).toLocaleString() : '—'}</span>
        </div>
      </div>`;

    main.innerHTML = `<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px" class="fp-network-grid">
      ${['MD', 'FL', 'NC'].map(s => `
        <div>
          <div style="font-size:12px;font-weight:700;letter-spacing:0.05em;text-transform:uppercase;color:var(--text-primary);margin-bottom:10px">
            ${STATE_LABELS[s]} <span style="color:var(--text-secondary);font-weight:400">· ${groups[s].length} buyer${groups[s].length === 1 ? '' : 's'}</span>
          </div>
          ${groups[s].length ? groups[s].map(i => fpCard(financial_partners[i], i)).join('') : `<div style="font-size:12px;color:var(--text-secondary)">No coverage here yet.</div>`}
        </div>
      `).join('')}
    </div>
    ${groups.OTHER.length ? `<div style="margin-top:20px">
      <div style="font-size:12px;font-weight:700;letter-spacing:0.05em;text-transform:uppercase;color:var(--text-secondary);margin-bottom:10px">Unassigned state · ${groups.OTHER.length}</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px" class="fp-network-grid">${groups.OTHER.map(i => fpCard(financial_partners[i], i)).join('')}</div>
    </div>` : ''}
    <div id="fpDetailContainer" style="margin-top:20px"></div>`;
  } else if (currentSubTab === 'kpi') {
    const { kpi } = await fetchJSON('/alex/kpi');
    if (!kpi) { main.innerHTML = emptyState('No KPI data yet.'); return; }
    main.innerHTML = kpiRow([
      ['Active OWN', kpi.active_deals_own], ['Active JV', kpi.active_deals_jv],
      ['Avg DOM', kpi.avg_days_on_market], ['FP Touches Today', kpi.fp_touches_today],
      ['Avg TTB (hrs)', kpi.avg_ttb_hours], ['TTB Breaches', kpi.ttb_breaches],
      ['Tier A', kpi.tier_a_count], ['Tier B', kpi.tier_b_count], ['Tier C', kpi.tier_c_count],
    ]);
  } else if (currentSubTab === 'alerts') {
    await renderAlerts(main, '/alex/ceo_alerts');
  }
}

// ---------------------------------------------------------------------------
// Taylor views
// ---------------------------------------------------------------------------

async function loadTaylorView(main) {
  if (currentSubTab === 'chat') { renderAgentChatTab(main, 'taylor'); return; }
  if (currentSubTab === 'closings') {
    const { closings } = await fetchJSON('/taylor/closings');
    if (!closings.length) { main.innerHTML = emptyState('No closings in the pipeline yet — waiting on a handoff from Alex.'); return; }
    main.innerHTML = closings.map(c => {
      const pct = Math.round((c.current_node / 36) * 100);
      const barColor = c.risk_tier === 'PROTECT_SPREAD' ? 'var(--status-red)' : 'var(--gold-light)';
      return `
      <div onclick="loadNodeBoard(${c.closing_id})" class="node-phase" style="cursor:pointer;margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
          <span style="font-weight:700">${c.address}</span>
          <div style="display:flex;gap:6px">
            ${badge(c.status, statusBadgeKind(c.status), isLiveStatus(c.status))}
            ${badge(c.risk_tier, c.risk_tier === 'PROTECT_SPREAD' ? 'red' : 'green')}
          </div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-secondary);margin:8px 0 4px">
          <span>Node ${c.current_node} of 36</span>
          <span>Target close: ${c.close_date_target || '—'}</span>
        </div>
        <div style="width:100%;height:6px;background:var(--charcoal-lighter);border-radius:3px;overflow:hidden">
          <div style="width:${pct}%;height:100%;background:${barColor}"></div>
        </div>
      </div>`;
    }).join('') + `<div id="nodeBoardContainer" style="margin-top:20px"></div>`;
  } else if (currentSubTab === 'emd') {
    const { emd_records } = await fetchJSON('/taylor/emd');
    if (!emd_records.length) { main.innerHTML = emptyState('No EMD records yet.'); return; }
    main.innerHTML = emd_records.map(e => `
      <div class="node-phase" style="margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
          <span style="font-weight:700">${e.address}</span>
          ${badge(e.refundable_status, e.refundable_status === 'RELEASED' ? 'green' : e.refundable_status === 'HELD' ? 'amber' : 'neutral')}
        </div>
        <div style="display:flex;gap:20px;margin-top:10px;flex-wrap:wrap;font-size:13px">
          <div><div style="font-size:10px;color:var(--text-secondary);text-transform:uppercase">Expected</div><div style="color:var(--gold-light);font-weight:700">${e.expected_amount ? '$' + Number(e.expected_amount).toLocaleString() : '—'}</div></div>
          <div><div style="font-size:10px;color:var(--text-secondary);text-transform:uppercase">Received</div><div>${e.received_amount ? '$' + Number(e.received_amount).toLocaleString() : '—'}</div></div>
          <div><div style="font-size:10px;color:var(--text-secondary);text-transform:uppercase">Tier</div><div>${e.emd_tier ? e.emd_tier + '-day' : '—'}</div></div>
          <div><div style="font-size:10px;color:var(--text-secondary);text-transform:uppercase">Non-Refundable</div><div style="color:var(--status-red)">${e.non_refundable_portion ? '$' + Number(e.non_refundable_portion).toLocaleString() : '—'}</div></div>
        </div>
      </div>
    `).join('');
  } else if (currentSubTab === 'alerts') {
    await renderAlerts(main, '/taylor/ceo_alerts');
  }
}

async function loadNodeBoard(closingId) {
  const container = document.getElementById('nodeBoardContainer');
  container.innerHTML = '<div class="loading">Loading pipeline...</div>';
  const { nodes } = await fetchJSON(`/taylor/closings/${closingId}/nodes`);

  const phases = {};
  nodes.forEach(n => { (phases[n.phase] ||= []).push(n); });

  const doneCount = nodes.filter(n => n.status === 'done').length;

  container.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:16px">
      <div style="font-size:11px;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.05em">Closing Pipeline</div>
      <div class="numeral" style="font-size:15px;color:var(--gold-light)">${doneCount} / 36</div>
    </div>
    <div class="pipeline-track">
      ${Object.entries(phases).map(([phase, phaseNodes]) => `
        <div>
          <div class="pipeline-phase-label">${phase.replace(/_/g, ' ')}</div>
          <div class="pipeline-nodes">
            ${phaseNodes.map((n, i) => `
              <div class="pipeline-node-wrap">
                <div class="pipeline-node ${n.status}">
                  ${n.status === 'done' ? '✓' : n.node_number}
                  <div class="pipeline-node-tooltip">${n.node_number}. ${n.title}${n.blocking_reason ? ' — ' + n.blocking_reason : ''}</div>
                </div>
                ${i < phaseNodes.length - 1 ? `<div class="pipeline-connector ${n.status === 'done' ? 'done' : ''}"></div>` : ''}
              </div>
            `).join('')}
          </div>
        </div>
      `).join('')}
    </div>`;
}

function showFPDetail(index) {
  const fp = window._fpData[index];
  const container = document.getElementById('fpDetailContainer');

  container.innerHTML = `<div class="node-phase" style="max-width:400px">
    <h3>${fp.entity_name}</h3>
    <div style="display:flex;flex-direction:column;gap:8px;margin:10px 0">
      <label style="font-size:11px;color:var(--text-secondary)">Phone</label>
      <input id="fpEditPhone" value="${fp.phone || ''}" placeholder="No phone on file"
        style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Email</label>
      <input id="fpEditEmail" value="${fp.email || ''}" placeholder="No email on file"
        style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <button onclick="saveFPContact(${fp.fp_id}, ${index})" style="padding:8px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;font-weight:600;cursor:pointer;font-size:12px">Save Contact Info</button>
      <div id="fpContactStatus" style="font-size:11px"></div>
    </div>
    <div class="node-row"><span>VIP Tier</span>${badge(fp.vip_tier, fp.vip_tier === 'VIP' ? 'green' : fp.vip_tier === 'WARM' ? 'amber' : 'neutral')}</div>
    <div class="node-row"><span>Dispo Tier</span><span class="tier-${(fp.dispo_tier || 'c').toLowerCase()}">${fp.dispo_tier || 'C'}</span></div>
    <div class="node-row"><span>Relationship</span>${badge(fp.relationship_stage, statusBadgeKind(fp.relationship_stage))}</div>
    <div class="node-row"><span>Deals Closed</span><span>${fp.total_deals_closed}</span></div>
  </div>`;
}

async function saveFPContact(fpId, index) {
  const statusEl = document.getElementById('fpContactStatus');
  const phone = document.getElementById('fpEditPhone').value.trim();
  const email = document.getElementById('fpEditEmail').value.trim();

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Saving...</span>';
  try {
    const res = await fetch(`/alex/financial_partners/${fpId}/update_contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email || null, phone: phone || null }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = '<span style="color:var(--status-green)">Saved.</span>';
      // Update the in-memory copy so the table reflects it without a full reload
      if (window._fpData && window._fpData[index]) {
        window._fpData[index].phone = phone || null;
        window._fpData[index].email = email || null;
      }
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

// ---------------------------------------------------------------------------
// Shared render helpers
// ---------------------------------------------------------------------------

async function generateBrief(leadId) {
  const container = document.getElementById('briefContainer');
  container.innerHTML = '<div class="loading">Drafting brief with Claude - this takes a few seconds...</div>';

  try {
    const res = await fetch(`/chris/leads/${leadId}/generate_brief`, { method: 'POST' });
    const data = await res.json();

    if (!data.success) {
      container.innerHTML = `<div class="node-phase"><h3 style="color:var(--status-red)">Could not generate brief</h3><p>${data.error}</p></div>`;
      return;
    }

    const warningsHtml = data.warnings.length
      ? `<div style="margin-bottom:12px">${data.warnings.map(w => badge(w, 'amber')).join(' ')}</div>`
      : '';

    const renderedBrief = window.marked ? marked.parse(data.brief) : `<pre style="white-space:pre-wrap">${data.brief}</pre>`;

    container.innerHTML = `<div class="node-phase" style="max-width:800px">
      ${warningsHtml}
      <div class="brief-content">${renderedBrief}</div>
    </div>`;

    // Refresh the leads table so Lock Deal's visibility reflects real
    // current state immediately, rather than staying stale until some
    // unrelated action happens to trigger a reload.
    loadView();
  } catch (err) {
    container.innerHTML = `<div class="node-phase"><h3 style="color:var(--status-red)">Error</h3><p>${err.message}</p></div>`;
  }
}

function showLockDealForm(leadId) {
  const container = document.getElementById('lockDealFormContainer');
  container.innerHTML = `<div class="node-phase" style="max-width:500px">
    <h3>Lock Deal</h3>
    <div style="display:flex;flex-direction:column;gap:8px">
      <label style="font-size:11px;color:var(--text-secondary)">Contract Price (agreed with seller)</label>
      <input id="lockContractPrice" type="number" placeholder="75000" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Purchase Agreement Document URL</label>
      <input id="lockPurchaseAgreementUrl" placeholder="https://..." style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Assignment Fee Target</label>
      <input id="lockAssignmentFee" type="number" value="15000" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Exit Strategy</label>
      <select id="lockExitStrategy" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <option value="WHOLESALE_ASSIGNMENT">Wholesale Assignment</option>
        <option value="NOVATION">Novation</option>
        <option value="DOUBLE_CLOSE">Double Close</option>
      </select>
      <button onclick="submitLockDeal(${leadId})" style="padding:10px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;font-weight:600;cursor:pointer">Lock Deal &amp; Hand Off to Alex</button>
      <div id="lockDealStatus"></div>
    </div>
  </div>`;
}

async function submitLockDeal(leadId) {
  const statusEl = document.getElementById('lockDealStatus');
  const contract_price = Number(document.getElementById('lockContractPrice').value);
  const purchase_agreement_doc_url = document.getElementById('lockPurchaseAgreementUrl').value.trim();
  const assignment_fee_target = Number(document.getElementById('lockAssignmentFee').value) || 15000;
  const exit_strategy = document.getElementById('lockExitStrategy').value;

  if (!contract_price || !purchase_agreement_doc_url) {
    statusEl.innerHTML = '<span style="color:var(--status-red)">Contract price and purchase agreement URL are required.</span>';
    return;
  }

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Locking deal...</span>';
  try {
    const res = await fetch(`/chris/leads/${leadId}/lock_deal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contract_price, purchase_agreement_doc_url, assignment_fee_target, exit_strategy }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = `<span style="color:var(--status-green)">Locked — handed off to Alex as deal #${data.alex_deal_id}.</span>`;
      setTimeout(() => loadView(), 1500);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

async function doAssignFP(dealId, dealIndex) {
  const statusEl = document.getElementById('alexActionStatus');
  const select = document.getElementById(`fpSelect${dealId}`);
  const fpIndex = select.value;
  if (fpIndex === '') {
    statusEl.innerHTML = '<span style="color:var(--status-red)">Pick a financial partner first.</span>';
    return;
  }
  const fp = window._fpDataForAssign[fpIndex];

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Assigning...</span>';
  try {
    const res = await fetch(`/alex/deals/${dealId}/assign_fp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fp_id: fp.fp_id }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = `<span style="color:var(--status-green)">Assigned ${data.fp_name}.</span>`;
      setTimeout(() => loadView(), 800);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

function showTaylorHandoffForm(dealId) {
  const container = document.getElementById('taylorHandoffFormContainer');
  container.innerHTML = `<div class="node-phase" style="max-width:500px">
    <h3>Hand Off to Taylor</h3>
    <div style="display:flex;flex-direction:column;gap:8px">
      <label style="font-size:11px;color:var(--text-secondary)">EMD Amount</label>
      <input id="handoffEmdAmount" type="number" placeholder="5000" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">EMD Received Date</label>
      <input id="handoffEmdDate" type="date" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Target Close Date</label>
      <input id="handoffCloseDate" type="date" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Assignment Agreement URL</label>
      <input id="handoffAssignmentUrl" placeholder="https://..." style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Photos Package URL</label>
      <input id="handoffPhotosUrl" placeholder="https://..." style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <button onclick="submitTaylorHandoff(${dealId})" style="padding:10px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;font-weight:600;cursor:pointer">Send to Taylor</button>
      <div id="taylorHandoffStatus"></div>
    </div>
  </div>`;
}

async function submitTaylorHandoff(dealId) {
  const statusEl = document.getElementById('taylorHandoffStatus');
  const emd_amount = Number(document.getElementById('handoffEmdAmount').value);
  const emd_received_at = document.getElementById('handoffEmdDate').value;
  const close_date_target = document.getElementById('handoffCloseDate').value;
  const assignment_signed_doc_url = document.getElementById('handoffAssignmentUrl').value.trim();
  const photos_package_url = document.getElementById('handoffPhotosUrl').value.trim();

  if (!emd_amount || !emd_received_at || !close_date_target || !assignment_signed_doc_url || !photos_package_url) {
    statusEl.innerHTML = '<span style="color:var(--status-red)">All fields are required.</span>';
    return;
  }

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Sending to Taylor...</span>';
  try {
    const res = await fetch(`/alex/deals/${dealId}/handoff_to_taylor`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ emd_amount, emd_received_at, close_date_target, assignment_signed_doc_url, photos_package_url }),
    });
    const data = await res.json();
    if (data.success) {
      let msg = `Handed off — Taylor closing ID ${data.taylor_closing_id}.`;
      if (data.warning) msg += ` Warning: ${data.warning}`;
      statusEl.innerHTML = `<span style="color:var(--status-green)">${msg}</span>`;
      setTimeout(() => loadView(), 1500);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

async function doTransitionTier(agentId) {
  const statusEl = document.getElementById('tierTransitionStatus');
  const select = document.getElementById(`tierSelect${agentId}`);
  const requested_tier = select.value;

  let address = null, city = null, zip_code = null;
  if (requested_tier === 'TIER_1') {
    address = prompt('Address the agent gave you (leave blank if just updating status, no new property):');
    if (address) {
      city = prompt('City:');
      zip_code = prompt('ZIP code:');
    }
  }

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Updating...</span>';
  try {
    const res = await fetch(`/chris/agents/${agentId}/transition_tier`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ requested_tier, reason: 'Manual update from dashboard', address, city, zip_code }),
    });
    const data = await res.json();
    if (data.success) {
      let msg = data.corrected
        ? `Requested ${requested_tier}, but a hard rule corrected it to ${data.resulting_tier} — this agent previously reached Tier 1 and can't be demoted back to Tier 3.`
        : `Updated to ${data.resulting_tier}.`;
      if (data.lead_id) msg += ` New lead created (#${data.lead_id}) — check the Leads tab.`;
      if (data.lead_warning) msg += ` Note: ${data.lead_warning}`;
      statusEl.innerHTML = `<span style="color:${data.corrected || data.lead_warning ? 'var(--status-amber)' : 'var(--status-green)'}">${msg}</span>`;
      setTimeout(() => loadView(), 2500);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

async function submitNewAgent() {
  const statusEl = document.getElementById('newAgentStatus');
  const name = document.getElementById('newAgentName').value.trim();
  const phone = document.getElementById('newAgentPhone').value.trim();
  const email = document.getElementById('newAgentEmail').value.trim();
  const brokerage = document.getElementById('newAgentBrokerage').value.trim();

  if (!name || !phone) {
    statusEl.innerHTML = '<span style="color:var(--status-red)">Name and phone are required.</span>';
    return;
  }

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Adding...</span>';
  try {
    const res = await fetch('/chris/agents/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, phone, email: email || null, brokerage: brokerage || null }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = '<span style="color:var(--status-green)">Added.</span>';
      setTimeout(() => loadView(), 800);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

async function callAgent(agentId) {
  const statusEl = document.getElementById('agentCallStatus');
  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Dialing via Brielle...</span>';
  try {
    const res = await fetch(`/chris/agents/${agentId}/call`, { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = `<span style="color:var(--status-green)">Call started (Vapi call ID: ${data.vapi_call_id}).</span>`;
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

function scoreGrade(score) {
  if (score == null) return { letter: '—', color: 'var(--text-secondary)' };
  if (score >= 80) return { letter: 'A', color: 'var(--status-green)' };
  if (score >= 60) return { letter: 'B', color: 'var(--gold-light)' };
  if (score >= 40) return { letter: 'C', color: 'var(--status-amber)' };
  return { letter: 'D', color: 'var(--status-red)' };
}

function leadTagChips(l) {
  const tags = [];
  if (l.risk_tier === 'PROTECT_SPREAD') tags.push('Protect spread');
  if (l.mortgage_balance === 0) tags.push('Free & clear');
  if (l.distress_score != null) tags.push(`Distress ${l.distress_score}/10`);
  if (l.motivation) tags.push(`${l.motivation} motivation`);
  if (l.locked) tags.push('Deal locked');
  else if (l.brief_generated) tags.push('Brief generated');
  if (l.is_test_data) tags.push('Test data');
  return tags;
}

function renderLeadsTable(leads) {
  return leads.map(l => {
    const grade = scoreGrade(l.deal_score);
    const tags = leadTagChips(l);
    return `
    <div class="node-phase" style="display:flex;gap:16px;align-items:flex-start;margin-bottom:12px">
      <div style="width:56px;height:56px;border-radius:50%;border:2px solid ${grade.color};display:flex;flex-direction:column;align-items:center;justify-content:center;flex-shrink:0">
        <span style="font-size:18px;font-weight:700;line-height:1;color:${grade.color}">${l.deal_score ?? '—'}</span>
        <span style="font-size:9px;color:var(--text-secondary)">${grade.letter}</span>
      </div>

      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <span style="font-weight:700;color:var(--gold-light)">${l.address}</span>
          ${badge(l.status, statusBadgeKind(l.status))}
        </div>
        <div style="font-size:12px;color:var(--text-secondary);margin-top:2px">
          ${l.city || ''}, ${l.state || ''} ${l.zip || ''} · ${l.owner_name || 'Owner unknown'} · ${l.source}
        </div>
        ${tags.length ? `<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
          ${tags.map(t => `<span style="font-size:11px;padding:2px 8px;border-radius:5px;background:var(--charcoal-lighter);color:var(--text-secondary);border:1px solid var(--border-subtle)">${t}</span>`).join('')}
        </div>` : ''}

        <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap;align-items:center">
          ${l.source === 'AGENT_REFERRAL' ? `
            ${l.setup_call_outcome ? badge(l.setup_call_outcome, l.setup_call_outcome === 'GREEN' ? 'green' : l.setup_call_outcome === 'RED' ? 'red' : 'amber') : '<span style="color:var(--text-secondary);font-size:11px">Not called</span>'}
            <button onclick="setSetupCallOutcome(${l.lead_id}, 'GREEN')" style="padding:3px 8px;background:transparent;border:1px solid var(--status-green);color:var(--status-green);border-radius:6px;cursor:pointer;font-size:10px">Green</button>
            <button onclick="setSetupCallOutcome(${l.lead_id}, 'RED')" style="padding:3px 8px;background:transparent;border:1px solid var(--status-red);color:var(--status-red);border-radius:6px;cursor:pointer;font-size:10px">Red</button>
          ` : ''}
          ${!l.arv ? `<button onclick="pullComps(${l.lead_id})" style="padding:6px 12px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;cursor:pointer;font-size:12px">Pull Comps</button>` : ''}
          ${l.arv ? `<button onclick="generateBrief(${l.lead_id})" style="padding:6px 12px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;cursor:pointer;font-size:12px">Generate Brief</button>` : '<span style="color:var(--text-secondary);font-size:11px">Needs ARV</span>'}
          ${l.arv && l.status !== 'ACTIVE' ? `<button onclick="showLockDealForm(${l.lead_id})" style="padding:6px 12px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600">Lock Deal</button>` : ''}
        </div>
      </div>

      <div style="text-align:right;flex-shrink:0">
        ${l.arv ? `<div style="font-weight:700;color:var(--gold-light)">$${Number(l.arv).toLocaleString()}<span style="font-size:11px;font-weight:400;color:var(--text-secondary)"> ARV</span></div>` : ''}
        ${l.asking_price ? `<div style="font-size:13px;color:var(--text-primary);margin-top:2px">$${Number(l.asking_price).toLocaleString()} ask</div>` : ''}
        ${l.equity != null ? `<div style="font-size:13px;color:var(--status-green);margin-top:2px">$${Number(l.equity).toLocaleString()} equity</div>` : ''}
      </div>
    </div>`;
  }).join('');
}

async function refreshLeadsTable() {
  // Targeted refresh - updates only the table itself, leaving
  // briefContainer/lockDealFormContainer untouched, so a freshly
  // displayed brief or open form doesn't get wiped out by a routine
  // data refresh after Pull Comps or Generate Brief completes.
  const wrapper = document.getElementById('leadsTableWrapper');
  if (!wrapper) return;
  try {
    const { leads } = await fetchJSON('/chris/leads');
    wrapper.innerHTML = renderLeadsTable(leads);
  } catch (err) {
    // Silent - this is a background refresh, not a user-initiated
    // action, so a transient failure here shouldn't surface an error.
  }
}

async function pullComps(leadId) {
  const statusEl = document.getElementById('pullCompsStatus');
  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Pulling comps from Zillow via HasData...</span>';
  try {
    const res = await fetch(`/chris/leads/${leadId}/pull_comps`, { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = `<span style="color:var(--status-green)">Found it — ARV estimate: $${Number(data.arv_estimate).toLocaleString()}${data.asking_price ? `, asking price: $${Number(data.asking_price).toLocaleString()}` : ''}.</span>`;
      setTimeout(() => refreshLeadsTable(), 1500);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

async function setSetupCallOutcome(leadId, outcome) {
  const statusEl = document.getElementById('setupCallStatus');
  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Recording...</span>';
  try {
    const res = await fetch(`/chris/leads/${leadId}/setup_call_outcome`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ outcome }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = `<span style="color:${outcome === 'GREEN' ? 'var(--status-green)' : 'var(--status-red)'}">Marked ${outcome}.</span>`;
      setTimeout(() => refreshLeadsTable(), 800);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

async function submitNewLead() {
  const statusEl = document.getElementById('newLeadStatus');
  const address = document.getElementById('newLeadAddress').value.trim();
  const city = document.getElementById('newLeadCity').value.trim();
  const zip = document.getElementById('newLeadZip').value.trim();
  const ownerName = document.getElementById('newLeadOwnerName').value.trim();
  const ownerPhone = document.getElementById('newLeadOwnerPhone').value.trim();
  const arv = document.getElementById('newLeadArv').value.trim();

  if (!address || !city || !zip) {
    statusEl.innerHTML = '<span style="color:var(--status-red)">Address, city, and ZIP are required.</span>';
    return;
  }

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Adding...</span>';

  try {
    const res = await fetch('/chris/leads/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        address, city, zip,
        owner_name: ownerName || null,
        owner_phone: ownerPhone || null,
        arv: arv ? Number(arv) : null,
      }),
    });
    const data = await res.json();

    if (data.accepted) {
      statusEl.innerHTML = '<span style="color:var(--status-green)">Lead added successfully.</span>';
      setTimeout(() => loadView(), 800);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Not added: ${data.reason || 'unknown error'}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

function kpiRow(pairs) {
  return `<div class="kpi-row">
    ${pairs.map(([label, value]) => `<div class="kpi-card">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value numeral">${value ?? 0}</div>
    </div>`).join('')}
  </div>`;
}

// Circular gauge dial - semi-circular arc with a filled value sweep.
// Pure SVG, no dependencies, styled entirely with the real --gold/--status
// tokens. value/max are numbers; label and status are short caps strings;
// color is any CSS color (var(--status-green) etc).
function gaugeSVG(value, max, label, status, color) {
  const v = Number(value) || 0;
  const m = Number(max) || 1;
  const pct = Math.min(v / m, 1);
  const angle = -120 + pct * 240;
  const size = 150, r = size / 2 - 12, cx = size / 2, cy = size / 2;
  const toXY = (deg) => {
    const rad = (deg - 90) * (Math.PI / 180);
    return [cx + r * Math.cos(rad), cy + r * Math.sin(rad)];
  };
  const [sx, sy] = toXY(-120);
  const [ex, ey] = toXY(120);
  const [vx, vy] = toXY(angle);
  const large = pct > 0.5 ? 1 : 0;

  return `<div style="display:flex;flex-direction:column;align-items:center">
    <svg width="${size}" height="${size * 0.72}" viewBox="0 0 ${size} ${size}">
      <path d="M ${sx} ${sy} A ${r} ${r} 0 1 1 ${ex} ${ey}" fill="none" stroke="var(--border-subtle)" stroke-width="9" stroke-linecap="round"/>
      <path d="M ${sx} ${sy} A ${r} ${r} 0 ${large} 1 ${vx} ${vy}" fill="none" stroke="${color}" stroke-width="9" stroke-linecap="round"/>
      <text x="${cx}" y="${cy - 10}" text-anchor="middle" font-size="24" font-weight="700" fill="var(--text-primary)">${v}</text>
    </svg>
    <div style="font-size:11px;font-weight:600;margin-top:2px;color:var(--text-secondary);text-align:center">${label}</div>
    <div style="font-size:11px;font-weight:600;color:${color}">${status}</div>
  </div>`;
}

async function renderAlerts(main, url) {
  const { alerts } = await fetchJSON(url);
  if (!alerts.length) { main.innerHTML = emptyState('No alerts fired — pipeline is clean.'); return; }
  main.innerHTML = `<table class="data-table">
    <tr><th>Type</th><th>Severity</th><th>Message</th><th>Fired At</th></tr>
    ${alerts.map(a => `<tr>
      <td>${a.alert_type}</td>
      <td>${badge(a.severity, a.severity === 'CRITICAL' || a.severity === 'HIGH' ? 'red' : a.severity === 'WARN' || a.severity === 'MEDIUM' ? 'amber' : 'neutral')}</td>
      <td>${a.message || ''}</td>
      <td>${a.fired_at}</td>
    </tr>`).join('')}
  </table>`;
}

// Init
applySiteSettings();
renderSubTabs();
loadView();
