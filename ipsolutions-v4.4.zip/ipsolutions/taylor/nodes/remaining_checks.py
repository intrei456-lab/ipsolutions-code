"""
Taylor's remaining node checks — nodes not already covered in
taylor/nodes/engine.py (which has the nodes with real conditional gates:
4, 6, 7, 25, 28). Most of these are straightforward "confirm X is true"
checks with a simple done/blocked outcome, so they're grouped here rather
than each getting Ideas'-worth of ceremony.
"""

from datetime import datetime, timedelta


def check_node_2_assignment_url(doc_url: str | None, url_reachable: bool) -> dict:
    if doc_url and url_reachable:
        return {"status": "done"}
    return {
        "status": "blocked",
        "blocking_reason": "assignment_url_unreachable",
        "alert_type": "assignment_url_unreachable",
        "severity": "HIGH",
    }


def check_node_3_fp_contact(name: str | None, email: str | None, phone: str | None,
                              entity: str | None, entity_is_llc: bool, ein: str | None) -> dict:
    required = [name, email, phone, entity]
    if entity_is_llc:
        required.append(ein)
    if all(required):
        return {"status": "done"}
    return {
        "status": "blocked",
        "blocking_reason": "fp_contact_incomplete",
        "alert_type": "fp_contact_incomplete",
        "severity": "MEDIUM",
    }


def check_node_5_seller_contract(contract_on_file: bool) -> dict:
    if contract_on_file:
        return {"status": "done"}
    return {
        "status": "blocked",
        "blocking_reason": "seller_contract_missing",
        "alert_type": "seller_contract_missing",
        "severity": "MEDIUM",
    }


def check_node_8_title_search(node_7_done: bool, title_search_ordered_at: str | None) -> dict:
    if not node_7_done:
        return {"status": "pending"}
    if title_search_ordered_at:
        return {"status": "done"}
    return {"status": "in_progress"}


def check_node_9_title_insurance(node_8_done: bool, commitment_ordered_at: str | None) -> dict:
    if not node_8_done:
        return {"status": "pending"}
    if commitment_ordered_at:
        return {"status": "done"}
    return {"status": "in_progress"}


def check_node_10_12_property_status(tax_status: str | None, hoa_status: str | None,
                                       utility_status: str | None, hoa_applicable: bool) -> dict:
    """Combined tax/HOA/utility verification - three related checks sharing
    the same simple pattern (pull data from Chris where possible, record
    in notes)."""
    checks_needed = ["tax"]
    if hoa_applicable:
        checks_needed.append("hoa")
    checks_needed.append("utility")

    have = {"tax": tax_status, "hoa": hoa_status, "utility": utility_status}
    missing = [c for c in checks_needed if not have.get(c)]

    if not missing:
        return {"status": "done", "notes": f"tax={tax_status}, hoa={hoa_status}, utility={utility_status}"}
    return {"status": "in_progress", "notes": f"still need: {', '.join(missing)}"}


def check_node_13_fp_closing_package(package_drafted: bool) -> dict:
    return {"status": "done" if package_drafted else "in_progress"}


def check_node_14_fp_funding_source(funding_source: str | None) -> dict:
    """cold_cash (1-2 day) or private_or_hard_money (7-14 day). Determines
    reminder cadence for node 24."""
    if funding_source in ("cold_cash", "private_or_hard_money"):
        return {"status": "done", "funding_source": funding_source}
    return {"status": "in_progress"}


def check_node_15_funding_instructions_sent(sent_at: str | None) -> dict:
    return {"status": "done" if sent_at else "in_progress"}


def check_node_16_17_wire_coordination(wire_received_at: str | None, wire_amount: float | None,
                                         expected_amount: float) -> dict:
    """Combined nodes 16 (coordinate wire) and 17 (verify received) - one
    wire, single amount check, never two separate deposits."""
    if wire_received_at and wire_amount and abs(wire_amount - expected_amount) < 1.0:
        return {"status": "done"}
    return {"status": "in_progress"}


def check_node_18_seller_closing_package(package_sent: bool) -> dict:
    return {"status": "done" if package_sent else "in_progress"}


def check_node_19_seller_execution_method(execution_method: str | None) -> dict:
    """mail_away / in_person / mobile_notary"""
    valid_methods = ("mail_away", "in_person", "mobile_notary")
    if execution_method in valid_methods:
        return {"status": "done", "execution_method": execution_method}
    return {"status": "in_progress"}


def check_node_20_mobile_notary(execution_method: str, state: str, notary_ordered: bool) -> dict:
    """Only applicable when mail_away AND state is FL or NC."""
    if execution_method != "mail_away" or state not in ("FL", "NC"):
        return {"status": "done", "notes": "not applicable - not a mail-away FL/NC deal"}
    if notary_ordered:
        return {"status": "done"}
    return {"status": "in_progress"}


def check_node_21_assignment_recorded(recorded_at: str | None) -> dict:
    return {"status": "done" if recorded_at else "in_progress"}


def check_node_22_termination_extension(applicable: bool, doc_status: str | None) -> dict:
    if not applicable:
        return {"status": "done", "notes": "not applicable to this deal"}
    return {"status": "done" if doc_status == "executed" else "in_progress"}


def check_node_23_schedule_closing(close_date_target: str | None) -> dict:
    return {"status": "done" if close_date_target else "in_progress"}


def check_node_24_48hour_reminder(close_date_target: str, now: datetime) -> dict:
    """Fires exactly when close_date_target is 48h away - a timing check,
    not a completion check, so this returns whether the reminder SHOULD
    fire right now rather than a done/blocked status."""
    target = datetime.fromisoformat(close_date_target)
    hours_until = (target - now).total_seconds() / 3600
    should_fire = 47 <= hours_until <= 49  # ~48h window with some tolerance
    return {"should_fire_reminder": should_fire, "hours_until_close": round(hours_until, 1)}


def check_node_26_day_of_monitoring(wire_confirmed: bool, doc_execution_confirmed: bool,
                                      recording_started: bool) -> dict:
    """Only meaningful on the actual close_date_target - Closing Day Sweep territory."""
    if wire_confirmed and doc_execution_confirmed and recording_started:
        return {"status": "done"}
    missing = []
    if not wire_confirmed:
        missing.append("wire")
    if not doc_execution_confirmed:
        missing.append("doc execution")
    if not recording_started:
        missing.append("recording")
    return {"status": "in_progress", "notes": f"still waiting on: {', '.join(missing)}"}


def check_node_27_hud_received(hud_url: str | None) -> dict:
    return {"status": "done" if hud_url else "in_progress"}


def check_node_29_emd_released(refundable_status: str) -> dict:
    """Reconciled against contract - HELD -> RELEASED or APPLIED."""
    if refundable_status in ("RELEASED", "APPLIED"):
        return {"status": "done"}
    return {"status": "in_progress"}


def check_node_30_deed_recorded(recorded_at: str | None, close_date: str, now: datetime) -> dict:
    if recorded_at:
        return {"status": "done"}
    close = datetime.fromisoformat(close_date)
    days_since_close = (now - close).days
    if days_since_close > 5:
        return {
            "status": "blocked",
            "blocking_reason": "deed_not_recorded_5d",
            "alert_type": "deed_not_recorded_5d",
            "severity": "HIGH",
        }
    return {"status": "in_progress"}


def check_node_31_33_closing_confirmations(sent_to_thomas: bool, sent_to_fp: bool, sent_to_seller: bool) -> dict:
    """Combined nodes 31/32/33 - same pattern, different recipient."""
    return {
        "node_31_thomas": "done" if sent_to_thomas else "pending",
        "node_32_fp": "done" if sent_to_fp else "pending",
        "node_33_seller": "done" if sent_to_seller else "pending",
    }


def check_node_34_resimpli_update(queued: bool) -> dict:
    """Always queues to resimpli_sync_queue regardless of live API auth status."""
    return {"status": "done" if queued else "in_progress"}
