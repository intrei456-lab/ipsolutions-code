"""
Taylor's KPI rollup and Node 36 (archive + post-close signal back to Alex).
"""

from datetime import date

from taylor.db.db import get_connection


def compute_kpi(rollup_type: str = "daily", kpi_date: str | None = None) -> dict:
    kpi_date = kpi_date or date.today().isoformat()
    conn = get_connection()
    try:
        active_count = conn.execute(
            "SELECT COUNT(*) as c FROM closings WHERE status = 'in_progress'"
        ).fetchone()["c"]

        closed_count = conn.execute(
            "SELECT COUNT(*) as c FROM closings WHERE status = 'closed' AND date(funded_at) = ?", (kpi_date,)
        ).fetchone()["c"] if rollup_type == "daily" else conn.execute(
            "SELECT COUNT(*) as c FROM closings WHERE status = 'closed' AND funded_at > datetime('now', '-7 days')"
        ).fetchone()["c"]

        fee_row = conn.execute(
            "SELECT SUM(assignment_fee_collected) as total FROM closings WHERE status = 'closed'"
        ).fetchone()

        avg_days_row = conn.execute(
            "SELECT AVG(days_to_close) as avg_days FROM closings WHERE days_to_close IS NOT NULL"
        ).fetchone()

        kpi = {
            "kpi_date": kpi_date,
            "rollup_type": rollup_type,
            "active_deal_count": active_count,
            "closed_deals_count": closed_count,
            "total_assignment_fees_banked": fee_row["total"] or 0,
            "avg_days_assignment_to_funded": avg_days_row["avg_days"] or 0,
        }

        conn.execute(
            """
            INSERT OR REPLACE INTO closing_kpi (
                kpi_date, rollup_type, active_deal_count, closed_deals_count,
                total_assignment_fees_banked, avg_days_assignment_to_funded
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (kpi["kpi_date"], kpi["rollup_type"], kpi["active_deal_count"],
             kpi["closed_deals_count"], kpi["total_assignment_fees_banked"],
             kpi["avg_days_assignment_to_funded"]),
        )
        conn.commit()
        return kpi
    finally:
        conn.close()


def archive_and_signal_alex(closing_id: int) -> dict:
    """
    Node 36: archive the closing and write the taylor_handoffs row that
    triggers Alex's Mode 3 post-close relationship deepening.
    """
    conn = get_connection()
    try:
        closing = conn.execute(
            "SELECT * FROM closings WHERE closing_id = ?", (closing_id,)
        ).fetchone()
        if closing is None:
            return {"success": False, "reason": "closing_not_found"}

        days_to_close = None
        if closing["started_at"] and closing["funded_at"]:
            row = conn.execute(
                "SELECT julianday(?) - julianday(?) as days",
                (closing["funded_at"], closing["started_at"]),
            ).fetchone()
            days_to_close = round(row["days"]) if row["days"] else None

        conn.execute(
            "UPDATE closings SET archived_at = datetime('now'), status = 'closed', days_to_close = ? WHERE closing_id = ?",
            (days_to_close, closing_id),
        )

        conn.execute(
            """
            INSERT INTO taylor_handoffs (
                closing_id, direction, status, fp_name, fp_contact,
                deal_zip, deal_state, assignment_fee_collected, close_date_actual, notes
            ) VALUES (?, 'OUTBOUND_TO_ALEX_POST_CLOSE', 'POST_CLOSE_SIGNAL', ?, ?, ?, ?, ?, ?,
                      'Deal closed and funded. Trigger Mode 3 post-deal FP relationship deepen.')
            """,
            (
                closing_id, closing["fp_name"], closing["fp_email"] or closing["fp_phone"],
                closing["zip"], closing["state"], None, closing["funded_at"],
            ),
        )

        conn.commit()
        return {"success": True, "days_to_close": days_to_close}
    finally:
        conn.close()
