"""
The canonical 36-node closing workflow, real titles confirmed directly
against the live Twin build (grouped into 4 phases as Twin organized them).
"""

from dataclasses import dataclass


@dataclass
class NodeTemplateEntry:
    number: int
    title: str
    phase: str


PRE_CLOSING = [
    (1, "Receive Alex handoff record"),
    (2, "Validate signed assignment doc URL is accessible"),
    (3, "Confirm FP contact info complete (name, email, phone, entity, EIN)"),
    (4, "Confirm EMD received and matches close timeline tier"),
    (5, "Confirm seller signed purchase contract on file"),
    (6, "Confirm Affidavit & MOA filed at county ($25 anti-double-sell)"),
    (7, "Open file with assigned title company (state-routed)"),
    (8, "Order title search"),
    (9, "Order title insurance commitment"),
    (10, "Verify property tax status (current vs delinquent)"),
    (11, "Verify HOA status if applicable"),
    (12, "Verify utility status (water/sewer liens, code violations)"),
]

CONTRACT_DOCS = [
    (13, "Draft FP closing package (settlement preview, ALTA, wire)"),
    (14, "Confirm FP funding source (cold cash 1-2d vs private/hard 7-14d)"),
    (15, "Send FP funding instructions"),
    (16, "Coordinate FP wire to title company escrow"),
    (17, "Verify wire received in escrow"),
    (18, "Coordinate seller closing package"),
    (19, "Confirm seller execution method (mail-away/in-person/mobile notary)"),
    (20, "Order mobile notary if mail-away (FL/NC)"),
    (21, "Confirm IPSolutions Assignment recorded with title company"),
    (22, "Confirm Termination/Extension/Auth-Release-Escrow if needed"),
]

CLOSING = [
    (23, "Schedule closing table date with all parties"),
    (24, "Send 48-hour reminder to FP, seller, title company"),
    (25, "Confirm photos package delivered to FP"),
    (26, "Day-of: monitor wire receipt, document execution, recording"),
    (27, "Day-of: receive HUD/CD final from title company"),
    (28, "Verify IPSolutions assignment fee disbursed correctly"),
    (29, "Verify EMD released or applied per contract"),
]

POST_CLOSING = [
    (30, "Confirm deed recorded with county"),
    (31, "Send closing confirmation to Thomas (with HUD attached)"),
    (32, "Send closing confirmation to FP (post-close client care)"),
    (33, "Send closing confirmation to seller (transaction complete)"),
    (34, "Update REsimpli with closed-won status"),
    (35, "Trigger Alex post-close follow-up cadence with FP"),
    (36, "Archive complete deal file"),
]

NODE_TEMPLATE: list[NodeTemplateEntry] = (
    [NodeTemplateEntry(n, t, "PRE_CLOSING") for n, t in PRE_CLOSING]
    + [NodeTemplateEntry(n, t, "CONTRACT_DOCS") for n, t in CONTRACT_DOCS]
    + [NodeTemplateEntry(n, t, "CLOSING") for n, t in CLOSING]
    + [NodeTemplateEntry(n, t, "POST_CLOSING") for n, t in POST_CLOSING]
)


def get_node(number: int) -> NodeTemplateEntry:
    return next(n for n in NODE_TEMPLATE if n.number == number)


def get_phase(phase: str) -> list[NodeTemplateEntry]:
    return [n for n in NODE_TEMPLATE if n.phase == phase]


PHASES_IN_ORDER = ["PRE_CLOSING", "CONTRACT_DOCS", "CLOSING", "POST_CLOSING"]
