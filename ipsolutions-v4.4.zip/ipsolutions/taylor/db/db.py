"""
Taylor's database connection helper. Same pattern as Chris/Alex.
"""

import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "taylor.db"
SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    conn = get_connection()
    with open(SCHEMA_PATH) as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()


def seed_node_template() -> None:
    """Seed the canonical 36-node workflow titles/phases."""
    from taylor.nodes.node_template import NODE_TEMPLATE

    conn = get_connection()
    for node in NODE_TEMPLATE:
        conn.execute(
            "INSERT OR REPLACE INTO node_template (node_number, title, phase) VALUES (?, ?, ?)",
            (node.number, node.title, node.phase),
        )
    conn.commit()
    conn.close()


def seed_title_company_directory() -> None:
    from shared.config import TITLE_COMPANY_DIRECTORY

    conn = get_connection()
    for state, info in TITLE_COMPANY_DIRECTORY.items():
        conn.execute(
            """
            INSERT OR REPLACE INTO title_company_directory
                (state, primary_company, secondary_company, contact_name)
            VALUES (?, ?, ?, ?)
            """,
            (state, info.get("primary"), info.get("secondary"), info.get("contact")),
        )
    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db()
    seed_node_template()
    seed_title_company_directory()
    print(f"Taylor DB initialized at {DB_PATH}")
