// IPSolutions Pipeline Command - vanilla JS, no build step, calls the
// real FastAPI endpoints defined in main.py.

const SUB_TABS = {
  workspace: [],
  chris: [
    { id: 'leads', label: 'Leads' },
    { id: 'agents', label: 'Agents' },
    { id: 'kpi', label: 'Daily KPI' },
    { id: 'scouts', label: 'Scout Runs' },
  ],
  alex: [
    { id: 'deals', label: 'Pipeline' },
    { id: 'fp_network', label: 'FP Network' },
    { id: 'kpi', label: 'KPI' },
    { id: 'alerts', label: 'CEO Alerts' },
  ],
  taylor: [
    { id: 'closings', label: 'Closings' },
    { id: 'alerts', label: 'CEO Alerts' },
  ],
};

let currentAgent = 'workspace';
let currentSubTab = null;
let workspaceHistory = [];

function switchAgent(agent) {
  currentAgent = agent;
  currentSubTab = SUB_TABS[agent].length ? SUB_TABS[agent][0].id : null;
  document.querySelectorAll('.agent-tab').forEach(el => {
    el.classList.toggle('active', el.dataset.agent === agent);
  });
  renderSubTabs();
  loadView();
}

function renderSubTabs() {
  const nav = document.getElementById('subTabs');
  nav.innerHTML = '';
  SUB_TABS[currentAgent].forEach(tab => {
    const el = document.createElement('div');
    el.className = 'sub-tab' + (tab.id === currentSubTab ? ' active' : '');
    el.textContent = tab.label;
    el.onclick = () => { currentSubTab = tab.id; renderSubTabs(); loadView(); };
    nav.appendChild(el);
  });
}

function refreshCurrent() { loadView(); }

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url} returned ${res.status}`);
  return res.json();
}

function emptyState(message) {
  return `<div class="empty-state"><div class="glyph">&mdash;</div>${message}</div>`;
}

function badge(text, kind) {
  return `<span class="badge badge-${kind}">${text}</span>`;
}

function statusBadgeKind(status) {
  const s = (status || '').toUpperCase();
  if (['DONE', 'CLOSED', 'VERIFIED_BUYER', 'ACTIVE', 'REPEAT'].includes(s)) return 'green';
  if (['BLOCKED', 'DEAD', 'CRITICAL', 'SUSPECTED_WHOLESALER'].includes(s)) return 'red';
  if (['IN_PROGRESS', 'WARN', 'PENDING'].includes(s)) return 'amber';
  return 'neutral';
}

async function loadView() {
  const main = document.getElementById('mainContent');
  if (currentAgent === 'workspace') { renderWorkspaceChat(main); return; }
  main.innerHTML = '<div class="loading">Loading...</div>';
  try {
    if (currentAgent === 'chris') await loadChrisView(main);
    else if (currentAgent === 'alex') await loadAlexView(main);
    else if (currentAgent === 'taylor') await loadTaylorView(main);
  } catch (err) {
    main.innerHTML = emptyState(`Could not load data — ${err.message}. Is the server running?`);
  }
}

// ---------------------------------------------------------------------------
// Workspace Chat - the Chief of Staff layer, embedded in the dashboard
// ---------------------------------------------------------------------------

function renderWorkspaceChat(main) {
  main.innerHTML = `
    <div style="max-width:700px;margin:0 auto">
      <div id="overviewStats" style="margin-bottom:20px"></div>
      <div id="reflectionsBanner"></div>
      <div id="workspaceMessages" style="display:flex;flex-direction:column;gap:12px;margin-bottom:16px;min-height:200px"></div>
      <div style="display:flex;gap:8px">
        <input id="workspaceInput" placeholder="Ask about deals, strategy, or what's happening across the business..."
          style="flex:1;padding:12px;background:var(--charcoal-light);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:8px"
          onkeydown="if(event.key==='Enter') sendWorkspaceMessage()">
        <button onclick="sendWorkspaceMessage()" style="padding:12px 20px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:8px;font-weight:600;cursor:pointer">Send</button>
      </div>
      <div style="display:flex;gap:8px;margin-top:10px;align-items:center">
        <input id="lessonInput" placeholder="Save a lesson to the brain (e.g. what you learned from a deal)..."
          style="flex:1;padding:8px;background:var(--charcoal-light);border:1px solid var(--border-subtle);color:var(--text-secondary);border-radius:6px;font-size:12px">
        <button onclick="saveLessonToBrain()" style="padding:8px 14px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;font-size:12px;cursor:pointer">Save to Brain</button>
      </div>
      <div id="lessonStatus" style="font-size:11px;margin-top:6px"></div>
    </div>`;
  renderWorkspaceMessages();
  loadPendingReflections();
  loadOverviewStats();
}

async function loadOverviewStats() {
  const container = document.getElementById('overviewStats');
  try {
    const [leadsRes, dealsRes, closingsRes, fpRes] = await Promise.all([
      fetchJSON('/chris/leads'), fetchJSON('/alex/deals'),
      fetchJSON('/taylor/closings'), fetchJSON('/alex/financial_partners'),
    ]);
    const activeDeals = dealsRes.deals.filter(d => d.dispo_status !== 'TAYLOR_HANDOFF' && d.dispo_status !== 'DEAD').length;
    const activeClosings = closingsRes.closings.filter(c => c.status === 'in_progress').length;

    container.innerHTML = kpiRow([
      ['Leads', leadsRes.leads.length],
      ['Active Deals', activeDeals],
      ['Closings In Progress', activeClosings],
      ['Financial Partners', fpRes.financial_partners.length],
    ]);
  } catch (err) {
    container.innerHTML = '';
  }
}

async function loadPendingReflections() {
  const banner = document.getElementById('reflectionsBanner');
  try {
    const res = await fetch('/workspace/pending_reflections');
    const data = await res.json();
    if (!data.pending || !data.pending.length) { banner.innerHTML = ''; return; }

    banner.innerHTML = `<div class="node-phase" style="margin-bottom:16px;border-color:var(--gold-light)">
      <h3>Closed deals worth reflecting on</h3>
      ${data.pending.map(p => `<div class="node-row">
        <span>${p.address}</span>
        <button onclick="promptLesson('${p.address.replace(/'/g, "\\'")}')" style="padding:4px 10px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;font-size:11px;cursor:pointer">What did you learn?</button>
      </div>`).join('')}
    </div>`;
  } catch (err) {
    banner.innerHTML = '';
  }
}

function promptLesson(address) {
  const input = document.getElementById('lessonInput');
  input.value = `Lesson from ${address}: `;
  input.focus();
}

async function saveLessonToBrain() {
  const input = document.getElementById('lessonInput');
  const statusEl = document.getElementById('lessonStatus');
  const lesson = input.value.trim();
  if (!lesson) return;

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Saving...</span>';
  try {
    const res = await fetch('/workspace/memory/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lesson }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = '<span style="color:var(--status-green)">Saved to brain/memory/lessons.md</span>';
      input.value = '';
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error || 'unknown'}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

function renderWorkspaceMessages() {
  const container = document.getElementById('workspaceMessages');
  if (!workspaceHistory.length) {
    container.innerHTML = `<div class="empty-state"><div class="glyph">&mdash;</div>
      Ask me anything about your business — I can see live counts across Chris, Alex, and Taylor.
      <br><span style="font-size:11px">Note: this chat resets when you reload the page — it's not saved yet.</span></div>`;
    return;
  }
  container.innerHTML = workspaceHistory.map(m => `
    <div style="align-self:${m.role === 'user' ? 'flex-end' : 'flex-start'};max-width:80%">
      <div style="font-size:10px;text-transform:uppercase;color:var(--text-secondary);margin-bottom:4px;text-align:${m.role === 'user' ? 'right' : 'left'}">${m.role === 'user' ? 'You' : 'Workspace'}</div>
      <div style="background:${m.role === 'user' ? 'var(--gold-light)' : 'var(--charcoal-light)'};color:${m.role === 'user' ? 'var(--charcoal)' : 'var(--text-primary)'};padding:12px 16px;border-radius:12px;white-space:pre-wrap;font-size:14px;line-height:1.5">${m.content}</div>
    </div>
  `).join('');
  container.scrollTop = container.scrollHeight;
}

async function sendWorkspaceMessage() {
  const input = document.getElementById('workspaceInput');
  const text = input.value.trim();
  if (!text) return;

  workspaceHistory.push({ role: 'user', content: text });
  input.value = '';
  renderWorkspaceMessages();

  workspaceHistory.push({ role: 'assistant', content: '...' });
  renderWorkspaceMessages();

  try {
    const res = await fetch('/workspace/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: workspaceHistory.slice(0, -1) }),
    });
    const data = await res.json();
    workspaceHistory.pop(); // remove the '...' placeholder

    if (data.success) {
      workspaceHistory.push({ role: 'assistant', content: data.reply });
    } else {
      workspaceHistory.push({ role: 'assistant', content: `Error: ${data.error}` });
    }
  } catch (err) {
    workspaceHistory.pop();
    workspaceHistory.push({ role: 'assistant', content: `Error: ${err.message}` });
  }
  renderWorkspaceMessages();
}

// ---------------------------------------------------------------------------
// Chris views
// ---------------------------------------------------------------------------

async function loadChrisView(main) {
  if (currentSubTab === 'leads') {
    const { leads } = await fetchJSON('/chris/leads');
    const formHtml = `<div class="node-phase" style="margin-bottom:20px;max-width:500px">
      <h3>Add a Lead</h3>
      <div style="display:flex;flex-direction:column;gap:8px">
        <input id="newLeadAddress" placeholder="Address" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newLeadCity" placeholder="City" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newLeadZip" placeholder="ZIP" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newLeadOwnerName" placeholder="Owner name (optional)" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newLeadOwnerPhone" placeholder="Owner phone (optional)" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newLeadArv" placeholder="ARV (optional)" type="number" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <button onclick="submitNewLead()" style="padding:10px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;font-weight:600;cursor:pointer">Add Lead</button>
        <div id="newLeadStatus"></div>
      </div>
    </div>`;

    if (!leads.length) {
      main.innerHTML = formHtml + emptyState('No leads yet. Add one above, or wait for a scout run.');
      return;
    }
    main.innerHTML = formHtml + `<table class="data-table">
      <tr><th>Address</th><th>City/State</th><th>Source</th><th>Status</th><th>Motivation</th><th>ARV</th><th></th></tr>
      ${leads.map(l => `<tr>
        <td>${l.address}</td>
        <td>${l.city || ''}, ${l.state || ''}</td>
        <td>${l.source}</td>
        <td>${badge(l.status, statusBadgeKind(l.status))}</td>
        <td>${l.motivation || '—'}</td>
        <td>${l.arv ? '$' + Number(l.arv).toLocaleString() : '—'}</td>
        <td style="display:flex;gap:6px">
          ${l.arv ? `<button onclick="generateBrief(${l.lead_id})" style="padding:6px 12px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;cursor:pointer;font-size:12px">Generate Brief</button>` : '<span style="color:var(--text-secondary);font-size:11px">Needs ARV</span>'}
          ${l.arv && l.status !== 'ACTIVE' ? `<button onclick="showLockDealForm(${l.lead_id})" style="padding:6px 12px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600">Lock Deal</button>` : ''}
        </td>
      </tr>`).join('')}
    </table>
    <div id="briefContainer" style="margin-top:20px"></div>
    <div id="lockDealFormContainer" style="margin-top:16px"></div>`;
  } else if (currentSubTab === 'agents') {
    const { agents } = await fetchJSON('/chris/agents');
    const formHtml = `<div class="node-phase" style="margin-bottom:20px;max-width:500px">
      <h3>Add an Agent</h3>
      <div style="display:flex;flex-direction:column;gap:8px">
        <input id="newAgentName" placeholder="Name" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newAgentPhone" placeholder="Phone" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newAgentEmail" placeholder="Email (optional)" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <input id="newAgentBrokerage" placeholder="Brokerage (optional)" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <button onclick="submitNewAgent()" style="padding:10px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;font-weight:600;cursor:pointer">Add Agent</button>
        <div id="newAgentStatus"></div>
      </div>
    </div>`;

    if (!agents.length) {
      main.innerHTML = formHtml + emptyState('No agents yet. Add one above to start building your gatekeeper network.');
      return;
    }
    main.innerHTML = formHtml + `<table class="data-table">
      <tr><th>Name</th><th>Phone</th><th>Brokerage</th><th>Tier</th><th>Last Contact</th><th>Last Outcome</th><th></th></tr>
      ${agents.map(a => `<tr>
        <td>${a.name}</td>
        <td>${a.phone || '—'}</td>
        <td>${a.brokerage || '—'}</td>
        <td>${badge(a.tier, a.tier === 'TIER_1' ? 'green' : a.tier === 'TIER_2' ? 'amber' : a.tier === 'DEAD' ? 'red' : 'neutral')}</td>
        <td>${a.last_contact_at || 'Never'}</td>
        <td>${a.last_call_outcome || '—'}</td>
        <td>${a.phone ? `<button onclick="callAgent(${a.agent_id})" style="padding:6px 12px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;cursor:pointer;font-size:12px">Call via Brielle</button>` : '<span style="color:var(--text-secondary);font-size:11px">No phone</span>'}</td>
      </tr>`).join('')}
    </table>
    <div id="agentCallStatus" style="margin-top:12px;font-size:12px"></div>`;
  } else if (currentSubTab === 'kpi') {
    const { kpi } = await fetchJSON('/chris/kpi');
    if (!kpi) { main.innerHTML = emptyState('No KPI data for today yet.'); return; }
    main.innerHTML = kpiRow([
      ['Leads Today', kpi.leads_today], ['Conversations', kpi.conversations_today],
      ['Offers', kpi.offers_today], ['Contracts', kpi.contracts_today],
      ['FB Ad Leads', kpi.fb_ad_leads], ['FSBO Leads', kpi.fsbo_leads],
      ['Scout Leads', kpi.scout_leads], ['Mat Beard Touches', kpi.mat_beard_touches],
    ]);
  } else if (currentSubTab === 'scouts') {
    const { scout_runs } = await fetchJSON('/chris/scout_runs');
    if (!scout_runs.length) { main.innerHTML = emptyState('No scout runs logged yet.'); return; }
    main.innerHTML = `<table class="data-table">
      <tr><th>Module</th><th>Ran At</th><th>Raw</th><th>In-Market</th><th>New Leads</th><th>Status</th></tr>
      ${scout_runs.map(r => `<tr>
        <td>${r.module}</td><td>${r.run_at}</td><td>${r.raw_results}</td>
        <td>${r.in_market_results}</td><td>${r.new_leads}</td>
        <td>${badge(r.portal_status, r.portal_status === 'OK' ? 'green' : 'red')}</td>
      </tr>`).join('')}
    </table>`;
  }
}

// ---------------------------------------------------------------------------
// Alex views
// ---------------------------------------------------------------------------

async function loadAlexView(main) {
  if (currentSubTab === 'deals') {
    const { deals } = await fetchJSON('/alex/deals');
    if (!deals.length) { main.innerHTML = emptyState('No deals in the pipeline yet — waiting on a handoff from Chris.'); return; }
    window._alexDeals = deals;

    let fpOptions = '';
    try {
      const { financial_partners } = await fetchJSON('/alex/financial_partners');
      window._fpDataForAssign = financial_partners;
      fpOptions = financial_partners.map((fp, i) => `<option value="${i}">${fp.entity_name}</option>`).join('');
    } catch (err) { /* fp list optional here */ }

    main.innerHTML = `<table class="data-table">
      <tr><th>Address</th><th>Status</th><th>Exit Strategy</th><th>Dispo Day</th><th>FP Price</th><th>Assigned FP</th><th></th></tr>
      ${deals.map((d, i) => `<tr>
        <td>${d.address}</td>
        <td>${badge(d.dispo_status, statusBadgeKind(d.dispo_status))}</td>
        <td>${d.exit_strategy}</td>
        <td>${d.dispo_day ?? '—'} / 5</td>
        <td>${d.fp_facing_price ? '$' + Number(d.fp_facing_price).toLocaleString() : '—'}</td>
        <td>${d.fp_assigned_id ? '<span style="color:var(--status-green)">Assigned</span>' : '<span style="color:var(--text-secondary)">Unassigned</span>'}</td>
        <td>
          ${!d.fp_assigned_id ? `
            <select id="fpSelect${d.deal_id}" style="padding:4px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px;font-size:11px">
              <option value="">Pick FP...</option>${fpOptions}
            </select>
            <button onclick="doAssignFP(${d.deal_id}, ${i})" style="padding:4px 10px;background:transparent;border:1px solid var(--gold-light);color:var(--gold-light);border-radius:6px;cursor:pointer;font-size:11px">Assign</button>
          ` : `
            <button onclick="showTaylorHandoffForm(${d.deal_id})" style="padding:4px 10px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;cursor:pointer;font-size:11px;font-weight:600">Hand off to Taylor</button>
          `}
        </td>
      </tr>`).join('')}
    </table>
    <div id="alexActionStatus" style="margin-top:12px;font-size:12px"></div>
    <div id="taylorHandoffFormContainer" style="margin-top:16px"></div>`;
  } else if (currentSubTab === 'fp_network') {
    const { financial_partners } = await fetchJSON('/alex/financial_partners');
    if (!financial_partners.length) { main.innerHTML = emptyState('No financial partners loaded yet.'); return; }
    window._fpData = financial_partners;
    main.innerHTML = `<table class="data-table">
      <tr><th>Entity</th><th>VIP Tier</th><th>Dispo Tier</th><th>Relationship</th><th>Deals Closed</th></tr>
      ${financial_partners.map((fp, i) => `<tr onclick="showFPDetail(${i})" style="cursor:pointer">
        <td>${fp.entity_name}</td>
        <td>${badge(fp.vip_tier, fp.vip_tier === 'VIP' ? 'green' : fp.vip_tier === 'WARM' ? 'amber' : 'neutral')}</td>
        <td class="tier-${(fp.dispo_tier || 'c').toLowerCase()}">${fp.dispo_tier || 'C'}</td>
        <td>${badge(fp.relationship_stage, statusBadgeKind(fp.relationship_stage))}</td>
        <td>${fp.total_deals_closed}</td>
      </tr>`).join('')}
    </table>
    <div id="fpDetailContainer" style="margin-top:20px"></div>`;
  } else if (currentSubTab === 'kpi') {
    const { kpi } = await fetchJSON('/alex/kpi');
    if (!kpi) { main.innerHTML = emptyState('No KPI data yet.'); return; }
    main.innerHTML = kpiRow([
      ['Active OWN', kpi.active_deals_own], ['Active JV', kpi.active_deals_jv],
      ['Avg DOM', kpi.avg_days_on_market], ['FP Touches Today', kpi.fp_touches_today],
      ['Avg TTB (hrs)', kpi.avg_ttb_hours], ['TTB Breaches', kpi.ttb_breaches],
      ['Tier A', kpi.tier_a_count], ['Tier B', kpi.tier_b_count], ['Tier C', kpi.tier_c_count],
    ]);
  } else if (currentSubTab === 'alerts') {
    await renderAlerts(main, '/alex/ceo_alerts');
  }
}

// ---------------------------------------------------------------------------
// Taylor views
// ---------------------------------------------------------------------------

async function loadTaylorView(main) {
  if (currentSubTab === 'closings') {
    const { closings } = await fetchJSON('/taylor/closings');
    if (!closings.length) { main.innerHTML = emptyState('No closings in the pipeline yet — waiting on a handoff from Alex.'); return; }
    main.innerHTML = `<table class="data-table">
      <tr><th>Address</th><th>Node</th><th>Status</th><th>Risk Tier</th><th>Close Date</th></tr>
      ${closings.map(c => `<tr onclick="loadNodeBoard(${c.closing_id})" style="cursor:pointer">
        <td>${c.address}</td>
        <td>${c.current_node} / 36</td>
        <td>${badge(c.status, statusBadgeKind(c.status))}</td>
        <td>${badge(c.risk_tier, c.risk_tier === 'PROTECT_SPREAD' ? 'amber' : 'green')}</td>
        <td>${c.close_date_target || '—'}</td>
      </tr>`).join('')}
    </table>
    <div id="nodeBoardContainer" style="margin-top:20px"></div>`;
  } else if (currentSubTab === 'alerts') {
    await renderAlerts(main, '/taylor/ceo_alerts');
  }
}

async function loadNodeBoard(closingId) {
  const container = document.getElementById('nodeBoardContainer');
  container.innerHTML = '<div class="loading">Loading node board...</div>';
  const { nodes } = await fetchJSON(`/taylor/closings/${closingId}/nodes`);

  const phases = {};
  nodes.forEach(n => { (phases[n.phase] ||= []).push(n); });

  container.innerHTML = `<div class="node-board">
    ${Object.entries(phases).map(([phase, phaseNodes]) => `
      <div class="node-phase">
        <h3>${phase.replace('_', ' ')}</h3>
        ${phaseNodes.map(n => `<div class="node-row">
          <span>${n.node_number}. ${n.title}</span>
          ${badge(n.status, statusBadgeKind(n.status))}
        </div>`).join('')}
      </div>
    `).join('')}
  </div>`;
}

function showFPDetail(index) {
  const fp = window._fpData[index];
  const container = document.getElementById('fpDetailContainer');

  container.innerHTML = `<div class="node-phase" style="max-width:400px">
    <h3>${fp.entity_name}</h3>
    <div style="display:flex;flex-direction:column;gap:8px;margin:10px 0">
      <label style="font-size:11px;color:var(--text-secondary)">Phone</label>
      <input id="fpEditPhone" value="${fp.phone || ''}" placeholder="No phone on file"
        style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Email</label>
      <input id="fpEditEmail" value="${fp.email || ''}" placeholder="No email on file"
        style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <button onclick="saveFPContact(${fp.fp_id}, ${index})" style="padding:8px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;font-weight:600;cursor:pointer;font-size:12px">Save Contact Info</button>
      <div id="fpContactStatus" style="font-size:11px"></div>
    </div>
    <div class="node-row"><span>VIP Tier</span>${badge(fp.vip_tier, fp.vip_tier === 'VIP' ? 'green' : fp.vip_tier === 'WARM' ? 'amber' : 'neutral')}</div>
    <div class="node-row"><span>Dispo Tier</span><span class="tier-${(fp.dispo_tier || 'c').toLowerCase()}">${fp.dispo_tier || 'C'}</span></div>
    <div class="node-row"><span>Relationship</span>${badge(fp.relationship_stage, statusBadgeKind(fp.relationship_stage))}</div>
    <div class="node-row"><span>Deals Closed</span><span>${fp.total_deals_closed}</span></div>
  </div>`;
}

async function saveFPContact(fpId, index) {
  const statusEl = document.getElementById('fpContactStatus');
  const phone = document.getElementById('fpEditPhone').value.trim();
  const email = document.getElementById('fpEditEmail').value.trim();

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Saving...</span>';
  try {
    const res = await fetch(`/alex/financial_partners/${fpId}/update_contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email || null, phone: phone || null }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = '<span style="color:var(--status-green)">Saved.</span>';
      // Update the in-memory copy so the table reflects it without a full reload
      if (window._fpData && window._fpData[index]) {
        window._fpData[index].phone = phone || null;
        window._fpData[index].email = email || null;
      }
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

// ---------------------------------------------------------------------------
// Shared render helpers
// ---------------------------------------------------------------------------

async function generateBrief(leadId) {
  const container = document.getElementById('briefContainer');
  container.innerHTML = '<div class="loading">Drafting brief with Claude - this takes a few seconds...</div>';

  try {
    const res = await fetch(`/chris/leads/${leadId}/generate_brief`, { method: 'POST' });
    const data = await res.json();

    if (!data.success) {
      container.innerHTML = `<div class="node-phase"><h3 style="color:var(--status-red)">Could not generate brief</h3><p>${data.error}</p></div>`;
      return;
    }

    const warningsHtml = data.warnings.length
      ? `<div style="margin-bottom:12px">${data.warnings.map(w => badge(w, 'amber')).join(' ')}</div>`
      : '';

    container.innerHTML = `<div class="node-phase" style="max-width:800px">
      <h3>Pre-Call Brief</h3>
      ${warningsHtml}
      <pre style="white-space:pre-wrap;font-family:inherit;font-size:13px;color:var(--text-primary);line-height:1.6">${data.brief}</pre>
    </div>`;
  } catch (err) {
    container.innerHTML = `<div class="node-phase"><h3 style="color:var(--status-red)">Error</h3><p>${err.message}</p></div>`;
  }
}

function showLockDealForm(leadId) {
  const container = document.getElementById('lockDealFormContainer');
  container.innerHTML = `<div class="node-phase" style="max-width:500px">
    <h3>Lock Deal</h3>
    <div style="display:flex;flex-direction:column;gap:8px">
      <label style="font-size:11px;color:var(--text-secondary)">Contract Price (agreed with seller)</label>
      <input id="lockContractPrice" type="number" placeholder="75000" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Purchase Agreement Document URL</label>
      <input id="lockPurchaseAgreementUrl" placeholder="https://..." style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Assignment Fee Target</label>
      <input id="lockAssignmentFee" type="number" value="15000" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Exit Strategy</label>
      <select id="lockExitStrategy" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
        <option value="WHOLESALE_ASSIGNMENT">Wholesale Assignment</option>
        <option value="NOVATION">Novation</option>
        <option value="DOUBLE_CLOSE">Double Close</option>
      </select>
      <button onclick="submitLockDeal(${leadId})" style="padding:10px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;font-weight:600;cursor:pointer">Lock Deal &amp; Hand Off to Alex</button>
      <div id="lockDealStatus"></div>
    </div>
  </div>`;
}

async function submitLockDeal(leadId) {
  const statusEl = document.getElementById('lockDealStatus');
  const contract_price = Number(document.getElementById('lockContractPrice').value);
  const purchase_agreement_doc_url = document.getElementById('lockPurchaseAgreementUrl').value.trim();
  const assignment_fee_target = Number(document.getElementById('lockAssignmentFee').value) || 15000;
  const exit_strategy = document.getElementById('lockExitStrategy').value;

  if (!contract_price || !purchase_agreement_doc_url) {
    statusEl.innerHTML = '<span style="color:var(--status-red)">Contract price and purchase agreement URL are required.</span>';
    return;
  }

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Locking deal...</span>';
  try {
    const res = await fetch(`/chris/leads/${leadId}/lock_deal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contract_price, purchase_agreement_doc_url, assignment_fee_target, exit_strategy }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = `<span style="color:var(--status-green)">Locked — handed off to Alex as deal #${data.alex_deal_id}.</span>`;
      setTimeout(() => loadView(), 1500);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

async function doAssignFP(dealId, dealIndex) {
  const statusEl = document.getElementById('alexActionStatus');
  const select = document.getElementById(`fpSelect${dealId}`);
  const fpIndex = select.value;
  if (fpIndex === '') {
    statusEl.innerHTML = '<span style="color:var(--status-red)">Pick a financial partner first.</span>';
    return;
  }
  const fp = window._fpDataForAssign[fpIndex];

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Assigning...</span>';
  try {
    const res = await fetch(`/alex/deals/${dealId}/assign_fp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fp_id: fp.fp_id }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = `<span style="color:var(--status-green)">Assigned ${data.fp_name}.</span>`;
      setTimeout(() => loadView(), 800);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

function showTaylorHandoffForm(dealId) {
  const container = document.getElementById('taylorHandoffFormContainer');
  container.innerHTML = `<div class="node-phase" style="max-width:500px">
    <h3>Hand Off to Taylor</h3>
    <div style="display:flex;flex-direction:column;gap:8px">
      <label style="font-size:11px;color:var(--text-secondary)">EMD Amount</label>
      <input id="handoffEmdAmount" type="number" placeholder="5000" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">EMD Received Date</label>
      <input id="handoffEmdDate" type="date" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Target Close Date</label>
      <input id="handoffCloseDate" type="date" style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Assignment Agreement URL</label>
      <input id="handoffAssignmentUrl" placeholder="https://..." style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <label style="font-size:11px;color:var(--text-secondary)">Photos Package URL</label>
      <input id="handoffPhotosUrl" placeholder="https://..." style="padding:8px;background:var(--charcoal-lighter);border:1px solid var(--border-subtle);color:var(--text-primary);border-radius:6px">
      <button onclick="submitTaylorHandoff(${dealId})" style="padding:10px;background:var(--gold-light);color:var(--charcoal);border:none;border-radius:6px;font-weight:600;cursor:pointer">Send to Taylor</button>
      <div id="taylorHandoffStatus"></div>
    </div>
  </div>`;
}

async function submitTaylorHandoff(dealId) {
  const statusEl = document.getElementById('taylorHandoffStatus');
  const emd_amount = Number(document.getElementById('handoffEmdAmount').value);
  const emd_received_at = document.getElementById('handoffEmdDate').value;
  const close_date_target = document.getElementById('handoffCloseDate').value;
  const assignment_signed_doc_url = document.getElementById('handoffAssignmentUrl').value.trim();
  const photos_package_url = document.getElementById('handoffPhotosUrl').value.trim();

  if (!emd_amount || !emd_received_at || !close_date_target || !assignment_signed_doc_url || !photos_package_url) {
    statusEl.innerHTML = '<span style="color:var(--status-red)">All fields are required.</span>';
    return;
  }

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Sending to Taylor...</span>';
  try {
    const res = await fetch(`/alex/deals/${dealId}/handoff_to_taylor`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ emd_amount, emd_received_at, close_date_target, assignment_signed_doc_url, photos_package_url }),
    });
    const data = await res.json();
    if (data.success) {
      let msg = `Handed off — Taylor closing ID ${data.taylor_closing_id}.`;
      if (data.warning) msg += ` Warning: ${data.warning}`;
      statusEl.innerHTML = `<span style="color:var(--status-green)">${msg}</span>`;
      setTimeout(() => loadView(), 1500);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

async function submitNewAgent() {
  const statusEl = document.getElementById('newAgentStatus');
  const name = document.getElementById('newAgentName').value.trim();
  const phone = document.getElementById('newAgentPhone').value.trim();
  const email = document.getElementById('newAgentEmail').value.trim();
  const brokerage = document.getElementById('newAgentBrokerage').value.trim();

  if (!name || !phone) {
    statusEl.innerHTML = '<span style="color:var(--status-red)">Name and phone are required.</span>';
    return;
  }

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Adding...</span>';
  try {
    const res = await fetch('/chris/agents/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, phone, email: email || null, brokerage: brokerage || null }),
    });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = '<span style="color:var(--status-green)">Added.</span>';
      setTimeout(() => loadView(), 800);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

async function callAgent(agentId) {
  const statusEl = document.getElementById('agentCallStatus');
  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Dialing via Brielle...</span>';
  try {
    const res = await fetch(`/chris/agents/${agentId}/call`, { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      statusEl.innerHTML = `<span style="color:var(--status-green)">Call started (Vapi call ID: ${data.vapi_call_id}).</span>`;
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${data.error}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

async function submitNewLead() {
  const statusEl = document.getElementById('newLeadStatus');
  const address = document.getElementById('newLeadAddress').value.trim();
  const city = document.getElementById('newLeadCity').value.trim();
  const zip = document.getElementById('newLeadZip').value.trim();
  const ownerName = document.getElementById('newLeadOwnerName').value.trim();
  const ownerPhone = document.getElementById('newLeadOwnerPhone').value.trim();
  const arv = document.getElementById('newLeadArv').value.trim();

  if (!address || !city || !zip) {
    statusEl.innerHTML = '<span style="color:var(--status-red)">Address, city, and ZIP are required.</span>';
    return;
  }

  statusEl.innerHTML = '<span style="color:var(--text-secondary)">Adding...</span>';

  try {
    const res = await fetch('/chris/leads/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        address, city, zip,
        owner_name: ownerName || null,
        owner_phone: ownerPhone || null,
        arv: arv ? Number(arv) : null,
      }),
    });
    const data = await res.json();

    if (data.accepted) {
      statusEl.innerHTML = '<span style="color:var(--status-green)">Lead added successfully.</span>';
      setTimeout(() => loadView(), 800);
    } else {
      statusEl.innerHTML = `<span style="color:var(--status-red)">Not added: ${data.reason || 'unknown error'}</span>`;
    }
  } catch (err) {
    statusEl.innerHTML = `<span style="color:var(--status-red)">Error: ${err.message}</span>`;
  }
}

function kpiRow(pairs) {
  return `<div class="kpi-row">
    ${pairs.map(([label, value]) => `<div class="kpi-card">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value numeral">${value ?? 0}</div>
    </div>`).join('')}
  </div>`;
}

async function renderAlerts(main, url) {
  const { alerts } = await fetchJSON(url);
  if (!alerts.length) { main.innerHTML = emptyState('No alerts fired — pipeline is clean.'); return; }
  main.innerHTML = `<table class="data-table">
    <tr><th>Type</th><th>Severity</th><th>Message</th><th>Fired At</th></tr>
    ${alerts.map(a => `<tr>
      <td>${a.alert_type}</td>
      <td>${badge(a.severity, a.severity === 'CRITICAL' || a.severity === 'HIGH' ? 'red' : a.severity === 'WARN' || a.severity === 'MEDIUM' ? 'amber' : 'neutral')}</td>
      <td>${a.message || ''}</td>
      <td>${a.fired_at}</td>
    </tr>`).join('')}
  </table>`;
}

// Init
renderSubTabs();
loadView();
