---
name: fp-outreach
description: Use when first-touching a new financial partner (Mode 1 proactive hunt or Mode 2 deal-specific hunt), running buy-box intake, or maintaining relationship warm-up between deals. Complements fp-verification-red-flags.md, which governs whether to trust a partner once contact is established.
---

# Skill: Financial Partner Outreach

Source: outreach channels and the 5-Day Dispo attribution below are
real, from Jerry Norton's model as taught via Matt Beard's "checkbooks"
training. The message variants in Sections 3 and 5 are synthesized from
the established brand-voice rules (`context/terminology-and-brand-voice.md`)
and Alex's real responsibilities (`AGENTS.md`) — not verbatim scripts.

**Honest status:** Alex correctly identified that the brain had FP
verification (red flags) but no actual outreach script or channel list
— Chris has this for sellers and agents, Alex didn't have the
equivalent. The channels (Section 3) are now real, sourced material. If
Thomas has Matt Beard's actual verbatim message scripts, swap those in
for the drafted variants — the structure (tone, tiering, cadence)
should hold either way.

---

## 1. Two outreach modes

**Mode 1 — Proactive hunt.** No specific deal driving it — building
pipeline depth in a market. Runs on a slower cadence, casts a wider net.

**Mode 2 — Deal-specific hunt.** A locked deal needs a buyer beyond the
existing network right now (5-Day Dispo Day 2, per
`skill-5-day-dispo-process.md`). Faster, more targeted — search for
partners whose buy-box actually matches this specific property.

### Where Mode 1 actually hunts

Per Jerry Norton's model (via Matt Beard): use every channel available,
not just one — "use them all if you can, and if you can't, use as many
as you possibly can."

- **Investor lists** — purchased/aggregated buyer lists for the market
- **Facebook groups** — local real estate investor groups for the
  target metro
- **InvestorBase** (or equivalent buyer-list platform)
- **Dispo services** — third-party listing/dispo posting services, used
  alongside the direct email+SMS blast to the existing buyer list, not
  instead of it
- **Skip-traced active buyers** — buyers active in the target area who
  aren't on the list yet; this is a real, separate Day 2 task (call
  them directly, not a blast) — see `skill-5-day-dispo-process.md`

No single channel is "the" channel — the real reference point is that
the best deals sold have come from a mix of these, not reliance on one.
Mode 2 (deal-specific) should hit the same channels, just filtered
tighter to partners whose buy-box actually matches the specific
property.

### Two real tone rules confirmed by the source tool

- **Day 1 blast copy should be vague, not exhaustive** — the goal is
  to prompt a reply/question, not fully answer everything upfront.
  Over-explaining in the initial blast filters out the exact behavior
  (a reply) that identifies genuine interest.
- **Keep text light, move to a phone call** — texting is for
  surfacing interest and scheduling a call, not for negotiating or
  going deep on details. Once someone's engaged over text, the next
  move is always toward a real conversation, not a longer text thread.

---

## 2. Tone rules (hard, not stylistic)

- Peer-to-peer, never CRM-sounding or transactional — same rule Chris
  follows with sellers, applied to a different relationship
- Never say "cash buyers" or "investor list" — always "financial
  partners" / "funding network" (see terminology doc)
- Don't oversell a specific property in first-touch outreach — Mode 1
  is about establishing the relationship and buy-box, not pitching a
  deal
- Never reveal `contract_price` or `assignment_fee` — only
  `fp_facing_price` is ever shown, from the very first conversation
  onward, not just once a deal is real

---

## 3. First-touch message variants (Mode 1 — proactive)

Vary these, don't send the same one on repeat — same principle as
Chris's agent "poke" messages: multiple variants, not one canned line
repeated.

- *"Hey [Name] — we're picking up off-market deals in [market] pretty
  regularly right now. What's your buy box look like these days?"*
- *"Quick one — still actively buying in [market]? We've got a steady
  flow of off-market stuff and I'm trying to figure out who to loop
  in."*
- *"Been closing a few in [market] lately and building out our list of
  people we actually want to call first. What price range/condition
  are you working right now?"*

If no reply after the first touch, one follow-up 3–5 days later, then
into nurture (see Section 6) — don't chase past that on cold outreach.

---

## 4. Buy-box intake (once they respond)

Get these before assigning a VIP tier — VIP tier is earned by buy-box
completeness, not just responding:

1. Preferred ZIPs/markets
2. Price range (min/max)
3. Condition preference (turnkey / light rehab / heavy rehab / any)
4. Capacity (min/max deal size they can actually close)
5. Funding type — cold cash (close in 1-2 days) vs. private/hard money
   (7-14 days) — this matters for EMD tier and closing timeline
   expectations later
6. Proof of funds — request it here, don't wait until a specific deal
   is on the table (ties into `skill-fp-verification-red-flags.md` —
   inability to provide POF when asked is itself a red flag)

Incomplete buy-box → COLD tier regardless of how many deals they claim
to have closed elsewhere. Complete buy-box + verified POF → eligible
for WARM, moving to ACTIVE once they've engaged on a real deal, REPEAT
after a closed deal (see AGENTS.md's dispo-tier logic for how A/B/C
gets assigned from there).

---

## 5. Deal-specific blast messages (Mode 2 — Day 1 of 5-Day Dispo)

Per the real Day 1 timing: A-tier first, B-tier +4 hours, C-tier +8
hours or end of day. Message varies slightly by tier — A-tier gets more
direct/less selling since the relationship is already proven:

**A-tier:** *"Got one for you in [area] — [beds/baths, condition
one-liner]. FP price is [fp_facing_price]. Photos attached, let me know
if you want the full package."*

**B/C-tier:** *"New one just came in — [area], [beds/baths, condition
one-liner], asking [fp_facing_price]. Full details and photos below if
it fits your box."*

Never individually negotiate before the Day 4 showing window — if
asked to lower the price pre-showing, redirect to "let's get you
through it Thursday and go from there," per the one-showing-window
hard rule.

---

## 6. Relationship warm-up between deals

Repeat financial partners (closed at least one deal) are the highest-
leverage relationship in the network — roughly the same "1 in 3
produces a second deal" logic Chris tracks for agents applies here.
Don't let them go cold:

- Light-touch check-in every 4-6 weeks for REPEAT-tier partners: *"How'd
  [last closed property] turn out? Anything specific you're hunting
  for right now?"*
- Never a hard sell on these touches — the goal is staying top-of-mind,
  not closing on the message itself
- A REPEAT partner going quiet for 60+ days without a touch is a real
  gap — this should surface as a nurture item, not just fall off the
  list silently

---

## 7. Hard boundary with fp-verification-red-flags

This skill governs *how to reach out and what to ask*. It does not
override `skill-fp-verification-red-flags.md` — a financial partner
who responds well to outreach but trips a red flag (asks about the
assignment fee, wants to bring a JV partner before seeing the deal,
etc.) still gets treated as unverified. Good outreach tone doesn't
buy trust; the verification checklist does.
