"""
Intake + ZIP filter. Every lead from every scout module, FSBO scan,
FB webhook, or Gmail webhook passes through insert_lead() before it
becomes a real row in `leads`.

Rules from the spec, enforced here (not scattered across scout modules):
  - Normalize ZIP to 5-digit string
  - Join against market_zips; no match = DEAD, logged, stopped
  - Match = copy state/tier/multifamily_strong onto the lead
  - Insert with scout_list_tag = 'SCOUT_LIST_' + source
  - Queue REsimpli sync row
  - Normalize motivation values on write (fixes the HIGH vs HIGH_MOTIVATED
    schema drift found in the Twin build log)
"""

import re
from dataclasses import dataclass

from chris.db.db import get_connection

# Normalize any incoming motivation string to one of these three buckets.
# The build log showed 'HIGH_MOTIVATED' vs 'HIGH' causing leads to be
# invisible to filters — normalize ONCE here so nothing downstream needs
# a startsWith() band-aid.
MOTIVATION_NORMALIZE = {
    "HIGH": "HIGH",
    "HIGH_MOTIVATED": "HIGH",
    "MEDIUM": "MEDIUM",
    "MEDIUM_MOTIVATED": "MEDIUM",
    "LOW": "LOW",
    "LOW_MOTIVATED": "LOW",
}


@dataclass
class IntakeResult:
    accepted: bool
    lead_id: int | None = None
    reason: str | None = None


def normalize_zip(raw_zip: str) -> str:
    digits = re.sub(r"\D", "", raw_zip or "")
    return digits[:5].zfill(5) if digits else ""


def normalize_motivation(raw: str | None) -> str | None:
    if not raw:
        return None
    return MOTIVATION_NORMALIZE.get(raw.upper(), raw.upper())


def lookup_market_zip(conn, zip_code: str) -> dict | None:
    row = conn.execute(
        "SELECT zip, state, region_tier, multifamily_strong FROM market_zips WHERE zip = ?",
        (zip_code,),
    ).fetchone()
    return dict(row) if row else None


def insert_lead(
    *,
    address: str,
    city: str,
    raw_zip: str,
    source: str,
    owner_name: str | None = None,
    owner_phone: str | None = None,
    owner_email: str | None = None,
    motivation: str | None = None,
    arv: float | None = None,
    repairs_estimate: float | None = None,
    asking_price: float | None = None,
    mortgage_balance: float = 0,
    is_test_data: bool = False,
) -> IntakeResult:
    """
    The single entry point for every lead from every source. Returns
    IntakeResult(accepted=False) if the ZIP isn't in market_zips —
    callers should log that to scout_runs.in_market_results denominator
    themselves (this function only handles the leads table + ZIP gate).
    """
    conn = get_connection()
    try:
        zip_code = normalize_zip(raw_zip)
        market = lookup_market_zip(conn, zip_code)

        if not market:
            return IntakeResult(accepted=False, reason=f"ZIP {zip_code} not in market_zips")

        equity = None
        if arv is not None and mortgage_balance is not None:
            equity = arv - mortgage_balance

        cur = conn.execute(
            """
            INSERT INTO leads (
                address, city, state, zip, owner_name, owner_phone, owner_email,
                source, scout_list_tag, motivation, arv, repairs_estimate,
                asking_price, mortgage_balance, equity, is_test_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                address, city, market["state"], zip_code, owner_name, owner_phone, owner_email,
                source, f"SCOUT_LIST_{source}", normalize_motivation(motivation),
                arv, repairs_estimate, asking_price, mortgage_balance, equity,
                int(is_test_data),
            ),
        )
        lead_id = cur.lastrowid

        # Queue REsimpli sync (deferred until Thomas provides API auth)
        conn.execute(
            "INSERT INTO resimpli_sync_queue (lead_id, action) VALUES (?, ?)",
            (lead_id, "CREATE_LEAD"),
        )
        conn.execute(
            "INSERT INTO resimpli_sync_queue (lead_id, action) VALUES (?, ?)",
            (lead_id, "TAG"),
        )

        conn.commit()
        return IntakeResult(accepted=True, lead_id=lead_id)
    finally:
        conn.close()
