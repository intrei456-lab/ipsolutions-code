"""
IPSolutions agent system - entry point.

Runs a FastAPI app (for webhooks + manual triggers) alongside an
in-process APScheduler instance covering all three agents' scheduled
jobs. Each agent has its own SQLite database file; cross-agent reads
happen via direct same-box file access (see each agent's handoff/ingest
modules).

Run locally for testing:
    uvicorn main:app --reload --port 8000

Trigger jobs manually while testing:
    curl -X POST http://localhost:8000/chris/scouts/tax_delinquent_md/run
    curl -X POST http://localhost:8000/alex/kpi/run
    curl -X POST http://localhost:8000/taylor/sweeps/pending_followups/run

Deploy: see README.md for the systemd service setup on a VPS.
"""

from contextlib import asynccontextmanager
from datetime import date

from dotenv import load_dotenv
load_dotenv()  # Must run before any module reads os.environ (e.g. shared/llm_client.py)

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

from chris.db.db import init_db as chris_init_db, seed_market_zips
from chris.scouts import tax_delinquent_md
from alex.db.db import init_db as alex_init_db
from alex.dispo.kpi_rollup import compute_daily_kpi as alex_compute_kpi
from taylor.db.db import init_db as taylor_init_db, seed_node_template, seed_title_company_directory
from taylor.sweeps.daily_sweeps import pending_followups_sweep, closing_day_sweep, stall_detection_sweep
from taylor.nodes.kpi_and_archive import compute_kpi as taylor_compute_kpi

scheduler = AsyncIOScheduler(timezone="America/New_York")


# ---------------------------------------------------------------------------
# Chris's scheduled jobs
# ---------------------------------------------------------------------------

def run_chris_scout_pass_a():
    """7am ET daily. Currently runs the one live scout module; more get
    added here as they're built (see architecture doc build order)."""
    print("[scheduler] Chris: 7am scout pass A")
    tax_delinquent_md.run()
    # TODO as more scouts come online:
    # water_shutoff_md.run()
    # code_violations_md.run()
    # fl_county_rotation.run()
    # d4d_zip_rotation.run()


def run_daily_briefing():
    """
    7:30am ET daily - Thomas's morning digest across all three agents,
    matching what Matt Beard demonstrates as the crown jewel of his own
    build: real live data, AI-narrated, sent so it's waiting when he
    wakes up rather than something he has to go check for.
    """
    print("[scheduler] Sending daily briefing")
    from shared.daily_briefing import send_daily_briefing

    result = send_daily_briefing(use_ai_narration=True)
    print(f"[scheduler] Daily briefing sent: {result['sent']}")


# ---------------------------------------------------------------------------
# Alex's scheduled jobs
# ---------------------------------------------------------------------------

def run_alex_daily_kpi():
    """End-of-day KPI rollup for Alex."""
    print("[scheduler] Alex: daily KPI rollup")
    alex_compute_kpi()
    # TODO: Mode 1/2 pipeline review (9am), touch sweep (4pm) once the
    # actual outreach-sending loop is wired to a real channel (email/SMS provider).


# ---------------------------------------------------------------------------
# Taylor's scheduled jobs
# ---------------------------------------------------------------------------

def run_taylor_pending_followups():
    """3pm ET daily."""
    print("[scheduler] Taylor: pending follow-ups sweep")
    pending_followups_sweep()


def run_taylor_closing_day():
    """5pm ET daily."""
    print("[scheduler] Taylor: closing day sweep")
    today = date.today().isoformat()
    closing_day_sweep(today)
    stall_detection_sweep()
    taylor_compute_kpi("daily")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup - initialize all three agent databases
    chris_init_db()
    seed_market_zips()
    alex_init_db()
    taylor_init_db()
    seed_node_template()
    seed_title_company_directory()

    scheduler.add_job(run_chris_scout_pass_a, CronTrigger(hour=7, minute=0),
                       id="chris_scout_pass_a", replace_existing=True)
    scheduler.add_job(run_daily_briefing, CronTrigger(hour=7, minute=30),
                       id="daily_briefing", replace_existing=True)
    scheduler.add_job(run_alex_daily_kpi, CronTrigger(hour=20, minute=0),
                       id="alex_daily_kpi", replace_existing=True)
    scheduler.add_job(run_taylor_pending_followups, CronTrigger(hour=15, minute=0),
                       id="taylor_pending_followups", replace_existing=True)
    scheduler.add_job(run_taylor_closing_day, CronTrigger(hour=17, minute=0),
                       id="taylor_closing_day", replace_existing=True)
    scheduler.start()

    print("[startup] All 3 agent DBs initialized. Scheduler running:")
    print("  - Chris scout pass A: 7am ET")
    print("  - Daily briefing: 7:30am ET")
    print("  - Alex daily KPI: 8pm ET")
    print("  - Taylor pending follow-ups: 3pm ET")
    print("  - Taylor closing day + stall detection + KPI: 5pm ET")
    yield
    # Shutdown
    scheduler.shutdown()


app = FastAPI(title="IPSolutions Agents", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def dashboard():
    return FileResponse("static/index.html")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/workspace/daily_briefing/send_now")
def trigger_daily_briefing(use_ai_narration: bool = True):
    """On-demand test trigger, so this doesn't need to wait until 7:30am
    to verify it actually works."""
    from shared.daily_briefing import send_daily_briefing

    result = send_daily_briefing(use_ai_narration=use_ai_narration)
    return result


def _load_brain() -> str:
    """
    Loads the actual business knowledge from /brain - AGENTS.md, all
    skills (folder + SKILL.md, per Anthropic's Agent Skills open
    standard), all context files, and the memory file. This is the
    'Thomas Moyd Brain': the portable business knowledge that should
    survive a platform switch, not just live in Python data structures.
    """
    import os

    brain_dir = os.path.join(os.path.dirname(__file__), "brain")
    parts = []

    agents_path = os.path.join(brain_dir, "AGENTS.md")
    if os.path.exists(agents_path):
        with open(agents_path) as f:
            parts.append("=== AGENTS.md ===\n" + f.read())

    # Skills: each is its own folder with a SKILL.md inside
    skills_dir = os.path.join(brain_dir, "skills")
    if os.path.isdir(skills_dir):
        for skill_name in sorted(os.listdir(skills_dir)):
            skill_md_path = os.path.join(skills_dir, skill_name, "SKILL.md")
            if os.path.exists(skill_md_path):
                with open(skill_md_path) as f:
                    parts.append(f"=== skills/{skill_name}/SKILL.md ===\n" + f.read())

    # Context: flat markdown files
    context_dir = os.path.join(brain_dir, "context")
    if os.path.isdir(context_dir):
        for filename in sorted(os.listdir(context_dir)):
            if filename.endswith(".md"):
                with open(os.path.join(context_dir, filename)) as f:
                    parts.append(f"=== context/{filename} ===\n" + f.read())

    # Memory: single file, per Remy Gaskell's framework
    memory_path = os.path.join(brain_dir, "memory", "memory.md")
    if os.path.exists(memory_path):
        with open(memory_path) as f:
            parts.append("=== memory/memory.md ===\n" + f.read())

    return "\n\n".join(parts)


def _gather_workspace_context() -> str:
    """Pulls a live snapshot across all three agents' real databases so the
    workspace chat has actual current numbers, not stale training knowledge."""
    from chris.db.db import get_connection as chris_conn
    from alex.db.db import get_connection as alex_conn
    from taylor.db.db import get_connection as taylor_conn

    lines = []
    try:
        conn = chris_conn()
        leads = conn.execute("SELECT COUNT(*) c FROM leads WHERE is_test_data = 0").fetchone()["c"]
        conn.close()
        lines.append(f"Chris: {leads} lead(s) in the system.")
    except Exception:  # noqa: BLE001
        lines.append("Chris: database not yet queryable.")

    try:
        conn = alex_conn()
        deals = conn.execute("SELECT COUNT(*) c FROM deals").fetchone()["c"]
        fps = conn.execute("SELECT COUNT(*) c FROM financial_partners WHERE is_test_data = 0").fetchone()["c"]
        conn.close()
        lines.append(f"Alex: {deals} deal(s) in the pipeline, {fps} financial partners loaded.")
    except Exception:  # noqa: BLE001
        lines.append("Alex: database not yet queryable.")

    try:
        conn = taylor_conn()
        closings = conn.execute("SELECT COUNT(*) c FROM closings").fetchone()["c"]
        conn.close()
        lines.append(f"Taylor: {closings} closing(s) in the pipeline.")
    except Exception:  # noqa: BLE001
        lines.append("Taylor: database not yet queryable.")

    try:
        from shared.brain_loader import load_memory

        conn = taylor_conn()
        memory_text = load_memory()
        closed_rows = conn.execute(
            "SELECT address FROM closings WHERE status = 'closed' AND archived_at IS NOT NULL "
            "ORDER BY archived_at DESC LIMIT 10"
        ).fetchall()
        conn.close()
        pending = [r["address"] for r in closed_rows if r["address"] not in memory_text]
        if pending:
            lines.append(
                f"PENDING REFLECTIONS: {len(pending)} closed deal(s) have no lesson saved yet "
                f"({', '.join(pending[:3])}{'...' if len(pending) > 3 else ''}). "
                f"If it fits naturally in conversation, ask Thomas if there's anything worth "
                f"saving from one of these before he leaves the chat."
            )
    except Exception:  # noqa: BLE001
        pass

    return "\n".join(lines)


class WorkspaceChatMessage(BaseModel):
    role: str  # "user" or "assistant"
    content: str


class WorkspaceChatRequest(BaseModel):
    messages: list[WorkspaceChatMessage]


class MemoryLessonRequest(BaseModel):
    lesson: str


@app.post("/workspace/memory/add")
def add_memory_lesson(req: MemoryLessonRequest):
    """Appends a new lesson to brain/memory/memory.md - this is how the
    brain actually grows over time instead of staying static."""
    import os
    from datetime import date

    brain_dir = os.path.join(os.path.dirname(__file__), "brain")
    memory_path = os.path.join(brain_dir, "memory", "memory.md")

    entry = f"\n{date.today().isoformat()}: {req.lesson.strip()}\n"
    with open(memory_path, "a") as f:
        f.write(entry)

    return {"success": True}


@app.post("/workspace/chat")
def workspace_chat(req: WorkspaceChatRequest):
    """
    The 'Chief of Staff' chat, embedded directly in the command center.
    Not a separate agent - a live conversational layer with real-time
    visibility into Chris/Alex/Taylor's actual current data, PLUS the
    full business brain (AGENTS.md, skills, context, memory), running on
    the same server, using the same API key already configured.
    """
    from shared.llm_client import get_client, MODEL

    live_context = _gather_workspace_context()
    brain = _load_brain()

    system_prompt = f"""You are the Workspace Chat inside Thomas's IPSolutions
command center - his Chief of Staff for the business. You have live
visibility into Chris (Acquisitions), Alex (Dispositions), and Taylor
(Transaction Coordinator) - three AI agents that run this real estate
wholesaling/novation business.

You reason from the actual business brain below - this is real,
specific knowledge (acquisitions frameworks, dispositions process,
market data, terminology rules, past lessons), not generic real estate
advice. Ground your answers in this material rather than falling back
on general knowledge whenever it's relevant.

=== BUSINESS BRAIN ===
{brain}
=== END BUSINESS BRAIN ===

CURRENT LIVE STATE OF THE BUSINESS (as of this message):
{live_context}

You are not one of the three agents - you're the layer above them, the
way Twin's "Workspace Chat" used to work: Thomas talks to you about
strategy, deal updates, questions, and you have context on what's
actually happening across all three agents. You do not run in the
background 24/7 - you only exist while Thomas is actively chatting with
you, unlike the three agents which run continuously via a scheduler on
the server.

If Thomas tells you something worth remembering for the future (a
lesson from a deal, an objection pattern, a market insight), say so and
offer to save it - real lessons get written to brain/memory/lessons.md
via the /workspace/memory/add endpoint, so the brain actually improves
over time rather than staying static.

Be direct, concise, and grounded in the real numbers and brain content
above - don't invent activity that hasn't happened. If asked about
something outside your visibility (e.g. a call that hasn't been
logged), say so plainly rather than guessing."""

    try:
        client = get_client()
        response = client.messages.create(
            model=MODEL,
            max_tokens=1500,
            system=system_prompt,
            messages=[{"role": m.role, "content": m.content} for m in req.messages],
        )
        text = "".join(block.text for block in response.content if hasattr(block, "text"))
        return {"success": True, "reply": text}
    except Exception as exc:  # noqa: BLE001
        return {"success": False, "error": str(exc)}


# ---------------------------------------------------------------------------
# Chris endpoints
# ---------------------------------------------------------------------------

@app.post("/chris/scouts/tax_delinquent_md/run")
def trigger_tax_delinquent_md():
    result = tax_delinquent_md.run()
    return {"triggered": True, "result": result}


@app.get("/chris/leads")
def list_leads(limit: int = 50):
    from chris.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT lead_id, address, city, state, zip, source, status, motivation, "
        "arv, is_test_data, created_at FROM leads ORDER BY created_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return {"leads": [dict(r) for r in rows]}


class NewLeadRequest(BaseModel):
    address: str
    city: str
    zip: str
    source: str = "MANUAL"
    owner_name: str | None = None
    owner_phone: str | None = None
    owner_email: str | None = None
    motivation: str | None = None
    arv: float | None = None
    repairs_estimate: float | None = None
    asking_price: float | None = None
    mortgage_balance: float = 0


@app.post("/chris/leads/add")
def add_lead(lead: NewLeadRequest):
    from chris.intake.zip_filter import insert_lead

    result = insert_lead(
        address=lead.address,
        city=lead.city,
        raw_zip=lead.zip,
        source=lead.source,
        owner_name=lead.owner_name,
        owner_phone=lead.owner_phone,
        owner_email=lead.owner_email,
        motivation=lead.motivation,
        arv=lead.arv,
        repairs_estimate=lead.repairs_estimate,
        asking_price=lead.asking_price,
        mortgage_balance=lead.mortgage_balance,
    )
    if not result.accepted:
        return {"accepted": False, "reason": result.reason}
    return {"accepted": True, "lead_id": result.lead_id}


class LockDealRequest(BaseModel):
    contract_price: float
    purchase_agreement_doc_url: str
    assignment_fee_target: float = 15000
    exit_strategy: str = "WHOLESALE_ASSIGNMENT"
    risk_tier: str = "STANDARD"
    days_to_close: int = 14
    double_close_recommended: bool = False


@app.post("/chris/leads/{lead_id}/lock_deal")
def lock_deal(lead_id: int, req: LockDealRequest):
    """
    THE MISSING CONNECTIVE TISSUE: creates the real handoff from Chris to
    Alex once a contract is signed. Before this endpoint existed, Alex's
    ingest_handoff() was built and tested but nothing ever called it -
    each agent was a working island. This is what makes it a real
    assembly line instead of three disconnected stations.

    Also records the signed purchase agreement doc in Chris's contracts
    table - this is what eventually travels through to Taylor (and the
    title company) alongside the assignment agreement, so both real
    documents are on file when title work begins, not just the buyer
    side.
    """
    from chris.db.db import get_connection as chris_conn
    from alex.dispo.handoff_ingest import ingest_handoff

    conn = chris_conn()
    lead = conn.execute("SELECT * FROM leads WHERE lead_id = ?", (lead_id,)).fetchone()
    if lead is None:
        conn.close()
        return {"success": False, "error": "lead_not_found"}
    lead = dict(lead)

    result = ingest_handoff(
        lead_id=lead_id,
        address=lead["address"],
        city=lead["city"] or "",
        state=lead["state"] or "",
        zip_code=lead["zip"] or "",
        contract_price=req.contract_price,
        assignment_fee_target=req.assignment_fee_target,
        exit_strategy=req.exit_strategy,
        risk_tier=req.risk_tier,
        days_to_close=req.days_to_close,
        double_close_recommended=req.double_close_recommended,
    )

    if not result.accepted:
        conn.close()
        return {"success": False, "error": result.reason}

    conn.execute(
        "INSERT INTO contracts (lead_id, contract_type, signed_amount, signed_at, contract_doc_url) "
        "VALUES (?, 'PURCHASE', ?, datetime('now'), ?)",
        (lead_id, req.contract_price, req.purchase_agreement_doc_url),
    )
    conn.execute("UPDATE leads SET status = 'ACTIVE' WHERE lead_id = ?", (lead_id,))
    conn.commit()
    conn.close()

    return {"success": True, "alex_deal_id": result.deal_id}


@app.get("/chris/scout_runs")
def list_scout_runs(limit: int = 20):
    from chris.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM scout_runs ORDER BY run_at DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return {"scout_runs": [dict(r) for r in rows]}


@app.post("/chris/leads/{lead_id}/generate_brief")
def generate_brief(lead_id: int):
    """
    Pulls a real lead, computes the offer ladder from its ARV/repairs,
    calls Claude to draft the narrative sections, assembles the full
    12-section brief, and stores it in conversations (matching how the
    real system stores briefs: channel=EMAIL, outcome=BRIEF_DELIVERED).
    """
    from chris.db.db import get_connection
    from chris.conversation.offer_engine import compute_cash_ladder, decide_exit_strategy
    from chris.conversation.brief_generator import generate_llm_sections
    from chris.templates.pre_call_brief import (
        BriefInputs, PropertySnapshot, OwnerIntel, OfferLadder, assemble_full_brief,
    )

    conn = get_connection()
    lead = conn.execute("SELECT * FROM leads WHERE lead_id = ?", (lead_id,)).fetchone()
    if lead is None:
        conn.close()
        return {"success": False, "error": "lead_not_found"}
    lead = dict(lead)

    arv = lead["arv"] or 0
    if arv <= 0:
        conn.close()
        return {"success": False, "error": "Lead needs an ARV before a brief can be generated."}

    # Reasonable default if repairs weren't provided when the lead was added
    repairs = lead["repairs_estimate"] or (arv * 0.25)
    assignment_fee_target = 15000

    ladder = compute_cash_ladder(arv=arv, repairs=repairs, assignment_fee_target=assignment_fee_target)
    exit_strategy = decide_exit_strategy(rehab_cost=repairs, seller_wants_retail=False)

    inputs = BriefInputs(
        lead_id=str(lead_id),
        snapshot=PropertySnapshot(
            address=lead["address"], city=lead["city"] or "", state=lead["state"] or "",
            zip_code=lead["zip"] or "", source=lead["source"], property_type="Residential",
            days_on_market=0, risk_tier=lead["risk_tier"] or "STANDARD",
        ),
        owner=OwnerIntel(
            name=lead["owner_name"] or "Unknown - Discovery Required",
            phone=lead["owner_phone"], email=lead["owner_email"],
        ),
        offer=OfferLadder(
            arv=arv, repairs=repairs, t1_lowball=ladder.t1, mao_ceiling=ladder.mao_ceiling,
            novation_target=arv * 0.90, ask=lead["asking_price"],
        ),
        exit_strategy=exit_strategy,
        personality_hypothesis=None,
    )

    try:
        llm_result = generate_llm_sections(inputs)
    except Exception as exc:  # noqa: BLE001
        conn.close()
        return {"success": False, "error": f"LLM call failed: {exc}"}

    full_brief = assemble_full_brief(inputs, llm_result["text"])

    conn.execute(
        """
        INSERT INTO conversations (lead_id, channel, direction, outcome, body)
        VALUES (?, 'EMAIL', 'OUTBOUND', 'BRIEF_DELIVERED', ?)
        """,
        (lead_id, full_brief),
    )
    conn.execute("UPDATE leads SET status = 'RESEARCHED' WHERE lead_id = ?", (lead_id,))
    conn.commit()
    conn.close()

    return {
        "success": True,
        "brief": full_brief,
        "terminology_clean": llm_result["terminology_clean"],
        "spread_safety_clean": llm_result["spread_safety_clean"],
        "warnings": llm_result["warnings"],
    }


# ---------------------------------------------------------------------------
# Chris's daily KPI computation (mirrors alex/dispo/kpi_rollup.py's pattern -
# Chris never had an equivalent module built, so /chris/kpi computes live
# as a fallback when no daily_kpi row exists yet for today, rather than
# silently returning null.)
# ---------------------------------------------------------------------------

def _compute_chris_kpi_live(today: str) -> dict:
    from chris.db.db import get_connection

    conn = get_connection()
    leads_today = conn.execute(
        "SELECT COUNT(*) as c FROM leads WHERE date(created_at) = ? AND is_test_data = 0", (today,)
    ).fetchone()["c"]
    conversations_today = conn.execute(
        "SELECT COUNT(*) as c FROM conversations WHERE date(timestamp) = ?", (today,)
    ).fetchone()["c"]
    offers_today = conn.execute(
        "SELECT COUNT(*) as c FROM offers WHERE date(created_at) = ?", (today,)
    ).fetchone()["c"]
    contracts_today = conn.execute(
        "SELECT COUNT(*) as c FROM contracts WHERE date(signed_at) = ?", (today,)
    ).fetchone()["c"]
    fb_ad_leads = conn.execute(
        "SELECT COUNT(*) as c FROM leads WHERE date(created_at) = ? AND source = 'FB_AD'", (today,)
    ).fetchone()["c"]
    fsbo_leads = conn.execute(
        "SELECT COUNT(*) as c FROM leads WHERE date(created_at) = ? AND source = 'FSBO'", (today,)
    ).fetchone()["c"]
    scout_leads = conn.execute(
        "SELECT COUNT(*) as c FROM leads WHERE date(created_at) = ? AND source NOT IN ('FB_AD', 'FSBO')",
        (today,),
    ).fetchone()["c"]
    mat_beard_touches = conn.execute(
        "SELECT COUNT(*) as c FROM mat_beard_touches WHERE date(sent_at) = ?", (today,)
    ).fetchone()["c"]
    conn.close()

    return {
        "kpi_date": today,
        "leads_today": leads_today,
        "conversations_today": conversations_today,
        "offers_today": offers_today,
        "contracts_today": contracts_today,
        "fb_ad_leads": fb_ad_leads,
        "fsbo_leads": fsbo_leads,
        "scout_leads": scout_leads,
        "mat_beard_touches": mat_beard_touches,
    }


class AddAgentRequest(BaseModel):
    name: str
    phone: str
    email: str | None = None
    brokerage: str | None = None
    tier: str = "TIER_3"
    notes: str | None = None


@app.post("/chris/agents/add")
def add_agent(req: AddAgentRequest):
    """Adds a real estate agent contact - the missing piece that existed
    as tiering logic in mat_beard.py but had nowhere to actually store
    agent records until now."""
    from chris.db.db import get_connection

    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO agents (name, phone, email, brokerage, tier, notes) VALUES (?, ?, ?, ?, ?, ?)",
        (req.name, req.phone, req.email, req.brokerage, req.tier, req.notes),
    )
    agent_id = cur.lastrowid
    conn.commit()
    conn.close()
    return {"success": True, "agent_id": agent_id}


@app.get("/chris/agents")
def list_agents(limit: int = 50):
    from chris.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT agent_id, name, phone, email, brokerage, tier, last_contact_at, "
        "last_call_outcome FROM agents WHERE is_test_data = 0 ORDER BY agent_id DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return {"agents": [dict(r) for r in rows]}


@app.post("/chris/agents/{agent_id}/call")
def call_agent(agent_id: int):
    """
    Triggers Brielle (via Vapi) to actually call this agent - real voice
    outreach, sidestepping the A2P 10DLC SMS registration process
    entirely since this is a phone call, not a text message.
    """
    from chris.db.db import get_connection
    from shared.vapi_client import trigger_agent_outbound_call

    conn = get_connection()
    agent = conn.execute("SELECT * FROM agents WHERE agent_id = ?", (agent_id,)).fetchone()
    if agent is None:
        conn.close()
        return {"success": False, "error": "agent_not_found"}
    agent = dict(agent)

    if not agent["phone"]:
        conn.close()
        return {"success": False, "error": "This agent has no phone number on file."}

    try:
        result = trigger_agent_outbound_call(agent["name"], agent["phone"], agent_id)
    except Exception as exc:  # noqa: BLE001
        conn.close()
        return {"success": False, "error": f"Vapi call failed: {exc}"}

    vapi_call_id = result.get("id")
    conn.execute(
        "UPDATE agents SET last_contact_at = datetime('now'), last_vapi_call_id = ? WHERE agent_id = ?",
        (vapi_call_id, agent_id),
    )
    conn.execute(
        "INSERT INTO agent_call_log (agent_id, vapi_call_id, direction, call_started_at) "
        "VALUES (?, ?, 'OUTBOUND', datetime('now'))",
        (agent_id, vapi_call_id),
    )
    conn.commit()
    conn.close()

    return {"success": True, "vapi_call_id": vapi_call_id}


@app.post("/vapi/webhook")
async def vapi_webhook(request: Request):
    """
    Receives call events back from Vapi once a call ends - the transcript
    and outcome. This is what lets Chris actually learn from agent calls
    instead of them disappearing into Vapi with no record on our side.
    """
    from chris.db.db import get_connection

    payload = await request.json()
    message = payload.get("message", {})

    if message.get("type") != "end-of-call-report":
        return {"received": True, "ignored": True}

    call = message.get("call", {})
    vapi_call_id = call.get("id")
    transcript = message.get("transcript", "")
    ended_reason = message.get("endedReason", "")

    conn = get_connection()
    agent_row = conn.execute(
        "SELECT agent_id FROM agents WHERE last_vapi_call_id = ?", (vapi_call_id,)
    ).fetchone()

    if agent_row:
        agent_id = agent_row["agent_id"]
        conn.execute(
            "UPDATE agents SET last_call_outcome = ? WHERE agent_id = ?",
            (ended_reason, agent_id),
        )
        conn.execute(
            "UPDATE agent_call_log SET transcript = ?, outcome = ?, call_ended_at = datetime('now') "
            "WHERE vapi_call_id = ?",
            (transcript, ended_reason, vapi_call_id),
        )
        conn.commit()

    conn.close()
    return {"received": True}


@app.get("/chris/kpi")
def chris_kpi():
    from chris.db.db import get_connection

    today = date.today().isoformat()
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM daily_kpi WHERE kpi_date = ?", (today,)
    ).fetchone()
    conn.close()

    if row:
        return {"kpi": dict(row)}
    # No scheduled rollup has run yet today - compute live rather than
    # returning null, so the dashboard always shows something real.
    return {"kpi": _compute_chris_kpi_live(today)}


# ---------------------------------------------------------------------------
# Alex endpoints
# ---------------------------------------------------------------------------

@app.post("/alex/kpi/run")
def trigger_alex_kpi():
    return {"triggered": True, "result": alex_compute_kpi()}


@app.get("/alex/deals")
def list_alex_deals(limit: int = 50):
    from alex.db.db import get_connection as alex_conn
    from chris.db.db import get_connection as chris_conn

    conn = alex_conn()
    rows = conn.execute(
        "SELECT deal_id, lead_id, dispo_status, exit_strategy, dispo_day, "
        "fp_facing_price, fp_assigned_id, created_at FROM deals ORDER BY created_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    deals = [dict(r) for r in rows]

    # Cross-db read to show the real address next to each deal - address
    # lives on Chris's side, deals only store the lead_id reference.
    if deals:
        chris_c = chris_conn()
        for deal in deals:
            lead = chris_c.execute(
                "SELECT address, city, state FROM leads WHERE lead_id = ?", (deal["lead_id"],)
            ).fetchone()
            deal["address"] = f"{lead['address']}, {lead['city']} {lead['state']}" if lead else "Unknown"
        chris_c.close()

    return {"deals": deals}


class AssignFPRequest(BaseModel):
    fp_id: int


@app.post("/alex/deals/{deal_id}/assign_fp")
def assign_fp(deal_id: int, req: AssignFPRequest):
    """Assigns a financial partner to a deal - the step that has to happen
    before handoff_to_taylor can work, since that endpoint requires
    fp_assigned_id to already be set."""
    from alex.db.db import get_connection

    conn = get_connection()
    fp = conn.execute("SELECT fp_id, entity_name FROM financial_partners WHERE fp_id = ?", (req.fp_id,)).fetchone()
    if fp is None:
        conn.close()
        return {"success": False, "error": "financial_partner_not_found"}

    conn.execute("UPDATE deals SET fp_assigned_id = ? WHERE deal_id = ?", (req.fp_id, deal_id))
    conn.commit()
    conn.close()
    return {"success": True, "fp_name": fp["entity_name"]}


@app.get("/alex/financial_partners")
def list_financial_partners(limit: int = 50):
    from alex.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT fp_id, entity_name, vip_tier, dispo_tier, relationship_stage, "
        "total_deals_closed, phone, email FROM financial_partners WHERE is_test_data = 0 "
        "ORDER BY fp_id LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return {"financial_partners": [dict(r) for r in rows]}


class UpdateFPContactRequest(BaseModel):
    email: str | None = None
    phone: str | None = None


@app.post("/alex/financial_partners/{fp_id}/update_contact")
def update_fp_contact(fp_id: int, req: UpdateFPContactRequest):
    """
    Fills in missing contact info for a real financial partner - this is
    what unblocks the Alex to Taylor handoff, since Taylor requires a
    complete email before a real deal can hand off. Only updates fields
    that were actually provided, so a partial edit doesn't wipe out an
    existing phone number when only adding an email, or vice versa.
    """
    from alex.db.db import get_connection

    if req.email is None and req.phone is None:
        return {"success": False, "error": "Provide at least an email or phone to update."}

    conn = get_connection()
    fp = conn.execute("SELECT fp_id FROM financial_partners WHERE fp_id = ?", (fp_id,)).fetchone()
    if fp is None:
        conn.close()
        return {"success": False, "error": "financial_partner_not_found"}

    if req.email is not None:
        conn.execute("UPDATE financial_partners SET email = ? WHERE fp_id = ?", (req.email, fp_id))
    if req.phone is not None:
        conn.execute("UPDATE financial_partners SET phone = ? WHERE fp_id = ?", (req.phone, fp_id))
    conn.commit()
    conn.close()

    return {"success": True}


@app.get("/alex/kpi")
def alex_kpi():
    from alex.db.db import get_connection

    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM dispo_kpi ORDER BY kpi_date DESC LIMIT 1"
    ).fetchone()
    conn.close()
    return {"kpi": dict(row) if row else None}


@app.get("/alex/ceo_alerts")
def alex_ceo_alerts(limit: int = 20):
    from alex.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM ceo_alerts ORDER BY fired_at DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return {"alerts": [dict(r) for r in rows]}


class HandoffToTaylorRequest(BaseModel):
    emd_amount: float
    emd_received_at: str
    close_date_target: str
    assignment_signed_doc_url: str
    photos_package_url: str
    days_to_close: int = 14


@app.post("/alex/deals/{deal_id}/handoff_to_taylor")
def handoff_to_taylor(deal_id: int, req: HandoffToTaylorRequest):
    """
    THE SECOND MISSING CONNECTIVE PIECE: creates the real handoff from
    Alex to Taylor once a financial partner is signed. Pulls the deal's
    FP details from Alex's own database, and the address from Chris's
    leads table via the deal's lead_id (cross-db read, same pattern
    used everywhere else in this system).
    """
    from alex.db.db import get_connection as alex_conn
    from chris.db.db import get_connection as chris_conn
    from taylor.nodes.engine import ingest_new_handoff

    conn = alex_conn()
    deal = conn.execute("SELECT * FROM deals WHERE deal_id = ?", (deal_id,)).fetchone()
    if deal is None:
        conn.close()
        return {"success": False, "error": "deal_not_found"}
    deal = dict(deal)

    if not deal.get("fp_assigned_id"):
        conn.close()
        return {"success": False, "error": "No financial partner assigned to this deal yet."}

    fp = conn.execute(
        "SELECT * FROM financial_partners WHERE fp_id = ?", (deal["fp_assigned_id"],)
    ).fetchone()
    conn.close()
    if fp is None:
        return {"success": False, "error": "Assigned financial partner not found."}
    fp = dict(fp)

    # Address AND the signed purchase agreement live on Chris's side -
    # cross-db reads via the deal's lead_id. Both the seller's purchase
    # agreement and the buyer's assignment agreement need to reach
    # Taylor (and eventually the title company) - not just the buyer side.
    chris_conn_obj = chris_conn()
    lead = chris_conn_obj.execute(
        "SELECT address, city, state, zip FROM leads WHERE lead_id = ?", (deal["lead_id"],)
    ).fetchone()
    purchase_contract = chris_conn_obj.execute(
        "SELECT contract_doc_url FROM contracts WHERE lead_id = ? AND contract_type = 'PURCHASE' "
        "ORDER BY contract_id DESC LIMIT 1",
        (deal["lead_id"],),
    ).fetchone()
    chris_conn_obj.close()
    if lead is None:
        return {"success": False, "error": "Could not find the originating lead's address."}
    lead = dict(lead)
    seller_contract_doc_url = purchase_contract["contract_doc_url"] if purchase_contract else None

    handoff_payload = {
        "deal_id": deal_id,
        "address": lead["address"],
        "city": lead["city"],
        "state": lead["state"],
        "zip": lead["zip"],
        "fp_name": fp["entity_name"],
        "fp_email": fp["email"],
        "fp_phone": fp["phone"],
        "fp_entity": fp["entity_name"],
        "emd_amount": req.emd_amount,
        "emd_received_at": req.emd_received_at,
        "close_date_target": req.close_date_target,
        "seller_contract_doc_url": seller_contract_doc_url,
        "assignment_signed_doc_url": req.assignment_signed_doc_url,
        "photos_package_url": req.photos_package_url,
        "days_to_close": req.days_to_close,
    }

    result = ingest_new_handoff(handoff_payload)
    if result.get("accepted"):
        conn = alex_conn()
        conn.execute("UPDATE deals SET dispo_status = 'TAYLOR_HANDOFF' WHERE deal_id = ?", (deal_id,))
        conn.commit()
        conn.close()
        response = {"success": True, "taylor_closing_id": result["closing_id"]}
        if seller_contract_doc_url is None:
            response["warning"] = (
                "No purchase agreement was found on file for this lead - Taylor's "
                "Node 5 (seller contract confirmation) will be blocked until it's added."
            )
        return response

    return {"success": False, "error": result.get("message", "Handoff was not accepted by Taylor.")}


# ---------------------------------------------------------------------------
# Taylor endpoints
# ---------------------------------------------------------------------------

@app.post("/taylor/sweeps/pending_followups/run")
def trigger_taylor_followups():
    return {"triggered": True, "result": pending_followups_sweep()}


@app.post("/taylor/sweeps/closing_day/run")
def trigger_taylor_closing_day():
    today = date.today().isoformat()
    return {"triggered": True, "result": closing_day_sweep(today)}


@app.get("/taylor/closings")
def list_closings(limit: int = 50):
    from taylor.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT closing_id, address, current_node, status, risk_tier, "
        "close_date_target, started_at FROM closings ORDER BY started_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return {"closings": [dict(r) for r in rows]}


@app.get("/taylor/closings/{closing_id}/nodes")
def get_closing_nodes(closing_id: int):
    from taylor.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        """
        SELECT cn.node_number, cn.status, cn.blocking_reason, cn.notes,
               nt.title, nt.phase
        FROM closing_nodes cn
        JOIN node_template nt ON nt.node_number = cn.node_number
        WHERE cn.closing_id = ?
        ORDER BY cn.node_number
        """,
        (closing_id,),
    ).fetchall()
    conn.close()
    return {"nodes": [dict(r) for r in rows]}


@app.get("/taylor/ceo_alerts")
def taylor_ceo_alerts(limit: int = 20):
    from taylor.db.db import get_connection

    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM ceo_alerts ORDER BY fired_at DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return {"alerts": [dict(r) for r in rows]}


@app.get("/workspace/pending_reflections")
def pending_reflections():
    """
    The memory 'habit' mechanism: rather than relying on Thomas to
    remember to save a lesson, surface a prompt for every closed deal
    that doesn't yet have a memory entry mentioning its address. Crude
    heuristic (address-string match against memory.md) but genuinely
    functional - this is what turns memory from a passive text field
    into something the system actively nudges toward filling in.
    """
    from taylor.db.db import get_connection
    from shared.brain_loader import load_memory

    memory_text = load_memory()

    conn = get_connection()
    rows = conn.execute(
        "SELECT closing_id, address, archived_at FROM closings "
        "WHERE status = 'closed' AND archived_at IS NOT NULL "
        "ORDER BY archived_at DESC LIMIT 10"
    ).fetchall()
    conn.close()

    pending = [
        {"closing_id": r["closing_id"], "address": r["address"], "archived_at": r["archived_at"]}
        for r in rows
        if r["address"] not in memory_text
    ]
    return {"pending": pending}
