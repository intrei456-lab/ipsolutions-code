"""
Vapi integration - triggers Brielle (the voice assistant already built and
configured in Thomas's Vapi account) to call real estate agents. This
sidesteps A2P 10DLC entirely, since voice calls aren't SMS - which is why
this was prioritized ahead of finishing SMS compliance.

Real API confirmed against Vapi's docs (docs.vapi.ai/api-reference/calls/create):
POST https://api.vapi.ai/call/phone, Bearer auth, phoneNumberId + assistantId
+ customer.number.

NOTE: requires real VAPI_API_KEY/VAPI_ASSISTANT_ID/VAPI_PHONE_NUMBER_ID and
network access - not testable in this sandbox. The customer.metadata.isAgent
flag below matches what Vapi's own assistant confirmed as a viable pattern
during Thomas's setup conversation with them - worth double-checking in the
Vapi dashboard after the first real test call that it actually reaches
Brielle's dual-trigger logic as expected.
"""

import os

import requests

VAPI_BASE_URL = "https://api.vapi.ai"


def _get_credentials() -> dict:
    api_key = os.environ.get("VAPI_API_KEY")
    assistant_id = os.environ.get("VAPI_ASSISTANT_ID")
    phone_number_id = os.environ.get("VAPI_PHONE_NUMBER_ID")
    if not all([api_key, assistant_id, phone_number_id]):
        raise RuntimeError(
            "VAPI_API_KEY, VAPI_ASSISTANT_ID, and VAPI_PHONE_NUMBER_ID must all be "
            "set in .env for Brielle's calling integration to work."
        )
    return {"api_key": api_key, "assistant_id": assistant_id, "phone_number_id": phone_number_id}


def trigger_agent_outbound_call(agent_name: str, agent_phone: str, agent_id: int) -> dict:
    """
    Triggers Brielle to call a real estate agent. Tags the customer as an
    agent via metadata so Brielle's AGENT OUTREACH MODE dual-trigger fires
    (per the routing logic worked out directly with Vapi) - this is the
    'Chris will also let her know it's an agent when he sends it through'
    tagging Thomas described.
    """
    creds = _get_credentials()

    payload = {
        "phoneNumberId": creds["phone_number_id"],
        "assistantId": creds["assistant_id"],
        "customer": {
            "number": agent_phone,
            "name": agent_name,
        },
        "metadata": {
            "isAgent": True,
            "agentType": "agent",
            "source": "chris_agent_outreach",
            "agent_id": agent_id,
        },
    }

    response = requests.post(
        f"{VAPI_BASE_URL}/call/phone",
        headers={
            "Authorization": f"Bearer {creds['api_key']}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=15,
    )
    response.raise_for_status()
    return response.json()
