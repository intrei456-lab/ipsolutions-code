"""
Terminology lock — post-generation check run on every piece of
LLM-drafted or template-rendered content before it goes out the door
(email, SMS, call script, brief). Catches banned terms and flags them
rather than silently rewriting, since some (like "wholesale") are
context-dependent and a bad auto-swap could produce nonsense.

Usage:
    from shared.terminology import check_terminology

    result = check_terminology(draft_text)
    if not result.clean:
        # log result.violations, regenerate or manually fix before sending
        ...
"""

import re
from dataclasses import dataclass, field

from shared.config import BANNED_TERMS

# Terms that are unambiguous find/replace (no context needed)
SAFE_AUTO_REPLACE = {
    "innovation": "novation",  # misspelling, not a real synonym conflict
}

# Terms that need a human/LLM second pass rather than blind replacement,
# because the "correct" replacement depends on sentence context.
CONTEXT_SENSITIVE_TERMS = {
    "buyer", "buyers", "cash buyer", "cash buyers",
    "investor list", "wholesale", "reselling",
}


@dataclass
class TerminologyCheckResult:
    clean: bool
    violations: list[str] = field(default_factory=list)
    auto_fixed_text: str = ""


def _word_boundaries(term: str) -> re.Pattern:
    return re.compile(rf"\b{re.escape(term)}\b", re.IGNORECASE)


def check_terminology(text: str) -> TerminologyCheckResult:
    """
    Scan outbound text for banned terminology.

    - Safe auto-replace terms (e.g. "innovation" -> "novation") are fixed
      automatically and returned in auto_fixed_text.
    - Context-sensitive terms are flagged in `violations` for a human or a
      second LLM pass to fix properly (e.g. "wholesale" might legitimately
      appear in an unrelated sentence, or might need to become "assignment").
    """
    violations = []
    fixed_text = text

    # Auto-fix unambiguous misspellings
    for wrong, right in SAFE_AUTO_REPLACE.items():
        pattern = _word_boundaries(wrong)
        if pattern.search(fixed_text):
            fixed_text = pattern.sub(right, fixed_text)

    # Flag context-sensitive banned terms
    for term in CONTEXT_SENSITIVE_TERMS:
        if _word_boundaries(term).search(text):
            replacement = BANNED_TERMS.get(term, "[needs manual review]")
            violations.append(f'"{term}" found — should likely be "{replacement}"')

    return TerminologyCheckResult(
        clean=len(violations) == 0,
        violations=violations,
        auto_fixed_text=fixed_text,
    )


def assert_clean_or_raise(text: str, source: str = "") -> str:
    """
    Convenience wrapper for use right before sending any outbound message.
    Raises if context-sensitive violations are present (forces a fix rather
    than silently sending bad terminology), returns the auto-fixed text
    if only safe replacements were needed.
    """
    result = check_terminology(text)
    if not result.clean:
        raise ValueError(
            f"Terminology violation in outbound content"
            f"{f' ({source})' if source else ''}: {result.violations}"
        )
    return result.auto_fixed_text
