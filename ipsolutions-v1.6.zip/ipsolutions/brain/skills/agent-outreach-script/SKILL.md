---
name: agent-outreach-script
description: Use for any agent outreach conversation - text or call - especially the opening approach and objection handling. Applies to both Chris's text-based outreach and Brielle's voice calls (Vapi).
---

# Skill: Agent Outreach Script

Source: Matt Beard, real estate agent outreach training. This is the
actual script and rules - not a summary. Text is the primary channel
(most effective), but the same script works on calls too, which is why
this applies to both Chris (text) and Brielle (voice, via Vapi).

## The core economics (why this approach, specifically)

- Off-market-only leads convert at **12-20 leads to 1 closed deal**.
  Accepting ALL properties (not just off-market) drops this to **41-62
  leads to 1 close** — roughly 3x worse. This is why the script never
  deviates from "properties that haven't hit the market yet."
- Volume target: **300-500 texts per day**, yielding roughly **3-8
  off-market properties per day** at that scale.
- Average deal cost: **$100-150** (essentially just the cost of texting
  that many people).
- Resulting margin: **75-78%**.
- **This only works with real volume.** If someone says "I've reached
  out to agents and haven't gotten deals," the real question is whether
  they've actually sent 300-500 texts a day for a month straight — most
  people who feel this doesn't work were never doing real volume.

## The opener: assume prior contact

**Do not open as a cold, first-time outreach.** Assume you already
reached out before, even on a genuine first touch:

> "Hey, I reached out about a month ago, hadn't got a chance to
> connect yet — it was about properties that need some work..."

This reads completely differently than a cold "hey, just checking in,
this is [name]" — it implies an existing (if faint) relationship rather
than an unsolicited pitch, and lowers the recipient's guard.

If they say "who is this? I don't know a [name]":

> "Oh, I'm sorry, this is [name] — I'd reached out about fixers
> probably a little over a month ago, hadn't got a chance to connect
> quite yet. Do you have anything coming up soon that I can maybe take
> a look at?"

Notice this response **ends in a question** — see the hard rule below.

## The hard rule: every objection answer ends in a question

**This is not optional or situational — every single objection
response must end by asking the prospect something**, so the
conversation keeps moving forward instead of dying on the objection.
Never let an objection be the last word in the exchange.

## The core sequence

1. Assume-prior-contact opener (above)
2. If they have something: move to Phase 2 (Call/Comp/Close) — collect
   address, on/off-market, condition, ask price, timeline
3. If they don't have anything right now: ask "how often do you run
   across properties that need some work / aren't market-ready?" —
   this reframes the conversation from a single ask to an ongoing
   relationship
4. Regardless of their answer: "We buy all kinds of properties,
   including multifamily and commercial. Do you know of anyone that
   may have something coming soon? We'd be happy to have you represent
   us in the transaction." (Only include the multifamily/commercial
   line if actually true for this business, and only in a call - drop
   the "putting a voice to the name" framing entirely when texting,
   since it only makes sense spoken.)
5. If they genuinely have nothing and no leads: thank them, offer a
   follow-up if welcomed, categorize as **Tier 3** (see existing
   agent-tier system) — this is a normal, expected, non-failure outcome
   for most contacts. Most of a day's 300-500 touches will land here or
   with no response; only 3-8 properties per day is the real, expected
   yield.

## Real objections and answers (always end each with a question back)

| Objection | Real answer |
|---|---|
| "Do you have proof of funds?" | Have it ready to reference/send. Fair, expected question — answer directly, then continue the sequence. |
| "What's your buy box?" | "Typically we buy in and around the medium price point, not much on the luxury side. We're normally very competitive with our offers. The home has at least 3 beds and 2 baths, is newer than 1970, and ideally needs some work." (Broad on purpose — matches where most institutional buyers and fix-and-flippers are actually buying.) |
| "Are you an investor or a wholesaler?" | Answer honestly per this business's real terminology (financial partners / funding network framing) — never claim to be something you're not. |
| "What company do you work for?" | State the real company name plainly. |
| "How did you get my number?" | Answer honestly about the actual lead source. |
| "How does an agent get paid in this situation?" | "The seller pays the buyer's agent commission — we're happy to let you represent us and get paid for bringing the opportunity." |
| "I only send deals to people who sign my brokerage agreement." | Treat as a real, reasonable business requirement — don't get defensive; ask what their process looks like. |
| "I'm a flipper/investor myself." | Genuine opportunity to build a peer relationship, not just a lead source — ask what they're looking for themselves. |
| "What properties are you interested in?" (when they don't recognize you) | "Are you an agent?" — confirm who you're speaking with before re-pitching. |
| "I'm licensed in [state], remove me from your list." | **Still ask one more question before removing them** — per the source material, a meaningful number of people who initially say "stop" convert when given one more genuine question. Don't just comply silently; ask "before I do — is there any chance you run across off-market stuff even occasionally?" Then honor their answer either way. |

## Market context worth knowing (not a script line, background understanding)

In buyer-heavy markets (higher rates, price uncertainty), sellers and
their agents are more affected by softening prices than buyers are —
meaning agents have real incentive to want a reliable, fast buyer
relationship right now. This isn't something to say verbatim to a
prospect, but it's useful context for why relationship-building with
agents who have "nothing right now" is a genuinely good use of time,
not a wasted touch.
