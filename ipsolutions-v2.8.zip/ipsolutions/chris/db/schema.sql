-- Chris (Acquisitions) database schema
-- Source of execution truth for the acquisitions agent.
-- NOTE: field names below were corrected against real bugs discovered in
-- the Twin build log (e.g. handoffs has property_condition_signals, not notes).

CREATE TABLE IF NOT EXISTS market_zips (
    zip TEXT PRIMARY KEY,
    state TEXT NOT NULL,
    region_tier TEXT NOT NULL,          -- primary/secondary/tertiary
    multifamily_strong INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS leads (
    lead_id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT NOT NULL,
    city TEXT,
    state TEXT,
    zip TEXT,
    owner_name TEXT,
    owner_phone TEXT,
    owner_email TEXT,
    owner_verified INTEGER DEFAULT 0,
    source TEXT NOT NULL,                -- e.g. TAX_DELINQUENT, FSBO, VIRTUAL_D4D, AGENT_REFERRAL
    agent_id INTEGER REFERENCES agents(agent_id),  -- set when source=AGENT_REFERRAL, links back to who gave the address
    setup_call_outcome TEXT,             -- GREEN/RED/PENDING - only meaningful for AGENT_REFERRAL leads, see chris/scouts/agent_lead_creation.py
    scout_list_tag TEXT,                 -- SCOUT_LIST_[SOURCE]
    status TEXT DEFAULT 'NEW',           -- NEW/RESEARCHED/WORKING/ACTIVE/DEAD/DO_NOT_CONTACT/...
    -- NOTE: normalize motivation on write, not on read. Never store
    -- HIGH_MOTIVATED alongside HIGH for the same concept (see build-log bug).
    motivation TEXT,                     -- HIGH/MEDIUM/LOW/NULL
    motivation_reason TEXT,
    arv REAL,
    repairs_estimate REAL,
    asking_price REAL,
    mortgage_balance REAL DEFAULT 0,
    equity REAL,
    distress_score INTEGER,              -- 0-10
    deal_score INTEGER,                  -- 0-99 composite, drives A/B/C/D grade
    pains_count INTEGER DEFAULT 0,
    risk_tier TEXT DEFAULT 'STANDARD',   -- STANDARD / PROTECT_SPREAD
    risk_tier_flipped_at TEXT,
    risk_tier_reason TEXT,
    is_test_data INTEGER DEFAULT 0,      -- flag seed/fake data explicitly, never mix silently
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS conversations (
    conversation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER NOT NULL REFERENCES leads(lead_id),
    channel TEXT NOT NULL,               -- CALL/SMS/EMAIL
    direction TEXT NOT NULL,             -- INBOUND/OUTBOUND
    outcome TEXT,                        -- e.g. BRIEF_DELIVERED (used for seller call prep storage)
    transcript TEXT,
    body TEXT,                           -- full rendered content (e.g. the brief itself)
    call_grade TEXT,                     -- GREEN/YELLOW/RED
    personality_read TEXT,               -- GREEN/RED/BLUE/YELLOW (Keith Everett framework)
    pains_uncovered INTEGER DEFAULT 0,
    opener_used TEXT,
    objections_handled TEXT,             -- JSON array
    timestamp TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS agents (
    agent_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    brokerage TEXT,
    tier TEXT DEFAULT 'TIER_3',          -- TIER_1/TIER_2/TIER_3/DEAD (see chris/scouts/mat_beard.py AgentTier)
    ever_reached_tier_1 INTEGER DEFAULT 0,  -- permanent flag, see chris/scouts/agent_tier_transitions.py
    deal_closed INTEGER DEFAULT 0,          -- permanent flag, locks tier at TIER_1 forever once set
    last_contact_at TEXT,
    last_call_outcome TEXT,
    last_vapi_call_id TEXT,
    notes TEXT,
    is_test_data INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS agent_tier_history (
    history_id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id INTEGER NOT NULL REFERENCES agents(agent_id),
    from_tier TEXT,
    to_tier TEXT NOT NULL,
    reason TEXT,
    changed_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS agent_call_log (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id INTEGER NOT NULL REFERENCES agents(agent_id),
    vapi_call_id TEXT,
    direction TEXT,                      -- INBOUND/OUTBOUND
    transcript TEXT,
    outcome TEXT,
    call_started_at TEXT,
    call_ended_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS offers (
    offer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER NOT NULL REFERENCES leads(lead_id),
    exit_strategy TEXT NOT NULL,         -- WHOLESALE_ASSIGNMENT/NOVATION/SUBTO/JUNIOR_BROKERAGE
    tier TEXT,                           -- T1/T2/T3
    offer_amount REAL,
    mao_ceiling REAL,
    estimated_fp_max_price REAL,
    estimated_assignment_fee REAL,
    estimated_ips_novation_profit REAL,
    novation_listing_agent TEXT,
    novation_min_ips_profit REAL DEFAULT 15000,
    double_close_flag INTEGER DEFAULT 0,
    status TEXT DEFAULT 'DRAFTED',       -- DRAFTED/PRESENTED/ACCEPTED/REJECTED
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS contracts (
    contract_id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER NOT NULL REFERENCES leads(lead_id),
    contract_type TEXT,                  -- PURCHASE/NOVATION/SUBTO
    signed_amount REAL,
    signed_at TEXT,
    contract_doc_url TEXT,               -- link to the signed purchase agreement - needed by Taylor/title company
    affidavit_filed INTEGER DEFAULT 0,
    moa_filed INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS scout_runs (
    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    module TEXT NOT NULL,
    county_or_zip TEXT,
    run_at TEXT DEFAULT (datetime('now')),
    raw_results INTEGER DEFAULT 0,
    in_market_results INTEGER DEFAULT 0,
    new_leads INTEGER DEFAULT 0,
    portal_status TEXT,                  -- OK/BLOCKED/ERROR
    consecutive_failures INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS daily_kpi (
    kpi_date TEXT PRIMARY KEY,
    leads_today INTEGER DEFAULT 0,
    conversations_today INTEGER DEFAULT 0,
    offers_today INTEGER DEFAULT 0,
    contracts_today INTEGER DEFAULT 0,
    fb_ad_leads INTEGER DEFAULT 0,
    fsbo_leads INTEGER DEFAULT 0,
    scout_leads INTEGER DEFAULT 0,
    mat_beard_touches INTEGER DEFAULT 0,
    speed_to_lead_breaches INTEGER DEFAULT 0,
    ceo_alerts_fired INTEGER DEFAULT 0,
    d4d_leads INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS mat_beard_touches (
    touch_id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_name TEXT,
    channel TEXT,                        -- EMAIL/LINKEDIN/CALL/SMS
    sent_at TEXT DEFAULT (datetime('now')),
    phase INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS followup_queue (
    queue_id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER NOT NULL REFERENCES leads(lead_id),
    track INTEGER NOT NULL,              -- 1 = automated drip, 2 = contextual
    next_touch_at TEXT,
    status TEXT DEFAULT 'PENDING',       -- PENDING/SENT/EXHAUSTED/DO_NOT_CONTACT
    drip_step TEXT                       -- D3/D7/D14/D30 for track 1
);

CREATE TABLE IF NOT EXISTS ceo_alerts (
    alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_type TEXT NOT NULL,
    severity TEXT DEFAULT 'WARN',        -- INFO/WARN/CRITICAL
    lead_id INTEGER REFERENCES leads(lead_id),
    message TEXT,
    fired_at TEXT DEFAULT (datetime('now')),
    email_sent_at TEXT
);

CREATE TABLE IF NOT EXISTS handoffs (
    handoff_id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER NOT NULL REFERENCES leads(lead_id),
    to_team_member TEXT NOT NULL,        -- ALEX
    status TEXT DEFAULT 'QUEUED',        -- QUEUED/ACKNOWLEDGED
    risk_tier TEXT DEFAULT 'STANDARD',
    exit_strategy TEXT,
    double_close_recommended INTEGER DEFAULT 0,
    photos_status TEXT DEFAULT 'NEEDED',
    photos_urgency TEXT,
    property_condition_signals TEXT,     -- JSON array (NOT "notes" - real schema bug fixed here)
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS resimpli_sync_queue (
    queue_id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER REFERENCES leads(lead_id),
    action TEXT NOT NULL,                -- CREATE_LEAD/TAG/etc
    status TEXT DEFAULT 'QUEUED',
    created_at TEXT DEFAULT (datetime('now')),
    flushed_at TEXT
);

CREATE TABLE IF NOT EXISTS fl_county_queue (
    county TEXT PRIMARY KEY,
    zips TEXT,                           -- JSON array
    portal_url TEXT,
    last_processed_at TEXT,
    consecutive_failures INTEGER DEFAULT 0,
    paused INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS d4d_zip_queue (
    zip TEXT PRIMARY KEY,
    last_processed_at TEXT,
    score_bonus_rules TEXT                -- JSON
);

CREATE INDEX IF NOT EXISTS idx_leads_zip ON leads(zip);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_test_data ON leads(is_test_data);
CREATE INDEX IF NOT EXISTS idx_conversations_lead ON conversations(lead_id);
CREATE INDEX IF NOT EXISTS idx_offers_lead ON offers(lead_id);
CREATE INDEX IF NOT EXISTS idx_handoffs_status ON handoffs(status, to_team_member);
